
import discord
from discord.ext import commands
import sqlite3
from datetime import datetime, timezone
import os

DB_FILE = "db/invite_tracker.db"

class InviteTracker(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.init_db())
        self.guild_invites = {}
        self.member_join_data = {}  # Track who invited whom

    async def init_db(self):
        await self.bot.wait_until_ready()
        # Create db directory if it doesn't exist
        os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
        with sqlite3.connect(DB_FILE) as conn:
            conn.executescript("""
            CREATE TABLE IF NOT EXISTS invites (
                guild_id TEXT,
                inviter_id TEXT,
                invite_code TEXT,
                uses INTEGER DEFAULT 0,
                PRIMARY KEY(guild_id, invite_code)
            );

            CREATE TABLE IF NOT EXISTS invite_stats (
                guild_id TEXT,
                user_id TEXT,
                invites INTEGER DEFAULT 0,
                fake INTEGER DEFAULT 0,
                leaves INTEGER DEFAULT 0,
                rejoins INTEGER DEFAULT 0,
                PRIMARY KEY(guild_id, user_id)
            );

            CREATE TABLE IF NOT EXISTS invite_settings (
                guild_id TEXT PRIMARY KEY,
                enabled INTEGER DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS member_inviter (
                guild_id TEXT,
                member_id TEXT,
                inviter_id TEXT,
                join_time TEXT,
                PRIMARY KEY(guild_id, member_id)
            );
            """)
            conn.commit()

        for guild in self.bot.guilds:
            try:
                self.guild_invites[guild.id] = await guild.invites()
            except discord.Forbidden:
                self.guild_invites[guild.id] = []

    async def is_enabled(self, guild_id):
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("SELECT enabled FROM invite_settings WHERE guild_id = ?", (str(guild_id),))
            row = cursor.fetchone()
            return bool(row[0]) if row else False

    async def set_enabled(self, guild_id, enabled: bool):
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO invite_settings (guild_id, enabled) VALUES (?, ?)
            """, (str(guild_id), int(enabled)))
            conn.commit()

    @commands.command(name="inviteenable", aliases=["inven", "enableinvite"])
    @commands.has_permissions(administrator=True)
    async def inviteenable(self, ctx):
        await self.set_enabled(ctx.guild.id, True)
        await ctx.reply("✅ Invite tracking **enabled** for this server.")

    @commands.command(name="invitedisable", aliases=["invdis", "disableinvite"])
    @commands.has_permissions(administrator=True)
    async def invitedisable(self, ctx):
        await self.set_enabled(ctx.guild.id, False)
        await ctx.reply("✅ Invite tracking **disabled** for this server.")

    @commands.Cog.listener()
    async def on_guild_join(self, guild):
        try:
            self.guild_invites[guild.id] = await guild.invites()
        except discord.Forbidden:
            self.guild_invites[guild.id] = []

    @commands.Cog.listener()
    async def on_invite_create(self, invite):
        invites = self.guild_invites.get(invite.guild.id, [])
        invites.append(invite)
        self.guild_invites[invite.guild.id] = invites

    @commands.Cog.listener()
    async def on_invite_delete(self, invite):
        invites = self.guild_invites.get(invite.guild.id, [])
        self.guild_invites[invite.guild.id] = [i for i in invites if i.code != invite.code]

    @commands.Cog.listener()
    async def on_member_join(self, member):
        if not await self.is_enabled(member.guild.id):
            return

        guild = member.guild
        before_invites = self.guild_invites.get(guild.id, [])
        try:
            after_invites = await guild.invites()
        except discord.Forbidden:
            return

        self.guild_invites[guild.id] = after_invites
        used_invite = None

        # Find which invite was used
        for before in before_invites:
            after = discord.utils.get(after_invites, code=before.code)
            if after and after.uses > before.uses:
                used_invite = after
                break

        if not used_invite:
            return

        inviter = used_invite.inviter
        now = datetime.now(timezone.utc)
        acc_age = now - member.created_at

        # Check if this is a rejoin
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("SELECT inviter_id FROM member_inviter WHERE guild_id = ? AND member_id = ?", 
                                (str(guild.id), str(member.id)))
            previous_inviter = cursor.fetchone()

            # Store current join data
            conn.execute("""
                INSERT OR REPLACE INTO member_inviter (guild_id, member_id, inviter_id, join_time)
                VALUES (?, ?, ?, ?)
            """, (str(guild.id), str(member.id), str(inviter.id), now.isoformat()))

            # Update invite stats
            conn.execute("""
                INSERT OR IGNORE INTO invite_stats (guild_id, user_id, invites, fake, leaves, rejoins)
                VALUES (?, ?, 0, 0, 0, 0)
            """, (str(guild.id), str(inviter.id)))

            if previous_inviter:
                # This is a rejoin
                previous_inviter_id = previous_inviter[0]
                conn.execute("""
                    UPDATE invite_stats SET rejoins = rejoins + 1 WHERE guild_id = ? AND user_id = ?
                """, (str(guild.id), str(inviter.id)))
                
                # Remove from leaves count if they left before
                conn.execute("""
                    UPDATE invite_stats SET leaves = MAX(leaves - 1, 0) WHERE guild_id = ? AND user_id = ?
                """, (str(guild.id), previous_inviter_id))
            else:
                # New join
                if acc_age.total_seconds() < 86400:  # Account younger than 1 day
                    conn.execute("""
                        UPDATE invite_stats SET fake = fake + 1 WHERE guild_id = ? AND user_id = ?
                    """, (str(guild.id), str(inviter.id)))
                else:
                    conn.execute("""
                        UPDATE invite_stats SET invites = invites + 1 WHERE guild_id = ? AND user_id = ?
                    """, (str(guild.id), str(inviter.id)))

            # Update invite uses tracking
            conn.execute("""
                INSERT OR REPLACE INTO invites (guild_id, inviter_id, invite_code, uses)
                VALUES (?, ?, ?, ?)
            """, (str(guild.id), str(inviter.id), used_invite.code, used_invite.uses))
            
            conn.commit()

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        if not await self.is_enabled(member.guild.id):
            return
            
        guild = member.guild
        with sqlite3.connect(DB_FILE) as conn:
            # Find who invited this member
            cursor = conn.execute("SELECT inviter_id FROM member_inviter WHERE guild_id = ? AND member_id = ?", 
                                (str(guild.id), str(member.id)))
            inviter_data = cursor.fetchone()
            
            if inviter_data:
                inviter_id = inviter_data[0]
                
                # Increase leaves count for the inviter
                conn.execute("""
                    INSERT OR IGNORE INTO invite_stats (guild_id, user_id, invites, fake, leaves, rejoins)
                    VALUES (?, ?, 0, 0, 0, 0)
                """, (str(guild.id), inviter_id))
                
                conn.execute("""
                    UPDATE invite_stats SET leaves = leaves + 1 WHERE guild_id = ? AND user_id = ?
                """, (str(guild.id), inviter_id))
                
                # Don't delete member_inviter record - keep it for rejoin detection
            
            conn.commit()

    async def get_stats(self, guild_id, user_id):
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                SELECT invites, fake, leaves, rejoins FROM invite_stats WHERE guild_id = ? AND user_id = ?
            """, (str(guild_id), str(user_id)))
            return cursor.fetchone() or (0, 0, 0, 0)

    @commands.command(name="invites", aliases=["inv", "invitation"])
    async def invites(self, ctx, member: discord.Member = None):
        if member is None:
            member = ctx.author
        if not isinstance(member, discord.Member):
            return await ctx.reply("❌ Invalid member provided.")
        if not await self.is_enabled(ctx.guild.id):
            return await ctx.reply("❌ Invite tracking is disabled.")

        invites, fake, leaves, rejoins = await self.get_stats(ctx.guild.id, member.id)
        total = invites - fake - leaves - rejoins
        
        embed = discord.Embed(title=f"📨 Invite Stats: {member}", color=discord.Color.blurple())
        embed.add_field(name="Valid Invites", value=invites, inline=True)
        embed.add_field(name="Fake Invites", value=fake, inline=True)
        embed.add_field(name="Left Members", value=leaves, inline=True)
        embed.add_field(name="Rejoined", value=rejoins, inline=True)
        embed.add_field(name="Total Score", value=f"**{total}**", inline=False)
        embed.set_footer(text=f"Total = Valid - Fake - Left - Rejoined")
        await ctx.reply(embed=embed)

    @commands.command(name="inviteleaderboard", aliases=["invlb", "invboard"])
    async def inviteleaderboard(self, ctx):
        if not await self.is_enabled(ctx.guild.id):
            return await ctx.reply("❌ Invite tracking is disabled.")

        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                SELECT user_id, invites, fake, leaves, rejoins,
                       (invites - fake - leaves - rejoins) as total
                FROM invite_stats 
                WHERE guild_id = ? 
                ORDER BY total DESC 
                LIMIT 10
            """, (str(ctx.guild.id),))
            rows = cursor.fetchall()

        if not rows:
            return await ctx.reply("❌ No invite data found.")

        embed = discord.Embed(title="🏆 Invite Leaderboard", color=discord.Color.gold())
        
        for i, (user_id, invites, fake, leaves, rejoins, total) in enumerate(rows, start=1):
            user = ctx.guild.get_member(int(user_id))
            name = user.display_name if user else f"<@{user_id}>"
            
            embed.add_field(
                name=f"#{i} {name}", 
                value=f"**{total}** total\n`{invites}` valid, `{fake}` fake, `{leaves}` left, `{rejoins}` rejoined", 
                inline=False
            )

        await ctx.reply(embed=embed)

    @commands.command(name="resetinvites", aliases=["resetinv", "cleanuserinv"])
    @commands.has_permissions(administrator=True)
    async def resetinvites(self, ctx, member: discord.Member):
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute("DELETE FROM invite_stats WHERE guild_id = ? AND user_id = ?", 
                        (str(ctx.guild.id), str(member.id)))
            conn.execute("DELETE FROM member_inviter WHERE guild_id = ? AND inviter_id = ?", 
                        (str(ctx.guild.id), str(member.id)))
            conn.commit()
        await ctx.reply(f"✅ Reset all invite stats for {member.mention}")

    @commands.command(name="addinvites", aliases=["addinv", "ainv"])
    @commands.has_permissions(administrator=True)
    async def addinvites(self, ctx, member: discord.Member, amount: int):
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute("""
                INSERT OR IGNORE INTO invite_stats (guild_id, user_id, invites, fake, leaves, rejoins)
                VALUES (?, ?, 0, 0, 0, 0)
            """, (str(ctx.guild.id), str(member.id)))
            conn.execute("""
                UPDATE invite_stats SET invites = invites + ? WHERE guild_id = ? AND user_id = ?
            """, (amount, str(ctx.guild.id), str(member.id)))
            conn.commit()
        await ctx.reply(f"✅ Added {amount} invites to {member.mention}")

    @commands.command(name="removeinvites", aliases=["reminv", "rinv"])
    @commands.has_permissions(administrator=True)
    async def removeinvites(self, ctx, member: discord.Member, amount: int):
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute("""
                INSERT OR IGNORE INTO invite_stats (guild_id, user_id, invites, fake, leaves, rejoins)
                VALUES (?, ?, 0, 0, 0, 0)
            """, (str(ctx.guild.id), str(member.id)))
            conn.execute("""
                UPDATE invite_stats SET invites = MAX(invites - ?, 0) WHERE guild_id = ? AND user_id = ?
            """, (amount, str(ctx.guild.id), str(member.id)))
            conn.commit()
        await ctx.reply(f"✅ Removed {amount} invites from {member.mention}")

    @commands.command(name="resetserverinvites", aliases=["resetallinv", "clearallinv"])
    @commands.has_permissions(administrator=True)
    async def resetserverinvites(self, ctx):
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute("DELETE FROM invite_stats WHERE guild_id = ?", (str(ctx.guild.id),))
            conn.execute("DELETE FROM invites WHERE guild_id = ?", (str(ctx.guild.id),))
            conn.execute("DELETE FROM member_inviter WHERE guild_id = ?", (str(ctx.guild.id),))
            conn.commit()
        await ctx.reply("✅ Reset all invite stats for this server.")

async def setup(bot):
    await bot.add_cog(InviteTracker(bot))
