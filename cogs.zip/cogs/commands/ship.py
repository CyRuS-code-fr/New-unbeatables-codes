import os
import io
import random
import discord
import datetime
import requests
import aiosqlite
from typing import Optional
from discord.ext import commands
from discord.ext.commands import errors
from PIL import Image, ImageFont, ImageDraw
from utils.Tools import *

class Ship(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.special_users = [1202618886466314273,]
        self.bot.loop.create_task(self.init_db())

    async def init_db(self):
        """Initialize ship gender roles database"""
        try:
            async with aiosqlite.connect('./db/ship.db') as db:
                await db.execute('''
                    CREATE TABLE IF NOT EXISTS gender_roles (
                        guild_id INTEGER,
                        boy_role_id INTEGER,
                        girl_role_id INTEGER,
                        PRIMARY KEY (guild_id)
                    )
                ''')
                await db.commit()
        except Exception as e:
            print(f"Error initializing ship database: {e}")

    @commands.hybrid_command(help="Ship two users together.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def ship(self, ctx, user1: Optional[discord.Member] = None, user2: Optional[discord.Member] = None):
        """Ship two users together with gender-based matching"""
        
        # Get gender roles for this guild
        try:
            async with aiosqlite.connect('./db/ship.db') as db:
                cursor = await db.execute(
                    'SELECT boy_role_id, girl_role_id FROM gender_roles WHERE guild_id = ?',
                    (ctx.guild.id,)
                )
                result = await cursor.fetchone()
                boy_role_id, girl_role_id = result if result else (None, None)
        except Exception:
            boy_role_id, girl_role_id = None, None

        if user1 is None:  
            user1 = ctx.author
            # Priority 1: Try opposite gender
            user2 = await self.get_opposite_gender_member(ctx.guild, user1, boy_role_id, girl_role_id)
            
            if user2 is None:
                # Priority 2: Fallback to any available member (including same gender)
                available_members = [m for m in ctx.guild.members if not m.bot and m != user1]
                user2 = random.choice(available_members) if available_members else ctx.author
        elif user2 is None:  
            user2 = user1
            user1 = ctx.author

        # Ensure we have valid users
        if not user1 or not user2:
            embed = discord.Embed(
                title="❌ Ship Error",
                description="Unable to find members to ship!",
                color=0xff0000
            )
            await ctx.reply(embed=embed)
            return
            
        if user1.id == user2.id:
            embed = discord.Embed(
                title="❌ Invalid Ship",
                description="You can't ship someone with themselves!",
                color=0xff0000
            )
            await ctx.reply(embed=embed)
            return

        author_id = float(user1.id)
        user_id = float(user2.id)

        if user1.id in self.special_users and user2.id in self.special_users:
            rate = 100
        else:
            now = datetime.datetime.now()
            day_seed = (now.day + now.month + now.year) / 3
            seed = (author_id + user_id) / day_seed
            random.seed(seed)
            rate = random.randint(1, 99)

        user_avatar = await get_avatar(user2)
        author_avatar = await get_avatar(user1)

        if user_avatar and author_avatar:
            self.make_image(author_avatar, user_avatar, user1.name, user2.name, rate)
            await self.img_ship(ctx, user1.mention, user2.mention, rate)
        else:
            await self.text_ship(ctx, user1.mention, user2.mention, rate)

    async def img_ship(self, ctx, author, user, rate):
        msg = "**Love rate between {0} & {1} is:**\n`{3}` {2}%"
        progress_bar = self.create_progress_bar(rate)
        try:
            b = discord.Embed(color=discord.Color(0xeb1818), description=msg.format(author, user, rate, progress_bar))
            f = discord.File("./data/ship/tmp_ship.png")
            b.set_image(url="attachment://tmp_ship.png")
            await ctx.reply(file=f, embed=b)
        except errors.BadArgument:
            await ctx.reply("Oops, something went wrong! Try again later!")

    def make_image(self, author_avatar, user_avatar, author, user, rate):
        red = (191, 15, 0, 255)
        white = (255, 255, 255, 255)
        blank = (255, 255, 255, 0)
        tmpl = Image.open("./data/ship/Template.png", "r").convert('RGBA')
        fill = Image.open("./data/ship/Tmpl_fill.png", "r").convert('RGBA')
        blank = Image.new('RGBA', tmpl.size, blank)
        fnt = ImageFont.truetype("./data/ship/font.ttf", 34)
        draw = ImageDraw.Draw(blank)
        author_avatar = author_avatar.resize((150, 150), Image.Resampling.LANCZOS)
        user_avatar = user_avatar.resize((150, 150), Image.Resampling.LANCZOS)
        tmpl.paste(author_avatar, (20, 50))
        tmpl.paste(user_avatar, (20, 312))
        offset = (100 - rate) * 2
        fill = fill.crop((0, offset, fill.width, fill.height))
        blank.paste(fill, (tmpl.width - fill.width - 1, 154 + offset))
        draw.text((20, 10), str(author), font=fnt, fill=red)
        draw.text((20, 460), str(user), font=fnt, fill=red)
        fnt = ImageFont.truetype("./data/ship/font.ttf", 80)
        draw.text((330, 192), str(rate) + "%", font=fnt, fill=white)
        tmpl = Image.alpha_composite(tmpl, blank)
        tmpl.save("./data/ship/tmp_ship.png", "PNG")

    async def text_ship(self, ctx, author, user, rate):
        msg = "**Love rate between {0} & {1} is:**\n`{3}` {2}%"
        progress_bar = self.create_progress_bar(rate)
        try:
            b = discord.Embed(color=discord.Color(0xeb1818), description=msg.format(author, user, rate, progress_bar))
            await ctx.reply(embed=b)
        except errors.BadArgument:
            await ctx.reply("Oops, something went wrong! Try again later!")

    def create_progress_bar(self, rate):
        filled_length = int(20 * rate // 100)
        bar = '█' * filled_length + ' ' * (20 - filled_length)
        return bar

    async def get_opposite_gender_member(self, guild, user, boy_role_id, girl_role_id):
        """Get a random member of opposite gender based on roles"""
        if not boy_role_id or not girl_role_id:
            return None
        
        # Get user's gender based on roles
        user_is_boy = any(role.id == boy_role_id for role in user.roles)
        user_is_girl = any(role.id == girl_role_id for role in user.roles)
        
        if not user_is_boy and not user_is_girl:
            # User has no gender role, pick random opposite gender member
            opposite_members = []
            for member in guild.members:
                if not member.bot and member != user:
                    has_boy_role = any(role.id == boy_role_id for role in member.roles)
                    has_girl_role = any(role.id == girl_role_id for role in member.roles)
                    if has_boy_role or has_girl_role:
                        opposite_members.append(member)
            return random.choice(opposite_members) if opposite_members else None
        
        # Find opposite gender members
        target_role_id = girl_role_id if user_is_boy else boy_role_id
        opposite_members = []
        
        for member in guild.members:
            if not member.bot and member != user:
                if any(role.id == target_role_id for role in member.roles):
                    opposite_members.append(member)
        
        return random.choice(opposite_members) if opposite_members else None

    @commands.command(help="Set boy and girl roles for gender-based ship matching")
    @blacklist_check()
    @ignore_check()
    @commands.has_permissions(manage_roles=True)
    async def shipsetup(self, ctx, boy_role: discord.Role, girl_role: discord.Role):
        """Setup boy and girl roles for ship command"""
        try:
            async with aiosqlite.connect('./db/ship.db') as db:
                await db.execute('''
                    INSERT OR REPLACE INTO gender_roles (guild_id, boy_role_id, girl_role_id)
                    VALUES (?, ?, ?)
                ''', (ctx.guild.id, boy_role.id, girl_role.id))
                await db.commit()
            
            embed = discord.Embed(
                title="✅ Ship Roles Configured!",
                description=f"**Boy Role:** {boy_role.mention}\n**Girl Role:** {girl_role.mention}\n\nNow ship command will match opposite genders!",
                color=0x00ff00
            )
            await ctx.reply(embed=embed)
        except Exception as e:
            error_msg = f"❌ Error setting up ship roles: {e}"
            if hasattr(ctx, 'interaction') and ctx.interaction:
                await ctx.reply(error_msg, ephemeral=True)
            else:
                await ctx.reply(error_msg)


    @commands.command(help="View current ship role configuration")
    @blacklist_check()
    @ignore_check()
    async def shipconfig(self, ctx):
        """View current ship role configuration"""
        try:
            async with aiosqlite.connect('./db/ship.db') as db:
                cursor = await db.execute(
                    'SELECT boy_role_id, girl_role_id FROM gender_roles WHERE guild_id = ?',
                    (ctx.guild.id,)
                )
                result = await cursor.fetchone()
            
            if result:
                boy_role_id, girl_role_id = result
                boy_role = ctx.guild.get_role(boy_role_id)
                girl_role = ctx.guild.get_role(girl_role_id)
                
                embed = discord.Embed(
                    title="🚢 Ship Configuration",
                    description=f"**Boy Role:** {boy_role.mention if boy_role else 'Role Deleted'}\n**Girl Role:** {girl_role.mention if girl_role else 'Role Deleted'}",
                    color=0x0099ff
                )
            else:
                embed = discord.Embed(
                    title="🚢 Ship Configuration",
                    description="No ship roles configured yet.\nUse `/shipsetup @boy_role @girl_role` to set them up!",
                    color=0xff9900
                )
            
            await ctx.reply(embed=embed)
        except Exception as e:
            error_msg = f"❌ Error fetching ship config: {e}"
            if hasattr(ctx, 'interaction') and ctx.interaction:
                await ctx.reply(error_msg, ephemeral=True)
            else:
                await ctx.reply(error_msg)


async def get_avatar(user):
    try:
        user_url = user.display_avatar.replace(format="png").url
        response = requests.get(user_url + "?size=256")
        avatar = Image.open(io.BytesIO(response.content)).convert('RGBA')
        tmp = Image.new('RGBA', avatar.size, (255, 255, 255, 255))
        tmp = Image.alpha_composite(tmp, avatar)
        return tmp
    except Exception as e:
        print(f"Error fetching avatar: {e}")
        return None


def setup(bot):
    bot.add_cog(Ship(bot))




"""
@Author: Sonu Jana
    + Discord: me.sonu
    + Community: https://discord.gg/odx (Olympus Development)
    + for any queries reach out support or DM me.
"""
