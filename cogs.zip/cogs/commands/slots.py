import discord
from discord.ext import commands
import random
import os
import uuid
from PIL import Image, ImageDraw, ImageFont
import bisect
from typing import List, Dict
from utils.Tools import *


class Slots(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(aliases=['slot'])
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def slots(self, ctx: commands.Context, *mentioned_users: discord.Member):
        try:
            # Setup players (author + mentioned users, max 4 total)
            all_players = [ctx.author] + list(mentioned_users)
            if len(all_players) > 4:
                await ctx.send(embed=discord.Embed(description="🎰 Maximum 4 players allowed!", color=discord.Color.red()))
                return
            
            # Remove duplicates and filter out bots while preserving order
            players = []
            for player in all_players:
                if player not in players and not player.bot:
                    players.append(player)
                elif player.bot and player != ctx.author:
                    await ctx.send(embed=discord.Embed(description=f"❌ Cannot add bot {player.display_name} to the game!", color=discord.Color.red()))
                    return
            
            if len(players) == 1:
                # Single player mode
                await self.single_player_slots(ctx)
                return
            else:
                # Multiplayer mode
                await self.multiplayer_slots(ctx, players)
                return
        except Exception as e:
            print(e)
            
    async def multiplayer_slots(self, ctx: commands.Context, players: List[discord.Member]):
        """Multiplayer slots game for up to 4 players"""
        try:
            # Initialize player results
            player_results: Dict[discord.Member, dict] = {}
            
            # Send initial message
            embed = discord.Embed(
                title="🎰 Multiplayer Slots",
                description=f"**{len(players)} players** are spinning the slots!\n\n🎲 Rolling...",
                color=discord.Color.gold()
            )
            message = await ctx.send(embed=embed)
            
            # Generate results for each player
            for player in players:
                result = self.generate_slot_result()
                player_results[player] = result
            
            # Create combined results image
            combined_file = self.create_multiplayer_slots_image(ctx.message.id, players, player_results)
            
            # Calculate winners
            winners = [player for player, result in player_results.items() if result['won']]
            
            # Create final embed
            final_embed = discord.Embed(
                title="🎰 Multiplayer Slots Results",
                color=discord.Color.green() if winners else discord.Color.red()
            )
            
            # Add results for each player
            results_text = ""
            for i, (player, result) in enumerate(player_results.items()):
                status = "🎉 WON" if result['won'] else "❌ LOST"
                results_text += f"**{i+1}. {player.display_name}:** {status}\n"
            
            if winners:
                final_embed.description = f"🎊 **{len(winners)} player(s) won!**\n\n{results_text}"
            else:
                final_embed.description = f"💸 **No winners this time!**\n\n{results_text}"
            
            final_embed.set_image(url=f"attachment://{combined_file.filename}")
            
            # Send new message with results (edit doesn't support new attachments)
            try:
                await message.delete()
            except:
                pass
            
            await ctx.send(embed=final_embed, file=combined_file)
            
            # Cleanup
            os.remove(f"data/pictures/mp_slots_{ctx.message.id}.png")
            
        except Exception as e:
            print(f"Multiplayer slots error: {e}")
            await ctx.send(embed=discord.Embed(description="❌ An error occurred during the slots game.", color=discord.Color.red()))
    
    def generate_slot_result(self) -> dict:
        """Generate slot result for a single player"""
        try:
            path = os.path.join('data/pictures/')
            facade = Image.open(f'{path}slot-face.png').convert('RGBA')
            reel = Image.open(f'{path}slot-reel.png').convert('RGBA')
        except:
            # Create fallback if images not found
            facade = Image.new('RGBA', (300, 200), color=(139, 69, 19))
            reel = Image.new('RGBA', (100, 1800), color=(255, 255, 255))
        
        rw, rh = reel.size
        item = 180
        items = rh // item if rh > 0 else 10
        
        s1 = random.randint(1, items - 1)
        s2 = random.randint(1, items - 1) 
        s3 = random.randint(1, items - 1)
        
        win_rate = 25 / 100
        
        if random.random() < win_rate:
            symbols_weights = [3.5, 7, 15, 25, 55]
            x = round(random.random() * 100, 1)
            pos = bisect.bisect(symbols_weights, x)
            s1 = pos + (random.randint(1, max(1, (items // 6) - 1)) * 6)
            s2 = pos + (random.randint(1, max(1, (items // 6) - 1)) * 6)
            s3 = pos + (random.randint(1, max(1, (items // 6) - 1)) * 6)
            s1 = s1 - 6 if s1 >= items else s1
            s2 = s2 - 6 if s2 >= items else s2
            s3 = s3 - 6 if s3 >= items else s3
        
        # Check if won
        won = (1 + s1) % 6 == (1 + s2) % 6 == (1 + s3) % 6
        
        return {
            's1': s1,
            's2': s2, 
            's3': s3,
            'won': won,
            'facade': facade,
            'reel': reel
        }
    
    def create_multiplayer_slots_image(self, game_id: int, players: List[discord.Member], 
                                      player_results: Dict[discord.Member, dict]) -> discord.File:
        """Create combined slots image for all players"""
        try:
            # Calculate image dimensions
            player_count = len(players)
            slot_width = 300
            slot_height = 200
            
            # Arrange in 2x2 grid for up to 4 players
            if player_count <= 2:
                cols = player_count
                rows = 1
            else:
                cols = 2
                rows = 2
            
            total_width = cols * slot_width + (cols - 1) * 20
            total_height = rows * slot_height + (rows - 1) * 20 + 60  # Extra space for titles
            
            # Create combined image
            combined = Image.new('RGBA', (total_width, total_height), color=(34, 139, 34))
            
            # Draw title
            try:
                font = ImageFont.truetype('utils/arial.ttf', 24)
            except:
                font = ImageFont.load_default()
            
            draw = ImageDraw.Draw(combined)
            title = "🎰 Multiplayer Slots Results"
            title_bbox = draw.textbbox((0, 0), title, font=font)
            title_width = title_bbox[2] - title_bbox[0]
            draw.text(((total_width - title_width) // 2, 10), title, fill='white', font=font)
            
            # Draw individual slot results
            for i, (player, result) in enumerate(player_results.items()):
                row = i // cols
                col = i % cols
                
                x = col * (slot_width + 20)
                y = 50 + row * (slot_height + 20)
                
                # Create individual slot image
                player_slot = self.create_single_slot_image(result)
                player_slot = player_slot.resize((slot_width, slot_height))
                
                # Paste onto combined image
                combined.paste(player_slot, (x, y))
                
                # Add player name and result
                try:
                    name_font = ImageFont.truetype('utils/arial.ttf', 16)
                except:
                    name_font = ImageFont.load_default()
                
                status = "🎉 WON" if result['won'] else "❌ LOST"
                player_text = f"{player.display_name}: {status}"
                
                # Text background
                text_bbox = draw.textbbox((0, 0), player_text, font=name_font)
                text_width = text_bbox[2] - text_bbox[0]
                text_height = text_bbox[3] - text_bbox[1]
                
                text_bg_color = (0, 255, 0, 180) if result['won'] else (255, 0, 0, 180)
                text_overlay = Image.new('RGBA', (int(text_width + 10), int(text_height + 4)), text_bg_color)
                combined.paste(text_overlay, (int(x + (slot_width - text_width - 10) // 2), int(y + slot_height - 25)), text_overlay)
                
                draw.text((x + (slot_width - text_width) // 2, y + slot_height - 23), 
                         player_text, fill='white', font=name_font)
            
            # Save combined image
            filename = f"mp_slots_{game_id}.png"
            filepath = f"data/pictures/{filename}"
            combined.save(filepath)
            
            return discord.File(filepath, filename=filename)
            
        except Exception as e:
            print(f"Error creating multiplayer slots image: {e}")
            # Create fallback image
            fallback = Image.new('RGBA', (400, 300), color=(34, 139, 34))
            filename = f"mp_slots_{game_id}.png"
            filepath = f"data/pictures/{filename}"
            fallback.save(filepath)
            return discord.File(filepath, filename=filename)
    
    def create_single_slot_image(self, result: dict) -> Image.Image:
        """Create slot image for single player result"""
        try:
            facade = result['facade']
            reel = result['reel']
            s1, s2, s3 = result['s1'], result['s2'], result['s3']
            
            rw, rh = reel.size
            item = 180
            
            # Create final frame
            bg = Image.new('RGBA', facade.size, color=(255, 255, 255))
            
            # Paste reels
            if rw > 0 and item > 0:
                bg.paste(reel, (25 + rw * 0, 100 - (item * s1)))
                bg.paste(reel, (25 + rw * 1, 100 - (item * s2)))
                bg.paste(reel, (25 + rw * 2, 100 - (item * s3)))
            
            # Apply facade
            bg.alpha_composite(facade)
            
            return bg
            
        except Exception as e:
            print(f"Error creating single slot image: {e}")
            # Return simple colored rectangle as fallback
            return Image.new('RGBA', (300, 200), color=(139, 69, 19))
    
    async def single_player_slots(self, ctx: commands.Context):
        """Original single player slots game"""
        try:
            path = os.path.join('data/pictures/')
            facade = Image.open(f'{path}slot-face.png').convert('RGBA')
            reel = Image.open(f'{path}slot-reel.png').convert('RGBA')

            rw, rh = reel.size
            item = 180
            items = rh // item

            s1 = random.randint(1, items - 1)
            s2 = random.randint(1, items - 1)
            s3 = random.randint(1, items - 1)

            win_rate = 25 / 100

            if random.random() < win_rate:
                symbols_weights = [3.5, 7, 15, 25, 55]
                x = round(random.random() * 100, 1)
                pos = bisect.bisect(symbols_weights, x)
                s1 = pos + (random.randint(1, (items // 6) - 1) * 6)
                s2 = pos + (random.randint(1, (items // 6) - 1) * 6)
                s3 = pos + (random.randint(1, (items // 6) - 1) * 6)
                s1 = s1 - 6 if s1 == items else s1
                s2 = s2 - 6 if s2 == items else s2
                s3 = s3 - 6 if s3 == items else s3

            images = []
            speed = 6
            for i in range(1, (item // speed) + 1):
                bg = Image.new('RGBA', facade.size, color=(255, 255, 255))
                bg.paste(reel, (25 + rw * 0, 100 - (speed * i * s1)))
                bg.paste(reel, (25 + rw * 1, 100 - (speed * i * s2)))
                bg.paste(reel, (25 + rw * 2, 100 - (speed * i * s3)))
                bg.alpha_composite(facade)
                images.append(bg)

            unique_filename = str(uuid.uuid4()) + '.gif'
            fp = os.path.join('data/pictures/', unique_filename)

            images[0].save(
                fp,
                save_all=True,
                append_images=images[1:],
                duration=50
            )

            file = discord.File(fp, filename=unique_filename)
            message = await ctx.reply(file=file)

            if (1 + s1) % 6 == (1 + s2) % 6 == (1 + s3) % 6:
                result = 'won'
            else:
                result = 'lost'

            embed = discord.Embed(
                title=f'{ctx.author.display_name}, You {result}!',
                color=discord.Color.green() if result == "won" else discord.Color.red()
            )

            embed.set_image(url=f"attachment://{unique_filename}")
            await message.edit(content=None, embed=embed)

            os.remove(fp)
        except Exception as e:
            print(f"Single player slots error: {e}")
            await ctx.send(embed=discord.Embed(description="❌ An error occurred during the slots game.", color=discord.Color.red()))


"""
@Author: Sonu Jana
    + Discord: me.sonu
    + Community: https://discord.gg/odx (Olympus Development)
    + for any queries reach out Community or DM me.
"""