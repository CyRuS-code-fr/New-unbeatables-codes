import discord
from discord.ext import commands, tasks
import sqlite3
import asyncio
from datetime import datetime, timezone, timedelta
import os
from typing import Optional, Dict, List

DB_FILE = "db/activity_tracker.db"

class ActivityTracker(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.init_db())
        self.voice_sessions = {}  # Track active voice sessions
        self.update_channels.start()  # Start periodic updates

    async def init_db(self):
        await self.bot.wait_until_ready()
        # Create db directory if it doesn't exist
        os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
        with sqlite3.connect(DB_FILE) as conn:
            conn.executescript("""
            CREATE TABLE IF NOT EXISTS message_stats (
                guild_id TEXT,
                user_id TEXT,
                channel_id TEXT,
                message_count INTEGER DEFAULT 0,
                last_message TIMESTAMP,
                PRIMARY KEY(guild_id, user_id, channel_id)
            );

            CREATE TABLE IF NOT EXISTS voice_stats (
                guild_id TEXT,
                user_id TEXT,
                channel_id TEXT,
                total_time INTEGER DEFAULT 0,
                last_joined TIMESTAMP,
                PRIMARY KEY(guild_id, user_id, channel_id)
            );

            CREATE TABLE IF NOT EXISTS activity_settings (
                guild_id TEXT PRIMARY KEY,
                message_tracking INTEGER DEFAULT 1,
                voice_tracking INTEGER DEFAULT 1,
                update_channel_id TEXT,
                update_interval INTEGER DEFAULT 3600
            );

            CREATE TABLE IF NOT EXISTS daily_stats (
                guild_id TEXT,
                user_id TEXT,
                date TEXT,
                messages INTEGER DEFAULT 0,
                voice_time INTEGER DEFAULT 0,
                PRIMARY KEY(guild_id, user_id, date)
            );
            """)
            conn.commit()

    async def is_message_tracking_enabled(self, guild_id):
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("SELECT message_tracking FROM activity_settings WHERE guild_id = ?", (str(guild_id),))
            row = cursor.fetchone()
            return bool(row[0]) if row else True

    async def is_voice_tracking_enabled(self, guild_id):
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("SELECT voice_tracking FROM activity_settings WHERE guild_id = ?", (str(guild_id),))
            row = cursor.fetchone()
            return bool(row[0]) if row else True

    async def set_tracking_settings(self, guild_id, message_tracking=None, voice_tracking=None):
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute("""
                INSERT INTO activity_settings (guild_id, message_tracking, voice_tracking) 
                VALUES (?, ?, ?) 
                ON CONFLICT(guild_id) DO UPDATE SET 
                message_tracking = COALESCE(excluded.message_tracking, message_tracking),
                voice_tracking = COALESCE(excluded.voice_tracking, voice_tracking)
            """, (str(guild_id), message_tracking, voice_tracking))
            conn.commit()

    async def set_update_channel(self, guild_id, channel_id, interval=3600):
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute("""
                INSERT INTO activity_settings (guild_id, update_channel_id, update_interval) 
                VALUES (?, ?, ?) 
                ON CONFLICT(guild_id) DO UPDATE SET 
                update_channel_id = excluded.update_channel_id,
                update_interval = excluded.update_interval
            """, (str(guild_id), str(channel_id), interval))
            conn.commit()

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return
        
        if not await self.is_message_tracking_enabled(message.guild.id):
            return

        now = datetime.now(timezone.utc)
        today = now.date().isoformat()

        with sqlite3.connect(DB_FILE) as conn:
            # Update message stats
            conn.execute("""
                INSERT INTO message_stats (guild_id, user_id, channel_id, message_count, last_message)
                VALUES (?, ?, ?, 1, ?)
                ON CONFLICT(guild_id, user_id, channel_id) DO UPDATE SET
                message_count = message_count + 1,
                last_message = excluded.last_message
            """, (str(message.guild.id), str(message.author.id), str(message.channel.id), now))

            # Update daily stats
            conn.execute("""
                INSERT INTO daily_stats (guild_id, user_id, date, messages)
                VALUES (?, ?, ?, 1)
                ON CONFLICT(guild_id, user_id, date) DO UPDATE SET
                messages = messages + 1
            """, (str(message.guild.id), str(message.author.id), today))
            
            conn.commit()

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if member.bot:
            return

        if not await self.is_voice_tracking_enabled(member.guild.id):
            return

        now = datetime.now(timezone.utc)
        today = now.date().isoformat()
        session_key = f"{member.guild.id}_{member.id}"

        # User joined a voice channel
        if before.channel is None and after.channel is not None:
            self.voice_sessions[session_key] = {
                'channel_id': after.channel.id,
                'join_time': now
            }

        # User left a voice channel
        elif before.channel is not None and after.channel is None:
            if session_key in self.voice_sessions:
                session = self.voice_sessions.pop(session_key)
                duration = int((now - session['join_time']).total_seconds())
                
                with sqlite3.connect(DB_FILE) as conn:
                    # Update voice stats
                    conn.execute("""
                        INSERT INTO voice_stats (guild_id, user_id, channel_id, total_time, last_joined)
                        VALUES (?, ?, ?, ?, ?)
                        ON CONFLICT(guild_id, user_id, channel_id) DO UPDATE SET
                        total_time = total_time + ?,
                        last_joined = excluded.last_joined
                    """, (str(member.guild.id), str(member.id), str(session['channel_id']), 
                         duration, session['join_time'], duration))

                    # Update daily stats
                    conn.execute("""
                        INSERT INTO daily_stats (guild_id, user_id, date, voice_time)
                        VALUES (?, ?, ?, ?)
                        ON CONFLICT(guild_id, user_id, date) DO UPDATE SET
                        voice_time = voice_time + ?
                    """, (str(member.guild.id), str(member.id), today, duration, duration))
                    
                    conn.commit()

        # User switched voice channels
        elif before.channel != after.channel and before.channel is not None and after.channel is not None:
            if session_key in self.voice_sessions:
                # End previous session
                session = self.voice_sessions[session_key]
                duration = int((now - session['join_time']).total_seconds())
                
                with sqlite3.connect(DB_FILE) as conn:
                    conn.execute("""
                        INSERT INTO voice_stats (guild_id, user_id, channel_id, total_time, last_joined)
                        VALUES (?, ?, ?, ?, ?)
                        ON CONFLICT(guild_id, user_id, channel_id) DO UPDATE SET
                        total_time = total_time + ?,
                        last_joined = excluded.last_joined
                    """, (str(member.guild.id), str(member.id), str(session['channel_id']), 
                         duration, session['join_time'], duration))

                    conn.execute("""
                        INSERT INTO daily_stats (guild_id, user_id, date, voice_time)
                        VALUES (?, ?, ?, ?)
                        ON CONFLICT(guild_id, user_id, date) DO UPDATE SET
                        voice_time = voice_time + ?
                    """, (str(member.guild.id), str(member.id), today, duration, duration))
                    
                    conn.commit()

            # Start new session
            self.voice_sessions[session_key] = {
                'channel_id': after.channel.id,
                'join_time': now
            }

    def format_time(self, seconds):
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        if hours > 0:
            return f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            return f"{minutes}m {seconds}s"
        else:
            return f"{seconds}s"

    # Enable/Disable Commands
    @commands.command(name="messagetracking", aliases=["msgtrack", "msgenable"])
    @commands.has_permissions(administrator=True)
    async def message_tracking(self, ctx, status: str = None):
        if status is None:
            enabled = await self.is_message_tracking_enabled(ctx.guild.id)
            status_text = "enabled" if enabled else "disabled"
            return await ctx.reply(f"📊 Message tracking is currently **{status_text}**")
        
        if status.lower() in ['on', 'enable', 'true', '1']:
            await self.set_tracking_settings(ctx.guild.id, message_tracking=1)
            await ctx.reply("✅ Message tracking **enabled**")
        elif status.lower() in ['off', 'disable', 'false', '0']:
            await self.set_tracking_settings(ctx.guild.id, message_tracking=0)
            await ctx.reply("✅ Message tracking **disabled**")
        else:
            await ctx.reply("❌ Invalid status. Use `on` or `off`")

    @commands.command(name="voicetracking", aliases=["vctrack", "vcenable"])
    @commands.has_permissions(administrator=True)
    async def voice_tracking(self, ctx, status: str = None):
        if status is None:
            enabled = await self.is_voice_tracking_enabled(ctx.guild.id)
            status_text = "enabled" if enabled else "disabled"
            return await ctx.reply(f"📊 Voice tracking is currently **{status_text}**")
        
        if status.lower() in ['on', 'enable', 'true', '1']:
            await self.set_tracking_settings(ctx.guild.id, voice_tracking=1)
            await ctx.reply("✅ Voice tracking **enabled**")
        elif status.lower() in ['off', 'disable', 'false', '0']:
            await self.set_tracking_settings(ctx.guild.id, voice_tracking=0)
            await ctx.reply("✅ Voice tracking **disabled**")
        else:
            await ctx.reply("❌ Invalid status. Use `on` or `off`")

    # Stats Commands
    @commands.command(name="messagestats", aliases=["msgstats", "msgstat"])
    async def message_stats(self, ctx, member: discord.Member = None):
        if member is None:
            member = ctx.author
        if not isinstance(member, discord.Member):
            return await ctx.reply("❌ Invalid member provided.")

        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                SELECT SUM(message_count), COUNT(DISTINCT channel_id) 
                FROM message_stats 
                WHERE guild_id = ? AND user_id = ?
            """, (str(ctx.guild.id), str(member.id)))
            total_messages, channels_used = cursor.fetchone() or (0, 0)

            cursor = conn.execute("""
                SELECT channel_id, message_count 
                FROM message_stats 
                WHERE guild_id = ? AND user_id = ? 
                ORDER BY message_count DESC LIMIT 3
            """, (str(ctx.guild.id), str(member.id)))
            top_channels = cursor.fetchall()

        embed = discord.Embed(
            title=f"📊 Message Stats: {member.display_name}",
            color=discord.Color.blue()
        )
        embed.add_field(name="Total Messages", value=f"{total_messages:,}", inline=True)
        embed.add_field(name="Channels Used", value=f"{channels_used}", inline=True)
        embed.add_field(name="\u200b", value="\u200b", inline=True)

        if top_channels:
            top_channels_text = ""
            for i, (channel_id, count) in enumerate(top_channels, 1):
                channel = ctx.guild.get_channel(int(channel_id))
                channel_name = channel.name if channel else f"Unknown Channel"
                top_channels_text += f"{i}. #{channel_name}: {count:,}\n"
            embed.add_field(name="Top Channels", value=top_channels_text, inline=False)

        embed.set_thumbnail(url=member.display_avatar.url)
        await ctx.reply(embed=embed)

    @commands.command(name="voicestats", aliases=["vcstats", "voicetime"])
    async def voice_stats(self, ctx, member: discord.Member = None):
        if member is None:
            member = ctx.author
        if not isinstance(member, discord.Member):
            return await ctx.reply("❌ Invalid member provided.")

        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                SELECT SUM(total_time), COUNT(DISTINCT channel_id) 
                FROM voice_stats 
                WHERE guild_id = ? AND user_id = ?
            """, (str(ctx.guild.id), str(member.id)))
            total_time, channels_used = cursor.fetchone() or (0, 0)

            cursor = conn.execute("""
                SELECT channel_id, total_time 
                FROM voice_stats 
                WHERE guild_id = ? AND user_id = ? 
                ORDER BY total_time DESC LIMIT 3
            """, (str(ctx.guild.id), str(member.id)))
            top_channels = cursor.fetchall()

        embed = discord.Embed(
            title=f"🎤 Voice Stats: {member.display_name}",
            color=discord.Color.green()
        )
        embed.add_field(name="Total Time", value=self.format_time(total_time or 0), inline=True)
        embed.add_field(name="Channels Used", value=f"{channels_used}", inline=True)
        embed.add_field(name="\u200b", value="\u200b", inline=True)

        if top_channels:
            top_channels_text = ""
            for i, (channel_id, time) in enumerate(top_channels, 1):
                channel = ctx.guild.get_channel(int(channel_id))
                channel_name = channel.name if channel else f"Unknown Channel"
                top_channels_text += f"{i}. {channel_name}: {self.format_time(time)}\n"
            embed.add_field(name="Top Channels", value=top_channels_text, inline=False)

        embed.set_thumbnail(url=member.display_avatar.url)
        await ctx.reply(embed=embed)

    @commands.command(name="userstats", aliases=["userstat", "useract"])
    async def user_stats(self, ctx, member: discord.Member = None):
        if member is None:
            member = ctx.author
        if not isinstance(member, discord.Member):
            return await ctx.reply("❌ Invalid member provided.")

        today = datetime.now(timezone.utc).date().isoformat()

        with sqlite3.connect(DB_FILE) as conn:
            # Get total stats
            cursor = conn.execute("""
                SELECT SUM(message_count) FROM message_stats 
                WHERE guild_id = ? AND user_id = ?
            """, (str(ctx.guild.id), str(member.id)))
            total_messages = cursor.fetchone()[0] or 0

            cursor = conn.execute("""
                SELECT SUM(total_time) FROM voice_stats 
                WHERE guild_id = ? AND user_id = ?
            """, (str(ctx.guild.id), str(member.id)))
            total_voice_time = cursor.fetchone()[0] or 0

            # Get today's stats
            cursor = conn.execute("""
                SELECT messages, voice_time FROM daily_stats 
                WHERE guild_id = ? AND user_id = ? AND date = ?
            """, (str(ctx.guild.id), str(member.id), today))
            daily_stats = cursor.fetchone() or (0, 0)

        embed = discord.Embed(
            title=f"📈 Activity Stats: {member.display_name}",
            color=discord.Color.purple()
        )
        
        embed.add_field(name="📊 All Time", value=f"Messages: {total_messages:,}\nVoice: {self.format_time(total_voice_time)}", inline=True)
        embed.add_field(name="📅 Today", value=f"Messages: {daily_stats[0]:,}\nVoice: {self.format_time(daily_stats[1])}", inline=True)
        embed.add_field(name="\u200b", value="\u200b", inline=True)

        embed.set_thumbnail(url=member.display_avatar.url)
        embed.timestamp = datetime.now(timezone.utc)
        await ctx.reply(embed=embed)

    # Leaderboard Commands
    @commands.command(name="messageleaderboard", aliases=["msglb", "topmessages", "msgboard"])
    async def message_leaderboard(self, ctx, limit: int = 10):
        limit = max(1, min(limit, 25))  # Limit between 1-25

        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                SELECT user_id, SUM(message_count) as total
                FROM message_stats 
                WHERE guild_id = ? 
                GROUP BY user_id 
                ORDER BY total DESC 
                LIMIT ?
            """, (str(ctx.guild.id), limit))
            results = cursor.fetchall()

        if not results:
            return await ctx.reply("❌ No message data found for this server.")

        embed = discord.Embed(
            title="🏆 Message Leaderboard", 
            color=discord.Color.gold()
        )

        leaderboard_text = ""
        for i, (user_id, count) in enumerate(results, 1):
            user = ctx.guild.get_member(int(user_id))
            if user:
                emoji = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else "🔸"
                leaderboard_text += f"{emoji} **{i}.** {user.display_name}: {count:,} messages\n"

        embed.description = leaderboard_text
        embed.set_footer(text=f"Showing top {len(results)} members")
        await ctx.reply(embed=embed)

    @commands.command(name="voiceleaderboard", aliases=["vclb", "topvoice", "vcboard"])
    async def voice_leaderboard(self, ctx, limit: int = 10):
        limit = max(1, min(limit, 25))  # Limit between 1-25

        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                SELECT user_id, SUM(total_time) as total
                FROM voice_stats 
                WHERE guild_id = ? 
                GROUP BY user_id 
                ORDER BY total DESC 
                LIMIT ?
            """, (str(ctx.guild.id), limit))
            results = cursor.fetchall()

        if not results:
            return await ctx.reply("❌ No voice data found for this server.")

        embed = discord.Embed(
            title="🏆 Voice Leaderboard", 
            color=discord.Color.gold()
        )

        leaderboard_text = ""
        for i, (user_id, time) in enumerate(results, 1):
            user = ctx.guild.get_member(int(user_id))
            if user:
                emoji = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else "🔸"
                leaderboard_text += f"{emoji} **{i}.** {user.display_name}: {self.format_time(time)}\n"

        embed.description = leaderboard_text
        embed.set_footer(text=f"Showing top {len(results)} members")
        await ctx.reply(embed=embed)

    @commands.command(name="activityleaderboard", aliases=["actlb", "topactivity", "actboard"])
    async def activity_leaderboard(self, ctx, limit: int = 10):
        limit = max(1, min(limit, 25))  # Limit between 1-25
        today = datetime.now(timezone.utc).date().isoformat()

        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                SELECT user_id, messages, voice_time, (messages + voice_time/60) as activity_score
                FROM daily_stats 
                WHERE guild_id = ? AND date = ?
                ORDER BY activity_score DESC 
                LIMIT ?
            """, (str(ctx.guild.id), today, limit))
            results = cursor.fetchall()

        if not results:
            return await ctx.reply("❌ No activity data found for today.")

        embed = discord.Embed(
            title="🏆 Today's Activity Leaderboard", 
            color=discord.Color.gold()
        )

        leaderboard_text = ""
        for i, (user_id, messages, voice_time, score) in enumerate(results, 1):
            user = ctx.guild.get_member(int(user_id))
            if user:
                emoji = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else "🔸"
                leaderboard_text += f"{emoji} **{i}.** {user.display_name}\n"
                leaderboard_text += f"    📊 {messages} msgs • 🎤 {self.format_time(voice_time)}\n"

        embed.description = leaderboard_text
        embed.set_footer(text=f"Showing top {len(results)} members for today")
        await ctx.reply(embed=embed)

    # Configuration Commands
    @commands.command(name="setupupdates", aliases=["setupchannel", "updatechannel"])
    @commands.has_permissions(administrator=True)
    async def setup_updates(self, ctx, channel: discord.TextChannel = None, interval: int = 3600):
        if channel is None:
            channel = ctx.channel

        interval = max(300, min(interval, 86400))  # Between 5 minutes and 24 hours

        await self.set_update_channel(ctx.guild.id, channel.id, interval)
        
        hours = interval // 3600
        minutes = (interval % 3600) // 60
        time_text = f"{hours}h {minutes}m" if hours > 0 else f"{minutes}m"
        
        await ctx.reply(f"✅ Activity updates will be posted in {channel.mention} every {time_text}")

    @commands.command(name="resetstats", aliases=["clearstats", "resetactivity"])
    @commands.has_permissions(administrator=True)
    async def reset_stats(self, ctx, member: discord.Member = None):
        if member:
            with sqlite3.connect(DB_FILE) as conn:
                conn.execute("DELETE FROM message_stats WHERE guild_id = ? AND user_id = ?", 
                           (str(ctx.guild.id), str(member.id)))
                conn.execute("DELETE FROM voice_stats WHERE guild_id = ? AND user_id = ?", 
                           (str(ctx.guild.id), str(member.id)))
                conn.execute("DELETE FROM daily_stats WHERE guild_id = ? AND user_id = ?", 
                           (str(ctx.guild.id), str(member.id)))
                conn.commit()
            await ctx.reply(f"✅ Reset all activity stats for {member.mention}")
        else:
            # Reset all server stats
            with sqlite3.connect(DB_FILE) as conn:
                conn.execute("DELETE FROM message_stats WHERE guild_id = ?", (str(ctx.guild.id),))
                conn.execute("DELETE FROM voice_stats WHERE guild_id = ?", (str(ctx.guild.id),))
                conn.execute("DELETE FROM daily_stats WHERE guild_id = ?", (str(ctx.guild.id),))
                conn.commit()
            await ctx.reply("✅ Reset all activity stats for this server")

    @commands.command(name="clearuserstats", aliases=["resetuser", "removeuserstats", "clearuseract"])
    @commands.has_permissions(administrator=True)
    async def clear_user_stats(self, ctx, member: discord.Member):
        """Clear all activity statistics for a specific user"""
        if not member:
            return await ctx.reply("❌ Please mention a user to clear their stats.")
        
        # Check if user has any stats
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                SELECT COUNT(*) FROM message_stats WHERE guild_id = ? AND user_id = ?
                UNION ALL
                SELECT COUNT(*) FROM voice_stats WHERE guild_id = ? AND user_id = ?
                UNION ALL
                SELECT COUNT(*) FROM daily_stats WHERE guild_id = ? AND user_id = ?
            """, (str(ctx.guild.id), str(member.id), str(ctx.guild.id), str(member.id), str(ctx.guild.id), str(member.id)))
            results = cursor.fetchall()
            total_records = sum(row[0] for row in results)
        
        if total_records == 0:
            return await ctx.reply(f"ℹ️ {member.mention} has no activity stats to clear.")
        
        # Clear all stats for the user
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute("DELETE FROM message_stats WHERE guild_id = ? AND user_id = ?", 
                       (str(ctx.guild.id), str(member.id)))
            conn.execute("DELETE FROM voice_stats WHERE guild_id = ? AND user_id = ?", 
                       (str(ctx.guild.id), str(member.id)))
            conn.execute("DELETE FROM daily_stats WHERE guild_id = ? AND user_id = ?", 
                       (str(ctx.guild.id), str(member.id)))
            conn.commit()
        
        embed = discord.Embed(
            title="✅ User Stats Cleared",
            description=f"Successfully cleared all activity statistics for {member.mention}",
            color=discord.Color.green()
        )
        embed.add_field(
            name="Cleared Data",
            value="• Message statistics\n• Voice channel statistics\n• Daily activity data",
            inline=False
        )
        embed.add_field(
            name="⚠️ Important Note",
            value="All historical stats are cleared! New activity will be tracked immediately.\nThe bot continues to monitor messages and voice activity in real-time.",
            inline=False
        )
        embed.set_footer(text="This action cannot be undone | New activity tracking starts now")
        
        await ctx.reply(embed=embed)

    @commands.command(name="clearmessagestats", aliases=["clearmsg", "resetmsg", "removemsgstats"])
    @commands.has_permissions(administrator=True)
    async def clear_message_stats(self, ctx, member: discord.Member):
        """Clear only message statistics for a specific user"""
        if not member:
            return await ctx.reply("❌ Please mention a user to clear their message stats.")
        
        # Check if user has any message stats
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                SELECT SUM(message_count) FROM message_stats WHERE guild_id = ? AND user_id = ?
            """, (str(ctx.guild.id), str(member.id)))
            total_messages = cursor.fetchone()[0] or 0
        
        if total_messages == 0:
            return await ctx.reply(f"ℹ️ {member.mention} has no message stats to clear.")
        
        # Clear only message stats for the user
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute("DELETE FROM message_stats WHERE guild_id = ? AND user_id = ?", 
                       (str(ctx.guild.id), str(member.id)))
            # Clear message part from daily stats
            conn.execute("UPDATE daily_stats SET messages = 0 WHERE guild_id = ? AND user_id = ?", 
                       (str(ctx.guild.id), str(member.id)))
            conn.commit()
        
        # Send immediate confirmation
        embed = discord.Embed(
            title="✅ Message Stats Cleared",
            description=f"Successfully cleared message statistics for {member.mention}",
            color=discord.Color.orange()
        )
        embed.add_field(
            name="Cleared Data",
            value=f"• {total_messages:,} total messages\n• All channel message data\n• Daily message data",
            inline=False
        )
        embed.add_field(
            name="⚠️ Important Note",
            value="Stats are cleared! New activity will be tracked from now on.\nThis is normal bot behavior - it tracks messages in real-time.",
            inline=False
        )
        embed.set_footer(text="Voice stats remain unchanged | New messages will be tracked immediately")
        
        await ctx.reply(embed=embed)

    @commands.command(name="clearvoicestats", aliases=["clearvc", "resetvc", "removevcstats"])
    @commands.has_permissions(administrator=True)
    async def clear_voice_stats(self, ctx, member: discord.Member):
        """Clear only voice channel statistics for a specific user"""
        if not member:
            return await ctx.reply("❌ Please mention a user to clear their voice stats.")
        
        # Check if user has any voice stats
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                SELECT SUM(total_time) FROM voice_stats WHERE guild_id = ? AND user_id = ?
            """, (str(ctx.guild.id), str(member.id)))
            total_time = cursor.fetchone()[0] or 0
        
        if total_time == 0:
            return await ctx.reply(f"ℹ️ {member.mention} has no voice stats to clear.")
        
        # Clear only voice stats for the user
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute("DELETE FROM voice_stats WHERE guild_id = ? AND user_id = ?", 
                       (str(ctx.guild.id), str(member.id)))
            # Clear voice part from daily stats
            conn.execute("UPDATE daily_stats SET voice_time = 0 WHERE guild_id = ? AND user_id = ?", 
                       (str(ctx.guild.id), str(member.id)))
            conn.commit()
        
        embed = discord.Embed(
            title="✅ Voice Stats Cleared",
            description=f"Successfully cleared voice channel statistics for {member.mention}",
            color=discord.Color.blue()
        )
        embed.add_field(
            name="Cleared Data",
            value=f"• {self.format_time(total_time)} total voice time\n• All channel voice data\n• Daily voice data",
            inline=False
        )
        embed.add_field(
            name="⚠️ Important Note",
            value="Stats are cleared! New voice activity will be tracked from now on.\nThis is normal bot behavior - it tracks voice time in real-time.",
            inline=False
        )
        embed.set_footer(text="Message stats remain unchanged | New voice activity will be tracked immediately")
        
        await ctx.reply(embed=embed)

    @commands.command(name="verifyclear", aliases=["checkstats", "statscheck"])
    async def verify_clear(self, ctx, member: discord.Member = None):
        """Verify if user stats are actually cleared"""
        if member is None:
            member = ctx.author
        
        with sqlite3.connect(DB_FILE) as conn:
            # Check message stats
            cursor = conn.execute("""
                SELECT SUM(message_count) FROM message_stats WHERE guild_id = ? AND user_id = ?
            """, (str(ctx.guild.id), str(member.id)))
            msg_count = cursor.fetchone()[0] or 0
            
            # Check voice stats
            cursor = conn.execute("""
                SELECT SUM(total_time) FROM voice_stats WHERE guild_id = ? AND user_id = ?
            """, (str(ctx.guild.id), str(member.id)))
            voice_time = cursor.fetchone()[0] or 0
            
            # Check daily stats
            today = datetime.now(timezone.utc).date().isoformat()
            cursor = conn.execute("""
                SELECT messages, voice_time FROM daily_stats 
                WHERE guild_id = ? AND user_id = ? AND date = ?
            """, (str(ctx.guild.id), str(member.id), today))
            daily_data = cursor.fetchone() or (0, 0)
        
        embed = discord.Embed(
            title=f"📊 Stats Verification: {member.display_name}",
            description="Current activity statistics in database",
            color=discord.Color.purple()
        )
        
        embed.add_field(
            name="All-Time Stats",
            value=f"Messages: {msg_count:,}\nVoice Time: {self.format_time(voice_time)}",
            inline=True
        )
        
        embed.add_field(
            name="Today's Stats",
            value=f"Messages: {daily_data[0]:,}\nVoice Time: {self.format_time(daily_data[1])}",
            inline=True
        )
        
        if msg_count == 0 and voice_time == 0:
            embed.add_field(
                name="✅ Status",
                value="All historical stats are cleared!",
                inline=False
            )
        else:
            embed.add_field(
                name="📈 Status", 
                value="Stats contain data (either historical or new activity)",
                inline=False
            )
        
        embed.set_footer(text="This shows current database values | Real-time tracking continues")
        await ctx.reply(embed=embed)

    # Periodic Updates Task
    @tasks.loop(minutes=5)
    async def update_channels(self):
        try:
            now = datetime.now(timezone.utc)
            
            with sqlite3.connect(DB_FILE) as conn:
                cursor = conn.execute("""
                    SELECT guild_id, update_channel_id, update_interval 
                    FROM activity_settings 
                    WHERE update_channel_id IS NOT NULL
                """)
                settings = cursor.fetchall()

            for guild_id, channel_id, interval in settings:
                # Check if it's time to update (simplified check)
                if now.minute % (interval // 60) == 0:  # Update based on interval
                    guild = self.bot.get_guild(int(guild_id))
                    if not guild:
                        continue
                        
                    channel = guild.get_channel(int(channel_id))
                    if not channel:
                        continue

                    # Generate activity summary
                    today = now.date().isoformat()
                    
                    with sqlite3.connect(DB_FILE) as conn:
                        # Get today's top users
                        cursor = conn.execute("""
                            SELECT user_id, messages, voice_time 
                            FROM daily_stats 
                            WHERE guild_id = ? AND date = ? 
                            ORDER BY (messages + voice_time/60) DESC 
                            LIMIT 5
                        """, (guild_id, today))
                        top_users = cursor.fetchall()

                    if top_users:
                        embed = discord.Embed(
                            title="📊 Daily Activity Update",
                            description="Here are today's most active members!",
                            color=discord.Color.blue(),
                            timestamp=now
                        )

                        activity_text = ""
                        for i, (user_id, messages, voice_time) in enumerate(top_users, 1):
                            user = guild.get_member(int(user_id))
                            if user:
                                emoji = "🥇" if i == 1 else "🥈" if i == 2 else "🥉" if i == 3 else "🔸"
                                activity_text += f"{emoji} {user.display_name}: {messages} msgs, {self.format_time(voice_time)}\n"

                        embed.add_field(name="🏆 Top Active Members Today", value=activity_text, inline=False)
                        embed.set_footer(text="Activity tracking powered by Aron Development™")

                        try:
                            await channel.send(embed=embed)
                        except discord.Forbidden:
                            pass  # No permission to send

        except Exception as e:
            print(f"Error in update_channels task: {e}")

    @update_channels.before_loop
    async def before_update_channels(self):
        await self.bot.wait_until_ready()

    def cog_unload(self):
        self.update_channels.cancel()

async def setup(bot):
    await bot.add_cog(ActivityTracker(bot))