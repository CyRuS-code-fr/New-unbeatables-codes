import discord
from discord.ext import commands
import sqlite3
import os
from datetime import datetime, timezone
from typing import Optional
from core import Cog, axon, Context

EMOJI_DOT = "<a:BlueDot:1364125472539021352>"
DB_FILE = "db/game_channels.db"

# Initialize database
async def init_game_channel_db():
    os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
    with sqlite3.connect(DB_FILE) as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS game_channels (
            guild_id TEXT,
            channel_id TEXT,
            channel_name TEXT,
            game_types TEXT DEFAULT 'all',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            created_by TEXT,
            PRIMARY KEY(guild_id, channel_id)
        );
        
        CREATE TABLE IF NOT EXISTS game_settings (
            guild_id TEXT PRIMARY KEY,
            strict_mode INTEGER DEFAULT 1,
            auto_create_channel INTEGER DEFAULT 0,
            default_channel_name TEXT DEFAULT 'games'
        );
        """)
        conn.commit()

# Game channel check decorator is now in utils/game_checks.py

class GameChannelConfig(Cog):
    """Game Channel Configuration System"""
    
    def __init__(self, client: axon):
        self.client = client
        self.client.loop.create_task(self.init_db())
    
    def help_custom(self):
        emoji = '🎮'
        label = 'Game Setup'
        description = 'Configure game channels and restrictions'
        return emoji, label, description
    
    async def init_db(self):
        await self.client.wait_until_ready()
        await init_game_channel_db()
    
    @commands.command(name="gamechannelsetup", aliases=["gsetup", "gamesetup", "setupgames"])
    @commands.has_permissions(manage_channels=True)
    async def game_channel_setup(self, ctx: Context):
        """Set up game channels for the server"""
        embed = discord.Embed(
            title="🎮 Game Channel Setup",
            description="Configure which channels can run game commands",
            color=discord.Color.blue(),
            timestamp=datetime.now(timezone.utc)
        )
        
        # Get current configuration
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                SELECT channel_id, channel_name FROM game_channels 
                WHERE guild_id = ?
            """, (str(ctx.guild.id),))
            game_channels = cursor.fetchall()
            
            cursor = conn.execute("""
                SELECT strict_mode FROM game_settings WHERE guild_id = ?
            """, (str(ctx.guild.id),))
            strict_result = cursor.fetchone()
            strict_mode = strict_result[0] if strict_result else 1
        
        if game_channels:
            channels_list = []
            for ch_id, ch_name in game_channels:
                channel = ctx.guild.get_channel(int(ch_id))
                if channel:
                    channels_list.append(f"• {channel.mention}")
            
            embed.add_field(
                name="📝 Current Game Channels",
                value="\n".join(channels_list) if channels_list else "None",
                inline=False
            )
        
        embed.add_field(
            name="🔧 Available Commands",
            value=f"""
{EMOJI_DOT} `addgamechannel #channel` - Add game channel
{EMOJI_DOT} `removegamechannel #channel` - Remove game channel  
{EMOJI_DOT} `gamechannels` - List all game channels
{EMOJI_DOT} `togglestrict` - Toggle strict mode
{EMOJI_DOT} `creategamechannel <name>` - Create new game channel
            """,
            inline=False
        )
        
        embed.add_field(
            name="⚙️ Current Settings",
            value=f"**Strict Mode**: {'Enabled' if strict_mode else 'Disabled'}",
            inline=False
        )
        
        embed.set_footer(text="Use the commands above to configure your game channels")
        await ctx.send(embed=embed)
    
    @commands.command(name="addgamechannel", aliases=["agc", "addgames"])
    @commands.has_permissions(manage_channels=True)
    async def add_game_channel(self, ctx: Context, channel: discord.TextChannel):
        """Add a channel to the game channels list"""
        with sqlite3.connect(DB_FILE) as conn:
            try:
                conn.execute("""
                    INSERT INTO game_channels (guild_id, channel_id, channel_name, created_by)
                    VALUES (?, ?, ?, ?)
                """, (str(ctx.guild.id), str(channel.id), channel.name, str(ctx.author.id)))
                conn.commit()
                
                embed = discord.Embed(
                    title="✅ Game Channel Added",
                    description=f"{channel.mention} has been added to the game channels list.",
                    color=discord.Color.green(),
                    timestamp=datetime.now(timezone.utc)
                )
                embed.set_footer(text=f"Added by {ctx.author.display_name}")
                await ctx.send(embed=embed)
                
            except sqlite3.IntegrityError:
                embed = discord.Embed(
                    title="❌ Channel Already Added",
                    description=f"{channel.mention} is already in the game channels list.",
                    color=discord.Color.red()
                )
                await ctx.send(embed=embed)
    
    @commands.command(name="removegamechannel", aliases=["rgc", "removegames"])
    @commands.has_permissions(manage_channels=True)
    async def remove_game_channel(self, ctx: Context, channel: discord.TextChannel):
        """Remove a channel from the game channels list"""
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                DELETE FROM game_channels WHERE guild_id = ? AND channel_id = ?
            """, (str(ctx.guild.id), str(channel.id)))
            
            if cursor.rowcount > 0:
                conn.commit()
                embed = discord.Embed(
                    title="✅ Game Channel Removed",
                    description=f"{channel.mention} has been removed from the game channels list.",
                    color=discord.Color.green(),
                    timestamp=datetime.now(timezone.utc)
                )
                embed.set_footer(text=f"Removed by {ctx.author.display_name}")
            else:
                embed = discord.Embed(
                    title="❌ Channel Not Found",
                    description=f"{channel.mention} was not in the game channels list.",
                    color=discord.Color.red()
                )
            
            await ctx.send(embed=embed)
    
    @commands.command(name="gamechannels", aliases=["gc", "listgames", "gameconfig"])
    async def list_game_channels(self, ctx: Context):
        """List all configured game channels"""
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                SELECT channel_id, channel_name, created_at, created_by FROM game_channels 
                WHERE guild_id = ? ORDER BY created_at
            """, (str(ctx.guild.id),))
            game_channels = cursor.fetchall()
            
            cursor = conn.execute("""
                SELECT strict_mode, auto_create_channel FROM game_settings WHERE guild_id = ?
            """, (str(ctx.guild.id),))
            settings_result = cursor.fetchone()
            strict_mode = settings_result[0] if settings_result else 1
            auto_create = settings_result[1] if settings_result else 0
        
        embed = discord.Embed(
            title="🎮 Game Channels Configuration",
            description="List of all configured game channels",
            color=discord.Color.blue(),
            timestamp=datetime.now(timezone.utc)
        )
        
        if game_channels:
            channels_info = []
            for ch_id, ch_name, created_at, created_by in game_channels:
                channel = ctx.guild.get_channel(int(ch_id))
                creator = ctx.guild.get_member(int(created_by)) if created_by else None
                
                if channel:
                    status = "✅ Active"
                    channel_text = channel.mention
                else:
                    status = "❌ Deleted"
                    channel_text = f"#{ch_name}"
                
                creator_text = creator.display_name if creator else "Unknown"
                channels_info.append(f"{channel_text} - {status}\n└ Added by: {creator_text}")
            
            embed.add_field(
                name="📝 Configured Channels",
                value="\n\n".join(channels_info),
                inline=False
            )
        else:
            embed.add_field(
                name="📝 Configured Channels",
                value="No game channels configured yet.",
                inline=False
            )
        
        embed.add_field(
            name="⚙️ Settings",
            value=f"""
**Strict Mode**: {'Enabled' if strict_mode else 'Disabled'}
**Auto Create**: {'Enabled' if auto_create else 'Disabled'}
            """,
            inline=False
        )
        
        embed.add_field(
            name="🔧 Management Commands",
            value=f"""
{EMOJI_DOT} `addgamechannel #channel` - Add game channel
{EMOJI_DOT} `removegamechannel #channel` - Remove game channel
{EMOJI_DOT} `togglestrict` - Toggle strict mode
{EMOJI_DOT} `creategamechannel <name>` - Create new channel
            """,
            inline=False
        )
        
        await ctx.send(embed=embed)
    
    @commands.command(name="togglestrict", aliases=["ts", "strictmode"])
    @commands.has_permissions(manage_channels=True)
    async def toggle_strict_mode(self, ctx: Context):
        """Toggle strict mode for game channels"""
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                SELECT strict_mode FROM game_settings WHERE guild_id = ?
            """, (str(ctx.guild.id),))
            result = cursor.fetchone()
            
            if result:
                new_mode = 0 if result[0] else 1
                conn.execute("""
                    UPDATE game_settings SET strict_mode = ? WHERE guild_id = ?
                """, (new_mode, str(ctx.guild.id)))
            else:
                new_mode = 0  # Default to disabled if no settings exist
                conn.execute("""
                    INSERT INTO game_settings (guild_id, strict_mode) VALUES (?, ?)
                """, (str(ctx.guild.id), new_mode))
            
            conn.commit()
        
        embed = discord.Embed(
            title="⚙️ Strict Mode Updated",
            description=f"Strict mode has been **{'enabled' if new_mode else 'disabled'}**.",
            color=discord.Color.green() if new_mode else discord.Color.orange(),
            timestamp=datetime.now(timezone.utc)
        )
        
        if new_mode:
            embed.add_field(
                name="🔒 Strict Mode Enabled",
                value="Game commands will only work in configured game channels.",
                inline=False
            )
        else:
            embed.add_field(
                name="🔓 Strict Mode Disabled", 
                value="Game commands will work in all channels.",
                inline=False
            )
        
        embed.set_footer(text=f"Changed by {ctx.author.display_name}")
        await ctx.send(embed=embed)
    
    @commands.command(name="creategamechannel", aliases=["cgc", "makegamechannel"])
    @commands.has_permissions(manage_channels=True)
    async def create_game_channel(self, ctx: Context, *, name: str = "games"):
        """Create a new game channel and add it to the configuration"""
        try:
            # Create the channel
            channel = await ctx.guild.create_text_channel(
                name=name,
                topic="🎮 Game commands are allowed in this channel",
                reason=f"Game channel created by {ctx.author}"
            )
            
            # Add to database
            with sqlite3.connect(DB_FILE) as conn:
                conn.execute("""
                    INSERT INTO game_channels (guild_id, channel_id, channel_name, created_by)
                    VALUES (?, ?, ?, ?)
                """, (str(ctx.guild.id), str(channel.id), channel.name, str(ctx.author.id)))
                conn.commit()
            
            embed = discord.Embed(
                title="✅ Game Channel Created",
                description=f"Successfully created {channel.mention} and added it to game channels.",
                color=discord.Color.green(),
                timestamp=datetime.now(timezone.utc)
            )
            embed.add_field(
                name="🎮 Channel Info",
                value=f"**Name**: {channel.name}\n**ID**: {channel.id}",
                inline=False
            )
            embed.set_footer(text=f"Created by {ctx.author.display_name}")
            await ctx.send(embed=embed)
            
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ Permission Error",
                description="I don't have permission to create channels.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
        except Exception as e:
            embed = discord.Embed(
                title="❌ Error",
                description=f"Failed to create channel: {str(e)}",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
    
    @commands.command(name="gamechannelhelp", aliases=["ghelp", "gch"])
    async def game_channel_help(self, ctx: Context):
        """Show help for game channel configuration"""
        embed = discord.Embed(
            title="🎮 Game Channel System Help",
            description="Complete guide to game channel configuration",
            color=discord.Color.blue(),
            timestamp=datetime.now(timezone.utc)
        )
        
        # Setup Commands
        embed.add_field(
            name="🔧 Setup Commands",
            value=f"""
{EMOJI_DOT} `gamechannelsetup` **(gsetup, gamesetup, setupgames)**
└ Show configuration overview

{EMOJI_DOT} `creategamechannel <name>` **(cgc, makegamechannel)**
└ Create new game channel
            """,
            inline=False
        )
        
        # Management Commands
        embed.add_field(
            name="⚙️ Management Commands",
            value=f"""
{EMOJI_DOT} `addgamechannel #channel` **(agc, addgames)**
└ Add channel to game channels

{EMOJI_DOT} `removegamechannel #channel` **(rgc, removegames)**
└ Remove channel from game channels

{EMOJI_DOT} `togglestrict` **(ts, strictmode)**
└ Toggle strict mode on/off
            """,
            inline=False
        )
        
        # Information Commands
        embed.add_field(
            name="📊 Information Commands",
            value=f"""
{EMOJI_DOT} `gamechannels` **(gc, listgames, gameconfig)**
└ List all configured game channels

{EMOJI_DOT} `gamechannelhelp` **(ghelp, gch)**
└ Show this help message
            """,
            inline=False
        )
        
        # How It Works
        embed.add_field(
            name="❓ How It Works",
            value=f"""
{EMOJI_DOT} **Strict Mode ON**: Games only work in configured channels
{EMOJI_DOT} **Strict Mode OFF**: Games work everywhere
{EMOJI_DOT} Configure multiple channels for different game types
{EMOJI_DOT} Automatic channel creation with proper setup
            """,
            inline=False
        )
        
        embed.set_footer(text="All aliases are shown in parentheses")
        await ctx.send(embed=embed)

async def setup(client):
    await client.add_cog(GameChannelConfig(client))