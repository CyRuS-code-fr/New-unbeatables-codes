import discord
from discord.ext import commands, tasks
import aiosqlite
import aiohttp
import os
from utils.Tools import *

DB_PATH = "db/vanity.db"

class VanityRoles(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize_db())
        self.vanity_checker.start()

    async def initialize_db(self):
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("""
                CREATE TABLE IF NOT EXISTS vanity_roles (
                    guild_id INTEGER,
                    vanity TEXT NOT NULL,
                    role_id INTEGER NOT NULL,
                    log_channel_id INTEGER NOT NULL,
                    current_status TEXT,
                    PRIMARY KEY (guild_id, vanity)
                )
            """)
            await db.commit()

            async with db.execute("PRAGMA table_info(vanity_roles)") as cursor:
                columns = await cursor.fetchall()
                column_names = [column[1] for column in columns]

            if "current_status" not in column_names:
                await db.execute("ALTER TABLE vanity_roles ADD COLUMN current_status TEXT")
                await db.commit()

    @commands.group(name="vanityroles", invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    async def vanityroles(self, ctx):
        await ctx.send("❗ Usage: `vanityroles setup <vanity> <@role> <#channel>`, `vanityroles show`, `vanityroles reset`")

    @vanityroles.command(name="setup")
    @blacklist_check()
    @ignore_check()
    async def setup(self, ctx, vanity: str, role: discord.Role, channel: discord.TextChannel):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("""
                INSERT OR REPLACE INTO vanity_roles (guild_id, vanity, role_id, log_channel_id, current_status)
                VALUES (?, ?, ?, ?, NULL)
            """, (ctx.guild.id, vanity.lower(), role.id, channel.id))
            await db.commit()
        embed = discord.Embed(
            title="✅ Vanity Role Setup",
            description=f"Vanity: `{vanity}`\nRole: {role.mention}\nLog Channel: {channel.mention}",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

    @vanityroles.command(name="show")
    @blacklist_check()
    @ignore_check()
    async def show(self, ctx):
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT vanity, role_id, log_channel_id FROM vanity_roles WHERE guild_id = ?", (ctx.guild.id,)) as cursor:
                rows = await cursor.fetchall()

        if not rows:
            return await ctx.send("❌ No vanity role setups found.")

        embed = discord.Embed(title="🔧 Vanity Role Settings", color=discord.Color.blue())
        for vanity, role_id, log_channel_id in rows:
            role = ctx.guild.get_role(role_id)
            channel = ctx.guild.get_channel(log_channel_id)
            embed.add_field(
                name=f"Vanity: `{vanity}`",
                value=f"Role: {role.mention if role else role_id}\nLog: {channel.mention if channel else log_channel_id}",
                inline=False
            )
        await ctx.send(embed=embed)

    @vanityroles.command(name="reset")
    @blacklist_check()
    @ignore_check()
    async def reset(self, ctx):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("DELETE FROM vanity_roles WHERE guild_id = ?", (ctx.guild.id,))
            await db.commit()
        await ctx.send("✅ All vanity role configurations have been reset.")

    @tasks.loop(seconds=15)
    async def vanity_checker(self):
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("SELECT guild_id, vanity, role_id, log_channel_id, current_status FROM vanity_roles") as cursor:
                rows = await cursor.fetchall()
        
        rows_list = list(rows)

        for guild_id, vanity, role_id, log_channel_id, current_status in rows_list:
            guild = self.bot.get_guild(guild_id)
            if not guild:
                continue

            role = guild.get_role(role_id)
            log_channel = guild.get_channel(log_channel_id)
            
            # Ensure all members are loaded
            try:
                await guild.chunk()
            except Exception:
                pass
            
            # Check permissions before attempting role operations
            if not guild.me.guild_permissions.manage_roles:
                if log_channel:
                    await log_channel.send(f"❌ Missing 'Manage Roles' permission for vanity `{vanity}`")
                continue
            
            if role and role >= guild.me.top_role:
                if log_channel:
                    await log_channel.send(f"❌ Role `{role.name}` is higher than bot's role for vanity `{vanity}`")
                continue

            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(f"https://discord.com/api/v10/invites/{vanity}") as response:
                        is_active = response.status == 200
            except Exception:
                continue

            if is_active:
                await self.update_status(guild_id, vanity, "active")
                assigned = 0
                removed = 0
                failed = 0
                
                for member in guild.members:
                    # Check if member has vanity in their status/bio
                    has_vanity_in_status = self.check_member_status(member, vanity)
                    
                    if has_vanity_in_status and role and role not in member.roles:
                        # Add role if member has vanity in status but doesn't have role
                        try:
                            await member.add_roles(role, reason="Vanity in status")
                            assigned += 1
                        except Exception as e:
                            failed += 1
                            if log_channel:
                                await log_channel.send(f"⚠️ Failed to assign role to {member.mention}: {str(e)[:100]}")
                    
                    elif not has_vanity_in_status and role and role in member.roles:
                        # Remove role if member doesn't have vanity in status but has role
                        try:
                            await member.remove_roles(role, reason="Vanity not in status")
                            removed += 1
                        except Exception:
                            pass
                
                if log_channel and (assigned > 0 or removed > 0):
                    await log_channel.send(f"🔄 Vanity `{vanity}` roles updated. Added: {assigned}, Removed: {removed}")

            elif not is_active and current_status == "active":
                await self.update_status(guild_id, vanity, None)
                removed = 0
                for member in guild.members:
                    if role and role in member.roles:
                        try:
                            await member.remove_roles(role, reason="Vanity inactive")
                            removed += 1
                        except Exception:
                            pass
                if log_channel and removed > 0:
                    await log_channel.send(f"❌ Vanity `{vanity}` is now **inactive**. Role removed from {removed} members.")

    def check_member_status(self, member, vanity):
        """Check if member has vanity URL in their status/activities"""
        # Check custom status
        for activity in member.activities:
            if activity.type == discord.ActivityType.custom:
                if activity.state and vanity.lower() in activity.state.lower():
                    return True
                if activity.name and vanity.lower() in activity.name.lower():
                    return True
            # Check other activity types (playing, watching, etc.)
            elif hasattr(activity, 'name') and activity.name:
                if vanity.lower() in activity.name.lower():
                    return True
            elif hasattr(activity, 'details') and activity.details:
                if vanity.lower() in activity.details.lower():
                    return True
        return False

    async def update_status(self, guild_id, vanity, new_status):
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("""
                UPDATE vanity_roles SET current_status = ? WHERE guild_id = ? AND vanity = ?
            """, (new_status, guild_id, vanity))
            await db.commit()

    @vanity_checker.before_loop
    async def before_checker(self):
        await self.bot.wait_until_ready()

async def setup(bot):
    await bot.add_cog(VanityRoles(bot))
