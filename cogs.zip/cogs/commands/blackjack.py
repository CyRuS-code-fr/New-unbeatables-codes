import discord
from discord.ext import commands
import os
import random
import asyncio
from typing import List, Tuple, Union, Dict
from PIL import Image, ImageDraw, ImageFont
from utils.Tools import *

CARDS_PATH = 'data/cards/'

class Card:
    suits = ["clubs", "diamonds", "hearts", "spades"]

    def __init__(self, suit: str, value: int, down=False):
        self.suit = suit
        self.value = value
        self.down = down
        self.symbol = self.name[0].upper()

    @property
    def name(self) -> str:
        if self.value <= 10:
            return str(self.value)
        else:
            return {
                11: 'jack',
                12: 'queen',
                13: 'king',
                14: 'ace',
            }[self.value]

    @property
    def image(self):
        return (
            f"{self.symbol if self.name != '10' else '10'}" \
            f"{self.suit[0].upper()}.png" \
            if not self.down else "red_back.png"
        )

    def flip(self):
        self.down = not self.down
        return self

    def __str__(self) -> str:
        return f'{self.name.title()} of {self.suit.title()}'

    def __repr__(self) -> str:
        return str(self)


class Blackjack(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @staticmethod
    def hand_to_images(hand: List[Card]) -> List[Image.Image]:
        return [Image.open(os.path.join(CARDS_PATH, card.image)) for card in hand]

    @staticmethod
    def center(*hands: List[Image.Image]) -> Image.Image:
        bg: Image.Image = Image.open(os.path.join(CARDS_PATH, 'table.png'))
        bg_center_x = bg.size[0] // 2
        bg_center_y = bg.size[1] // 2

        img_w = hands[0][0].size[0]
        img_h = hands[0][0].size[1]

        start_y = bg_center_y - (((len(hands) * img_h) + ((len(hands) - 1) * 15)) // 2)

        for hand in hands:
            start_x = bg_center_x - (((len(hand) * img_w) + ((len(hand) - 1) * 10)) // 2)
            for card in hand:
                bg.alpha_composite(card, (start_x, start_y))
                start_x += img_w + 10
            start_y += img_h + 15

        return bg

    def output(self, name, *hands: List[Card]) -> None:
        hand_images = [self.hand_to_images(hand) for hand in hands]
        self.center(*hand_images).save(f'data/{name}.png')

    @staticmethod
    def calc_hand(hand: List[Card]) -> int:
        non_aces = [c for c in hand if c.symbol != 'A']
        aces = [c for c in hand if c.symbol == 'A']
        total_sum = 0
        for card in non_aces:
            if not card.down:
                if card.symbol in 'JQK':
                    total_sum += 10
                else:
                    total_sum += card.value
        for card in aces:
            if not card.down:
                if total_sum <= 10:
                    total_sum += 11
                else:
                    total_sum += 1
        return total_sum

    @commands.command(aliases=['bj', 'blackjacks'], help="Play blackjack alone or with up to 4 players total.", usage="blackjack [@user1] [@user2] [@user3]")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def blackjack(self, ctx: commands.Context, *mentioned_users: discord.Member):
        try:
            # Setup players (author + mentioned users, max 4 total)
            all_players = [ctx.author] + list(mentioned_users)
            if len(all_players) > 4:
                await ctx.send(embed=discord.Embed(description="❌ Maximum 4 players allowed!", color=discord.Color.red()))
                return
            
            # Remove duplicates and filter out bots while preserving order
            players = []
            for player in all_players:
                if player not in players and not player.bot:
                    players.append(player)
                elif player.bot and player != ctx.author:
                    await ctx.send(embed=discord.Embed(description=f"❌ Cannot add bot {player.display_name} to the game!", color=discord.Color.red()))
                    return
            
            if len(players) == 1:
                # Single player mode
                await self.single_player_blackjack(ctx)
                return
            else:
                # Multiplayer mode
                await self.multiplayer_blackjack(ctx, players)
                return
        except Exception as e:
            print(e)
            
    async def multiplayer_blackjack(self, ctx: commands.Context, players: List[discord.Member]):
        """Multiplayer blackjack game for up to 4 players"""
        try:
            deck = [Card(suit, num) for num in range(2, 15) for suit in Card.suits]
            random.shuffle(deck)
            
            # Initialize hands for all players and dealer
            player_hands: Dict[discord.Member, List[Card]] = {}
            dealer_hand: List[Card] = []
            player_standing: Dict[discord.Member, bool] = {}
            player_results: Dict[discord.Member, str] = {}
            
            # Deal initial cards
            for player in players:
                player_hands[player] = [deck.pop(), deck.pop()]
                player_standing[player] = False
                
            dealer_hand = [deck.pop(), deck.pop()]
            dealer_hand[1] = dealer_hand[1].flip()  # Hide dealer's second card
            
            # Create multiplayer visualization function
            async def create_multiplayer_visual() -> discord.Message:
                game_id = f"mp_{ctx.message.id}"
                self.create_multiplayer_image(game_id, players, player_hands, dealer_hand)
                
                embed = discord.Embed(
                    title="🃏 Multiplayer Blackjack",
                    description=self.get_game_status(players, player_hands, dealer_hand, player_standing),
                    color=discord.Color.blue()
                )
                
                file = discord.File(f"data/{game_id}.png", filename=f"{game_id}.png")
                embed.set_image(url=f"attachment://{game_id}.png")
                msg = await ctx.send(file=file, embed=embed)
                return msg
                
            # Player turns
            for player in players:
                if self.calc_hand(player_hands[player]) == 21:
                    player_standing[player] = True
                    player_results[player] = "Blackjack! 🎉"
                    continue
                    
                while not player_standing[player]:
                    current_score = self.calc_hand(player_hands[player])
                    
                    if current_score > 21:
                        player_standing[player] = True
                        player_results[player] = "Bust! 💥"
                        break
                        
                    msg = await create_multiplayer_visual()
                    
                    # Add turn indicator
                    embed = msg.embeds[0]
                    if embed.description is None:
                        embed.description = ""
                    embed.description += f"\n\n**{player.display_name}'s Turn**"
                    embed.description += f"\nYour hand: {current_score}"
                    embed.description += "\n🇭 = Hit | 🇸 = Stand"
                    await msg.edit(embed=embed)
                    
                    await msg.add_reaction("🇭")
                    await msg.add_reaction("🇸")
                    
                    def check(reaction, user):
                        return (
                            str(reaction.emoji) in ("🇭", "🇸") and
                            user == player and
                            reaction.message == msg
                        )
                    
                    try:
                        reaction, _ = await self.bot.wait_for('reaction_add', timeout=30, check=check)
                    except asyncio.TimeoutError:
                        player_standing[player] = True
                        player_results[player] = "Timeout ⏰"
                        await msg.delete()
                        break
                        
                    if str(reaction.emoji) == "🇭":
                        player_hands[player].append(deck.pop())
                        await msg.delete()
                    elif str(reaction.emoji) == "🇸":
                        player_standing[player] = True
                        await msg.delete()
                        break
            
            # Dealer's turn
            dealer_hand[1] = dealer_hand[1].flip()  # Reveal dealer's card
            dealer_score = self.calc_hand(dealer_hand)
            
            while dealer_score < 17:
                dealer_hand.append(deck.pop())
                dealer_score = self.calc_hand(dealer_hand)
            
            # Calculate final results
            for player in players:
                if player in player_results:  # Already has result (blackjack/bust/timeout)
                    continue
                    
                player_score = self.calc_hand(player_hands[player])
                
                if dealer_score > 21:
                    player_results[player] = "Won! 🎉 (Dealer bust)"
                elif dealer_score == player_score:
                    player_results[player] = "Tie! 🤝"
                elif dealer_score > player_score:
                    player_results[player] = "Lost! 😔"
                else:
                    player_results[player] = "Won! 🎉"
            
            # Final results - delete old message and send new one with results
            try:
                final_msg = await create_multiplayer_visual()
                await final_msg.delete()
            except:
                pass
            
            # Create final results image and send new message
            game_id = f"mp_{ctx.message.id}"
            self.create_multiplayer_image(game_id, players, player_hands, dealer_hand)
            
            final_embed = discord.Embed(
                title="🎯 Final Results",
                description=self.get_final_results(players, player_hands, dealer_hand, player_results),
                color=discord.Color.green()
            )
            
            file = discord.File(f"data/{game_id}.png", filename=f"{game_id}.png")
            final_embed.set_image(url=f"attachment://{game_id}.png")
            
            await ctx.send(embed=final_embed, file=file)
            
            # Cleanup
            os.remove(f"data/{game_id}.png")
            
        except Exception as e:
            print(f"Multiplayer blackjack error: {e}")
            await ctx.send(embed=discord.Embed(description="❌ An error occurred during the game.", color=discord.Color.red()))
    
    def create_multiplayer_image(self, game_id: str, players: List[discord.Member], 
                               player_hands: Dict[discord.Member, List[Card]], 
                               dealer_hand: List[Card]) -> None:
        """Create multiplayer game visualization"""
        try:
            # Calculate image dimensions based on number of players
            card_width, card_height = 120, 160
            spacing = 20
            
            # Base image size
            base_width = 800
            base_height = 200 + (len(players) * (card_height + spacing))
            
            # Create background
            bg = Image.new('RGBA', (base_width, base_height), color=(34, 139, 34))  # Green background
            
            # Try to load table background if available
            try:
                table_bg = Image.open(os.path.join(CARDS_PATH, 'table.png'))
                table_bg = table_bg.resize((base_width, base_height))
                bg = table_bg.convert('RGBA')
            except:
                pass  # Use solid green if table.png not found
            
            # Draw dealer hand at top
            dealer_y = 20
            dealer_x = (base_width - (len(dealer_hand) * (card_width + 10))) // 2
            
            for i, card in enumerate(dealer_hand):
                try:
                    card_img = Image.open(os.path.join(CARDS_PATH, card.image))
                    card_img = card_img.resize((card_width, card_height))
                    bg.paste(card_img, (dealer_x + (i * (card_width + 10)), dealer_y))
                except:
                    # Fallback: draw a rectangle if card image not found
                    draw = ImageDraw.Draw(bg)
                    draw.rectangle([
                        dealer_x + (i * (card_width + 10)), dealer_y,
                        dealer_x + (i * (card_width + 10)) + card_width, dealer_y + card_height
                    ], fill='white', outline='black')
            
            # Draw player hands
            for idx, player in enumerate(players):
                player_y = 200 + (idx * (card_height + spacing))
                hand = player_hands[player]
                player_x = (base_width - (len(hand) * (card_width + 10))) // 2
                
                for i, card in enumerate(hand):
                    try:
                        card_img = Image.open(os.path.join(CARDS_PATH, card.image))
                        card_img = card_img.resize((card_width, card_height))
                        bg.paste(card_img, (player_x + (i * (card_width + 10)), player_y))
                    except:
                        # Fallback: draw a rectangle if card image not found
                        draw = ImageDraw.Draw(bg)
                        draw.rectangle([
                            player_x + (i * (card_width + 10)), player_y,
                            player_x + (i * (card_width + 10)) + card_width, player_y + card_height
                        ], fill='white', outline='black')
            
            # Save the image
            bg.save(f'data/{game_id}.png')
            
        except Exception as e:
            print(f"Error creating multiplayer image: {e}")
            # Create a simple fallback image
            bg = Image.new('RGBA', (800, 400), color=(34, 139, 34))
            bg.save(f'data/{game_id}.png')
    
    def get_game_status(self, players: List[discord.Member], 
                       player_hands: Dict[discord.Member, List[Card]], 
                       dealer_hand: List[Card], 
                       player_standing: Dict[discord.Member, bool]) -> str:
        """Get current game status text"""
        status = f"**🃏 Dealer:** {self.calc_hand(dealer_hand)}\n\n"
        
        for i, player in enumerate(players):
            score = self.calc_hand(player_hands[player])
            standing_status = "✅ Standing" if player_standing[player] else "🎯 Playing"
            status += f"**{i+1}. {player.display_name}:** {score} - {standing_status}\n"
        
        return status
    
    def get_final_results(self, players: List[discord.Member], 
                         player_hands: Dict[discord.Member, List[Card]], 
                         dealer_hand: List[Card], 
                         player_results: Dict[discord.Member, str]) -> str:
        """Get final results text"""
        results = f"**🃏 Dealer:** {self.calc_hand(dealer_hand)}\n\n"
        
        for i, player in enumerate(players):
            score = self.calc_hand(player_hands[player])
            result = player_results.get(player, "Unknown")
            results += f"**{i+1}. {player.display_name}:** {score} - {result}\n"
        
        return results
    
    async def single_player_blackjack(self, ctx: commands.Context):
        """Original single player blackjack game"""
        try:
            deck = [Card(suit, num) for num in range(2, 15) for suit in Card.suits]
            random.shuffle(deck)

            player_hand: List[Card] = []
            dealer_hand: List[Card] = []

            player_hand.append(deck.pop())
            dealer_hand.append(deck.pop())
            player_hand.append(deck.pop())
            dealer_hand.append(deck.pop())

            dealer_hand[1] = dealer_hand[1].flip() 

            # Implementation for single player blackjack game
            async def out_table(**kwargs) -> discord.Message:
                self.output(ctx.author.id, dealer_hand, player_hand)
                embed = discord.Embed(**kwargs)
                file = discord.File(f"data/{ctx.author.id}.png", filename=f"{ctx.author.id}.png")
                embed.set_image(url=f"attachment://{ctx.author.id}.png")
                msg: discord.Message = await ctx.send(file=file, embed=embed)
                return msg

            def check(reaction: discord.Reaction, user: Union[discord.Member, discord.User]) -> bool:
                return all((
                    str(reaction.emoji) in ("🇸", "🇭"),
                    user == ctx.author,
                    user != self.bot.user,
                    reaction.message == msg
                ))

            standing = False
            msg = None
            result = ("Unknown", 'unknown')  # Initialize result variable

            while True:
                player_score = self.calc_hand(player_hand)
                dealer_score = self.calc_hand(dealer_hand)

                if player_score == 21:  
                    result = ("Blackjack!", 'won')
                    break

                elif player_score > 21: 
                    result = ("Player busts", 'lost')
                    break

                msg = await out_table(
                    title="Your Turn",
                    description=f"Your hand: {player_score}\nDealer's hand: {dealer_score}"
                )

                await msg.add_reaction("🇭")
                await msg.add_reaction("🇸")

                try:
                    reaction, _ = await self.bot.wait_for('reaction_add', timeout=60, check=check)
                except asyncio.TimeoutError:
                    await msg.delete()
                    return

                if str(reaction.emoji) == "🇭":
                    player_hand.append(deck.pop())
                    await msg.delete()
                    continue

                elif str(reaction.emoji) == "🇸":
                    standing = True
                    break

            if standing:
                dealer_hand[1] = dealer_hand[1].flip()  
                player_score = self.calc_hand(player_hand)
                dealer_score = self.calc_hand(dealer_hand)

                while dealer_score < 17:
                    dealer_hand.append(deck.pop())
                    dealer_score = self.calc_hand(dealer_hand)

                if dealer_score == 21:
                    result = ('Dealer blackjack', 'lost')
                elif dealer_score > 21:
                    result = ("Dealer busts", 'won')
                elif dealer_score == player_score:
                    result = ("Tie!", 'kept')
                elif dealer_score > player_score:
                    result = ("You lose!", 'lost')
                elif dealer_score < player_score:
                    result = ("You win!", 'won')
                else:
                    result = ("Game ended", 'kept')  # Fallback case

            color = (
                discord.Color.red() if result[1] == 'lost'
                else discord.Color.green() if result[1] == 'won'
                else discord.Color.blue()
            )
            try:
                if msg:
                    await msg.delete()
            except:
                pass
            msg = await out_table(
                title=result[0],
                color=color,
                description=(
                    f"**You {result[1]}**\nYour hand: {player_score}\n" +
                    f"Dealer's hand: {dealer_score}"
                )
            )
            os.remove(f'data/{ctx.author.id}.png')
        except Exception as e:
            print(f"Single player blackjack error: {e}")
            await ctx.send(embed=discord.Embed(description="❌ An error occurred during the game.", color=discord.Color.red()))


"""
@Author: Sonu Jana
    + Discord: me.sonu
    + Community: https://discord.gg/odx (Olympus Development)
    + for any queries reach out support or DM me.
"""