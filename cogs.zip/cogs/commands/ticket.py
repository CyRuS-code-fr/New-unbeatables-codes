import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import io
import sqlite3
import os
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List

EMOJI_DOT = "<a:BlueDot:1364125472539021352>"  # Replace with your emoji

ticket_counter = 0
DB_FILE = "db/tickets.db"

# Ticket priorities
TICKET_PRIORITIES = {
    "🔴": "High",
    "🟡": "Medium", 
    "🟢": "Low"
}

# Ticket categories
TICKET_CATEGORIES = {
    "💬": "General Support",
    "🐛": "Bug Report",
    "💡": "Feature Request",
    "❓": "Question",
    "⚠️": "Technical Issue"
}

# Initialize database
async def init_ticket_db():
    os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
    with sqlite3.connect(DB_FILE) as conn:
        # Create the table with all required columns
        conn.execute("""
        CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id TEXT,
            channel_id TEXT,
            creator_id TEXT,
            staff_id TEXT,
            ticket_type TEXT,
            priority TEXT DEFAULT 'Medium',
            category TEXT DEFAULT 'General Support',
            status TEXT DEFAULT 'open',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            closed_at TIMESTAMP,
            transcript TEXT,
            rating INTEGER,
            feedback TEXT
        )
        """)
        
        # Check existing columns and add missing ones (for existing tables)
        cursor = conn.execute("PRAGMA table_info(tickets)")
        columns = [column[1] for column in cursor.fetchall()]
        
        # Add missing columns if they don't exist
        missing_columns = {
            'priority': 'TEXT DEFAULT "Medium"',
            'category': 'TEXT DEFAULT "General Support"', 
            'rating': 'INTEGER',
            'feedback': 'TEXT',
            'transcript': 'TEXT',
            'closed_at': 'TIMESTAMP'
        }
        
        for column_name, column_def in missing_columns.items():
            if column_name not in columns:
                try:
                    conn.execute(f"ALTER TABLE tickets ADD COLUMN {column_name} {column_def}")
                    print(f"Added missing column: {column_name}")
                except sqlite3.OperationalError as e:
                    print(f"Error adding column {column_name}: {e}")
        
        conn.commit()
        
        conn.executescript("""
        
        -- Add category column if it doesn't exist
        PRAGMA table_info(tickets);
        
        CREATE TABLE IF NOT EXISTS ticket_settings (
            guild_id TEXT PRIMARY KEY,
            category_id TEXT,
            log_channel_id TEXT,
            staff_role_id TEXT,
            auto_close_time INTEGER DEFAULT 24,
            max_tickets_per_user INTEGER DEFAULT 3,
            enable_ratings BOOLEAN DEFAULT 1,
            enable_transcripts BOOLEAN DEFAULT 1
        );
        
        CREATE TABLE IF NOT EXISTS ticket_templates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id TEXT,
            name TEXT,
            content TEXT,
            category TEXT
        );
        """)
        conn.commit()

class EmbedEditModal(discord.ui.Modal, title="Edit Ticket Embed"):
    def __init__(self, view):
        super().__init__()
        self.view = view

        self.title_input = discord.ui.TextInput(label="Embed Title", required=False)
        self.description_input = discord.ui.TextInput(label="Description", required=False, style=discord.TextStyle.paragraph)
        self.color_input = discord.ui.TextInput(label="Color (Hex, e.g. #3498db)", required=False)
        self.image_input = discord.ui.TextInput(label="Image URL", required=False)

        self.add_item(self.title_input)
        self.add_item(self.description_input)
        self.add_item(self.color_input)
        self.add_item(self.image_input)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            color = int(self.color_input.value.replace("#", ""), 16) if self.color_input.value else 0x2B2D31
        except:
            color = 0x2B2D31

        embed = discord.Embed(
            title=self.title_input.value or "Support Ticket",
            description=self.description_input.value or "Select an option below to open a ticket.",
            color=color
        )

        if self.image_input.value:
            embed.set_image(url=self.image_input.value)

        self.view.embed = embed
        await interaction.response.edit_message(embed=embed, view=self.view)

class AddOptionModal(discord.ui.Modal, title="Add Ticket Option"):
    def __init__(self, view):
        super().__init__()
        self.view = view

        self.option_name = discord.ui.TextInput(label="Option Name", required=True)
        self.option_emoji = discord.ui.TextInput(label="Emoji (e.g. :ticket: or emoji ID)", required=True)
        self.staff_role = discord.ui.TextInput(label="Staff Role ID", required=True)

        self.add_item(self.option_name)
        self.add_item(self.option_emoji)
        self.add_item(self.staff_role)

    async def on_submit(self, interaction: discord.Interaction):
        emoji = discord.PartialEmoji.from_str(self.option_emoji.value)
        self.view.options.append({
            "label": self.option_name.value,
            "emoji": emoji,
            "staff_role": int(self.staff_role.value)
        })
        await interaction.response.edit_message(content="Option added.", embed=self.view.embed, view=self.view)

class AddUserModal(discord.ui.Modal, title="Add User to Ticket"):
    def __init__(self, channel: discord.TextChannel):
        super().__init__()
        self.channel = channel
        
        self.user_input = discord.ui.TextInput(label="User ID or @mention", required=True)
        self.add_item(self.user_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        if not interaction.guild:
            await interaction.response.send_message("❌ This command can only be used in a server.", ephemeral=True)
            return
            
        try:
            # Try to get user by ID or mention
            user_id = self.user_input.value.strip().replace('<@', '').replace('>', '').replace('!', '')
            user = interaction.guild.get_member(int(user_id))
            
            if user and isinstance(self.channel, discord.TextChannel):
                # Add user to ticket channel
                overwrites = self.channel.overwrites
                overwrites[user] = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)
                await self.channel.edit(overwrites=overwrites)
                
                # Send confirmation
                add_embed = discord.Embed(
                    title="👥 User Added",
                    description=f"{user.mention} has been added to this ticket.",
                    color=discord.Color.blue(),
                    timestamp=datetime.now(timezone.utc)
                )
                await self.channel.send(embed=add_embed)
                await interaction.response.send_message(f"Added {user.mention} to the ticket.", ephemeral=True)
            else:
                await interaction.response.send_message("❌ User not found. Please check the ID or mention.", ephemeral=True)
        except ValueError:
            await interaction.response.send_message("❌ Invalid user ID format.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error adding user: {str(e)}", ephemeral=True)

class TicketSetupView(discord.ui.View):
    def __init__(self, bot, author):
        super().__init__(timeout=300)
        self.bot = bot
        self.author = author
        self.embed = discord.Embed(title="Ticket Panel", description="Select an option to open a ticket.", color=0x2B2D31)
        self.options = []
        self.channel = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        return interaction.user.id == self.author.id

    @discord.ui.select(
        placeholder="Select an action",
        min_values=1,
        max_values=1,
        options=[
            discord.SelectOption(label="Embed Edit", value="embed_edit", emoji="📝"),
            discord.SelectOption(label="Add Option", value="add_option", emoji="➕"),
            discord.SelectOption(label="Send Embed", value="send_embed", emoji="📨"),
        ]
    )
    async def menu(self, interaction: discord.Interaction, select: discord.ui.Select):
        value = select.values[0]

        if value == "embed_edit":
            await interaction.response.send_modal(EmbedEditModal(self))

        elif value == "add_option":
            await interaction.response.send_modal(AddOptionModal(self))

        elif value == "send_embed":
            await interaction.response.send_message("Mention the channel to send the ticket panel.", ephemeral=True)

            def check(m):
                return m.author.id == interaction.user.id and m.channel == interaction.channel

            try:
                msg = await self.bot.wait_for("message", check=check, timeout=30)
                if msg.channel_mentions:
                    self.channel = msg.channel_mentions[0]
                    await self.send_panel(interaction)
                else:
                    await interaction.followup.send("No channel mentioned.", ephemeral=True)
            except asyncio.TimeoutError:
                await interaction.followup.send("Timeout. Please try again.", ephemeral=True)

    async def send_panel(self, interaction: discord.Interaction):
        if not self.channel:
            await interaction.followup.send("❌ No channel specified.", ephemeral=True)
            return
            
        if not self.options:
            await interaction.followup.send("❌ No ticket options configured.", ephemeral=True)
            return

        global ticket_counter

        select = discord.ui.Select(
            placeholder="Select a ticket type",
            options=[
                discord.SelectOption(label=opt["label"], value=opt["label"], emoji=opt["emoji"])
                for opt in self.options
            ]
        )

        async def ticket_callback(ticket_interaction: discord.Interaction):
            if not ticket_interaction.guild:
                await ticket_interaction.response.send_message("❌ This can only be used in a server.", ephemeral=True)
                return
                
            if not hasattr(ticket_interaction, 'data') or not ticket_interaction.data:
                await ticket_interaction.response.send_message("❌ Invalid interaction data.", ephemeral=True)
                return
                
            values = ticket_interaction.data.get('values')
            if not values:
                await ticket_interaction.response.send_message("❌ No option selected.", ephemeral=True)
                return
                
            global ticket_counter
            selected_label = values[0]
            ticket_counter += 1
            option = next((opt for opt in self.options if opt["label"] == selected_label), None)

            if option is None:
                await ticket_interaction.response.send_message("❌ Option not found.", ephemeral=True)
                return

            guild = ticket_interaction.guild
            role = guild.get_role(option["staff_role"]) if guild else None
            
            overwrites = {
                guild.default_role: discord.PermissionOverwrite(view_channel=False),
                ticket_interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
                guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True, manage_channels=True)
            }
            
            if role:
                overwrites[role] = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)

            try:
                ticket_channel = await guild.create_text_channel(
                    name=f"{selected_label.lower().replace(' ', '-')}-{ticket_counter}",
                    overwrites=overwrites,
                    reason="New support ticket"
                )

                # Save to database
                with sqlite3.connect(DB_FILE) as conn:
                    conn.execute("""
                        INSERT INTO tickets (guild_id, channel_id, creator_id, ticket_type, category, status)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (str(guild.id), str(ticket_channel.id), str(ticket_interaction.user.id), selected_label, 'General Support', 'open'))
                    conn.commit()

                ticket_embed = discord.Embed(
                    title=f"🎫 {selected_label} Ticket",
                    description=f"Welcome {ticket_interaction.user.mention}! Please describe your issue and our team will assist you shortly.",
                    color=discord.Color.blurple(),
                    timestamp=datetime.now(timezone.utc)
                )
                ticket_embed.add_field(name="Ticket ID", value=f"#{ticket_counter}", inline=True)
                ticket_embed.add_field(name="Category", value=selected_label, inline=True)
                ticket_embed.add_field(name="Status", value="🟢 Open", inline=True)

                view = TicketView(ticket_interaction.user, ticket_counter)
                await ticket_channel.send(
                    content=f"{ticket_interaction.user.mention} {role.mention if role else ''}",
                    embed=ticket_embed,
                    view=view
                )
                await ticket_interaction.response.send_message(f"✅ Ticket created: {ticket_channel.mention}", ephemeral=True)
                
            except Exception as e:
                await ticket_interaction.response.send_message(f"❌ Error creating ticket: {str(e)}", ephemeral=True)

        select.callback = ticket_callback

        view = discord.ui.View()
        view.add_item(select)
        await self.channel.send(embed=self.embed, view=view)
        await interaction.followup.send("✅ Ticket panel sent!", ephemeral=True)

class TicketView(discord.ui.View):
    def __init__(self, creator, ticket_id=None):
        super().__init__(timeout=None)
        self.creator = creator
        self.claimed = False
        self.ticket_id = ticket_id

    @discord.ui.button(label="📌 Claim", style=discord.ButtonStyle.primary)
    async def claim(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not isinstance(interaction.channel, discord.TextChannel):
            await interaction.response.send_message("❌ This can only be used in text channels.", ephemeral=True)
            return
            
        if self.claimed:
            await interaction.response.send_message("❌ This ticket is already claimed.", ephemeral=True)
        else:
            self.claimed = True
            
            # Update database
            with sqlite3.connect(DB_FILE) as conn:
                conn.execute("UPDATE tickets SET staff_id = ? WHERE channel_id = ?", 
                           (str(interaction.user.id), str(interaction.channel.id)))
                conn.commit()
            
            # Create claim embed
            claim_embed = discord.Embed(
                title="🎫 Ticket Claimed",
                description=f"{interaction.user.mention} has claimed this ticket and will be handling your request.",
                color=discord.Color.green(),
                timestamp=datetime.now(timezone.utc)
            )
            claim_embed.set_footer(text=f"Claimed by {interaction.user.display_name}", icon_url=interaction.user.display_avatar.url)
            
            await interaction.channel.send(embed=claim_embed)
            await interaction.response.send_message("✅ You have successfully claimed this ticket.", ephemeral=True)

    @discord.ui.button(label="👥 Add User", style=discord.ButtonStyle.secondary)
    async def add_user(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not isinstance(interaction.channel, discord.TextChannel):
            await interaction.response.send_message("❌ This can only be used in text channels.", ephemeral=True)
            return
        await interaction.response.send_modal(AddUserModal(interaction.channel))

    @discord.ui.button(label="🔒 Lock", style=discord.ButtonStyle.secondary)
    async def lock_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not isinstance(interaction.channel, discord.TextChannel) or not interaction.guild:
            await interaction.response.send_message("❌ This can only be used in server text channels.", ephemeral=True)
            return
            
        # Lock the ticket (remove send_messages permission for creator)
        overwrites = interaction.channel.overwrites
        creator = interaction.guild.get_member(self.creator.id)
        
        if creator and creator in overwrites:
            overwrites[creator].send_messages = False
            await interaction.channel.edit(overwrites=overwrites)
            
            lock_embed = discord.Embed(
                title="🔒 Ticket Locked",
                description=f"This ticket has been locked by {interaction.user.mention}. The creator can no longer send messages.",
                color=discord.Color.orange(),
                timestamp=datetime.now(timezone.utc)
            )
            await interaction.channel.send(embed=lock_embed)
            await interaction.response.send_message("✅ Ticket has been locked.", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Could not find ticket creator or creator not in channel.", ephemeral=True)

    @discord.ui.button(label="❌ Close", style=discord.ButtonStyle.danger)
    async def close(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("Ticket will be closed. Choose below:", view=CloseOptionsView(interaction.channel, self.creator), ephemeral=True)

class CloseOptionsView(discord.ui.View):
    def __init__(self, channel, creator):
        super().__init__()
        self.channel = channel
        self.creator = creator

    @discord.ui.button(label="📄 Save & Close", style=discord.ButtonStyle.secondary)
    async def transcript_and_close(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Generate enhanced transcript
        messages = []
        async for msg in self.channel.history(limit=None, oldest_first=True):
            timestamp = msg.created_at.strftime('%Y-%m-%d %H:%M:%S')
            author = f"{msg.author.display_name} ({msg.author.id})"
            content = msg.content or "[No text content]"
            
            # Handle attachments
            if msg.attachments:
                content += f" [Attachments: {', '.join([att.filename for att in msg.attachments])}]"
            
            # Handle embeds
            if msg.embeds:
                content += f" [Embeds: {len(msg.embeds)} embed(s)]"
                
            messages.append(f"[{timestamp}] {author}: {content}")

        transcript_content = f"""
=== TICKET TRANSCRIPT ===
Channel: {self.channel.name}
Guild: {self.channel.guild.name}
Creator: {self.creator.display_name} ({self.creator.id})
Closed by: {interaction.user.display_name} ({interaction.user.id})
Closed at: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} UTC
Total Messages: {len(messages)}

=== CONVERSATION ===
""" + "\n".join(messages)

        # Save to database
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute("""
                UPDATE tickets SET status = 'closed', closed_at = ?, transcript = ? 
                WHERE channel_id = ?
            """, (datetime.now(timezone.utc), transcript_content, str(self.channel.id)))
            conn.commit()

        # Send transcript file
        transcript_file = discord.File(
            io.BytesIO(transcript_content.encode()), 
            filename=f"ticket-{self.channel.name}-{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        )
        
        try:
            await interaction.user.send("Here is the ticket transcript:", file=transcript_file)
            await self.creator.send("Here is your ticket transcript:", file=transcript_file)
        except:
            pass  # In case DMs are disabled
        
        # Send closing message
        close_embed = discord.Embed(
            title="🎫 Ticket Closed",
            description=f"This ticket has been closed by {interaction.user.mention}.\nTranscript saved and sent to participants.",
            color=discord.Color.red(),
            timestamp=datetime.now(timezone.utc)
        )
        close_embed.set_footer(text="Channel will be deleted in 10 seconds...")
        
        await interaction.response.send_message(embed=close_embed)
        await asyncio.sleep(10)
        await self.channel.delete(reason=f"Ticket closed by {interaction.user}")

    @discord.ui.button(label="🗑️ Delete Now", style=discord.ButtonStyle.danger)
    async def delete_immediately(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Update database without transcript
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute("""
                UPDATE tickets SET status = 'deleted', closed_at = ? 
                WHERE channel_id = ?
            """, (datetime.now(timezone.utc), str(self.channel.id)))
            conn.commit()
            
        await interaction.response.send_message("Deleting ticket channel immediately...", ephemeral=True)
        await self.channel.delete(reason=f"Ticket force deleted by {interaction.user}")

class TicketSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        await init_ticket_db()

    # Main ticket setup command with aliases
    @commands.command(name="ticketsetup", aliases=["tsetup", "setupticket", "ticketpanel"])
    @commands.has_permissions(administrator=True)
    async def ticket_setup(self, ctx):
        """Set up the ticket system panel"""
        embed = discord.Embed(
            title="🎫 Ticket Panel Setup",
            description="Setting up your ticket panel...",
            color=discord.Color.blue()
        )
        
        view = TicketSetupView(self.bot, ctx.author)
        await ctx.send(embed=embed, view=view)

    # Ticket stats command with aliases
    @commands.command(name="ticketstats", aliases=["tstats", "ticketinfo", "tinfo"])
    @commands.has_permissions(manage_channels=True)
    async def ticket_stats(self, ctx):
        """View ticket statistics for the server"""
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                SELECT status, COUNT(*) FROM tickets 
                WHERE guild_id = ? 
                GROUP BY status
            """, (str(ctx.guild.id),))
            stats = dict(cursor.fetchall())
            
            cursor = conn.execute("""
                SELECT COUNT(*) FROM tickets 
                WHERE guild_id = ? AND created_at >= date('now', '-7 days')
            """, (str(ctx.guild.id),))
            weekly_tickets = cursor.fetchone()[0]
            
            cursor = conn.execute("""
                SELECT COUNT(*) FROM tickets 
                WHERE guild_id = ? AND created_at >= date('now', '-30 days')
            """, (str(ctx.guild.id),))
            monthly_tickets = cursor.fetchone()[0]

        embed = discord.Embed(
            title="📊 Ticket Statistics",
            color=discord.Color.green(),
            timestamp=datetime.now(timezone.utc)
        )
        
        embed.add_field(name="🟢 Open Tickets", value=stats.get('open', 0), inline=True)
        embed.add_field(name="🔴 Closed Tickets", value=stats.get('closed', 0), inline=True)
        embed.add_field(name="🗑️ Deleted Tickets", value=stats.get('deleted', 0), inline=True)
        embed.add_field(name="📅 This Week", value=weekly_tickets, inline=True)
        embed.add_field(name="📆 This Month", value=monthly_tickets, inline=True)
        embed.add_field(name="📈 Total Tickets", value=sum(stats.values()), inline=True)
        
        await ctx.send(embed=embed)

    # Close ticket command with aliases
    @commands.command(name="closeticket", aliases=["close", "tclose", "endticket"])
    @commands.has_permissions(manage_channels=True)
    async def close_ticket(self, ctx):
        """Close the current ticket channel"""
        # Check if this channel is in the database as a ticket
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("SELECT id FROM tickets WHERE channel_id = ?", (str(ctx.channel.id),))
            if not cursor.fetchone():
                await ctx.send("❌ This command can only be used in ticket channels!")
                return
            
        # Get ticket creator from database
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("""
                SELECT creator_id FROM tickets WHERE channel_id = ?
            """, (str(ctx.channel.id),))
            result = cursor.fetchone()
            
        if result:
            creator_id = int(result[0])
            creator = ctx.guild.get_member(creator_id)
            if creator:
                view = CloseOptionsView(ctx.channel, creator)
                await ctx.send("Choose how to close this ticket:", view=view)
                return
                
        await ctx.send("❌ Could not find ticket information.")

    # Add user to ticket command with aliases  
    @commands.command(name="adduser", aliases=["add", "tadduser", "ticketadd"])
    @commands.has_permissions(manage_channels=True)
    async def add_user_to_ticket(self, ctx, user: discord.Member):
        """Add a user to the current ticket"""
        # Check if this channel is in the database as a ticket
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("SELECT id FROM tickets WHERE channel_id = ?", (str(ctx.channel.id),))
            if not cursor.fetchone():
                await ctx.send("❌ This command can only be used in ticket channels!")
                return
            
        # Add user to channel
        overwrites = ctx.channel.overwrites
        overwrites[user] = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)
        await ctx.channel.edit(overwrites=overwrites)
        
        embed = discord.Embed(
            title="👥 User Added",
            description=f"{user.mention} has been added to this ticket.",
            color=discord.Color.blue(),
            timestamp=datetime.now(timezone.utc)
        )
        await ctx.send(embed=embed)

    # Remove user from ticket command with aliases
    @commands.command(name="removeuser", aliases=["remove", "tremoveuser", "ticketremove"])
    @commands.has_permissions(manage_channels=True)
    async def remove_user_from_ticket(self, ctx, user: discord.Member):
        """Remove a user from the current ticket"""
        # Check if this channel is in the database as a ticket
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("SELECT id FROM tickets WHERE channel_id = ?", (str(ctx.channel.id),))
            if not cursor.fetchone():
                await ctx.send("❌ This command can only be used in ticket channels!")
                return
            
        # Remove user from channel
        overwrites = ctx.channel.overwrites
        if user in overwrites:
            del overwrites[user]
            await ctx.channel.edit(overwrites=overwrites)
            
            embed = discord.Embed(
                title="👤 User Removed", 
                description=f"{user.mention} has been removed from this ticket.",
                color=discord.Color.orange(),
                timestamp=datetime.now(timezone.utc)
            )
            await ctx.send(embed=embed)
        else:
            await ctx.send("❌ User is not in this ticket channel.")

    # Claim ticket command with aliases
    @commands.command(name="claim", aliases=["tclaim", "claimticket"])
    @commands.has_permissions(manage_channels=True) 
    async def claim_ticket(self, ctx):
        """Claim the current ticket"""
        # Check if this channel is in the database as a ticket
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("SELECT id FROM tickets WHERE channel_id = ?", (str(ctx.channel.id),))
            if not cursor.fetchone():
                await ctx.send("❌ This command can only be used in ticket channels!")
                return
            
        # Update database
        with sqlite3.connect(DB_FILE) as conn:
            conn.execute("UPDATE tickets SET staff_id = ? WHERE channel_id = ?", 
                       (str(ctx.author.id), str(ctx.channel.id)))
            conn.commit()
        
        embed = discord.Embed(
            title="🎫 Ticket Claimed",
            description=f"{ctx.author.mention} has claimed this ticket.",
            color=discord.Color.green(),
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_footer(text=f"Claimed by {ctx.author.display_name}", icon_url=ctx.author.display_avatar.url)
        await ctx.send(embed=embed)

    # Set ticket priority command with aliases
    @commands.command(name="priority", aliases=["tpriority", "setpriority", "ticketpriority"])
    @commands.has_permissions(manage_channels=True)
    async def set_priority(self, ctx, priority: str = None):
        """Set the priority level of the current ticket"""
        # Check if this channel is in the database as a ticket
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("SELECT id FROM tickets WHERE channel_id = ? AND status = 'open'", (str(ctx.channel.id),))
            if not cursor.fetchone():
                await ctx.send("❌ This command can only be used in ticket channels!")
                return
            
        if priority is None:
            embed = discord.Embed(
                title="🎯 Set Ticket Priority", 
                description="Please specify a priority level:\n\n🔴 **High** - Urgent issues\n🟡 **Medium** - Normal issues\n🟢 **Low** - Minor issues",
                color=discord.Color.blue()
            )
            embed.add_field(name="Usage", value="`!priority high/medium/low`", inline=False)
            await ctx.send(embed=embed)
            return
            
        priority = priority.lower()
        priority_map = {"high": "🔴 High", "medium": "🟡 Medium", "low": "🟢 Low"}
        
        if priority not in priority_map:
            await ctx.send("❌ Priority must be: `high`, `medium`, or `low`\nExample: `!priority high`")
            return
            
        try:
            # Update database
            with sqlite3.connect(DB_FILE) as conn:
                conn.execute("UPDATE tickets SET priority = ? WHERE channel_id = ?", 
                           (priority_map[priority], str(ctx.channel.id)))
                conn.commit()
            
            # Set color based on priority
            color_map = {
                "high": discord.Color.red(),
                "medium": discord.Color.orange(), 
                "low": discord.Color.green()
            }
            
            embed = discord.Embed(
                title="🎯 Priority Updated Successfully",
                description=f"Ticket priority has been set to **{priority_map[priority]}**",
                color=color_map[priority],
                timestamp=datetime.now(timezone.utc)
            )
            embed.set_footer(text=f"Updated by {ctx.author.display_name}", icon_url=ctx.author.display_avatar.url)
            await ctx.send(embed=embed)
            
        except Exception as e:
            await ctx.send(f"❌ Error updating priority: {str(e)}")
            print(f"Priority command error: {e}")

    # Ticket rating command with aliases
    @commands.command(name="rate", aliases=["rating", "rateticket", "feedback"])
    async def rate_ticket(self, ctx, rating: int = None, *, feedback: str = None):
        """Rate your ticket experience (1-5 stars)"""
        # Check if this channel is in the database as a ticket
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("SELECT id FROM tickets WHERE channel_id = ? AND status = 'open'", (str(ctx.channel.id),))
            if not cursor.fetchone():
                await ctx.send("❌ This command can only be used in ticket channels!")
                return
            
        if rating is None:
            embed = discord.Embed(
                title="⭐ Rate This Ticket Experience",
                description="Please rate your experience with our support team!\n\n**Usage:** `!rate <1-5> [optional feedback]`",
                color=discord.Color.gold()
            )
            embed.add_field(name="Examples", value="`!rate 5 Excellent support!`\n`!rate 4`\n`!rate 3 Could be better`", inline=False)
            embed.add_field(name="Rating Scale", value="⭐ = Poor\n⭐⭐ = Fair\n⭐⭐⭐ = Good\n⭐⭐⭐⭐ = Very Good\n⭐⭐⭐⭐⭐ = Excellent", inline=False)
            await ctx.send(embed=embed)
            return
            
        if rating < 1 or rating > 5:
            await ctx.send("❌ Please provide a rating from 1 to 5 stars.\nExample: `!rate 5 Great support!`")
            return
            
        try:
            # Check if ticket exists in database
            with sqlite3.connect(DB_FILE) as conn:
                cursor = conn.execute("SELECT creator_id FROM tickets WHERE channel_id = ?", (str(ctx.channel.id),))
                result = cursor.fetchone()
                
                if not result:
                    await ctx.send("❌ This ticket was not found in the database!")
                    return
                    
                creator_id = int(result[0])
                
                # Only allow ticket creator to rate (or staff with manage channels)
                if ctx.author.id != creator_id and not ctx.author.guild_permissions.manage_channels:
                    await ctx.send("❌ Only the ticket creator or staff members can rate this ticket!")
                    return
                
                # Update database
                conn.execute("UPDATE tickets SET rating = ?, feedback = ? WHERE channel_id = ?", 
                           (rating, feedback or "", str(ctx.channel.id)))
                conn.commit()
            
            # Create rating display
            stars = "⭐" * rating + "☆" * (5 - rating)
            
            # Set color based on rating
            color_map = {
                1: discord.Color.red(),
                2: discord.Color.orange(),
                3: discord.Color.yellow(),
                4: discord.Color.blue(),
                5: discord.Color.green()
            }
            
            embed = discord.Embed(
                title="🌟 Thank You for Your Feedback!",
                description=f"**Rating:** {stars} ({rating}/5)\n**User:** {ctx.author.mention}",
                color=color_map.get(rating, discord.Color.gold()),
                timestamp=datetime.now(timezone.utc)
            )
            
            if feedback:
                embed.add_field(name="💬 Feedback", value=feedback, inline=False)
            else:
                embed.add_field(name="💬 Feedback", value="*No additional feedback provided*", inline=False)
                
            embed.set_footer(text="Your feedback helps us improve our support service!")
            embed.set_thumbnail(url=ctx.author.display_avatar.url)
            
            await ctx.send(embed=embed)
            
            # Send confirmation message
            rating_text = ["Poor", "Fair", "Good", "Very Good", "Excellent"][rating - 1]
            await ctx.send(f"✅ Rating saved successfully! You rated this ticket **{rating}/5 ({rating_text})**")
            
        except Exception as e:
            await ctx.send(f"❌ Error saving rating: {str(e)}")
            print(f"Rate command error: {e}")

    # Ticket transcript command with aliases
    @commands.command(name="transcript", aliases=["ttranscript", "tickettranscript", "save"])
    @commands.has_permissions(manage_channels=True)
    async def get_transcript(self, ctx):
        """Generate and save ticket transcript"""
        # Check if this channel is in the database as a ticket
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.execute("SELECT id FROM tickets WHERE channel_id = ?", (str(ctx.channel.id),))
            if not cursor.fetchone():
                await ctx.send("❌ This command can only be used in ticket channels!")
                return
            
        try:
            # Send initial message
            processing_embed = discord.Embed(
                title="📄 Generating Transcript...",
                description="Please wait while we collect all messages from this ticket.",
                color=discord.Color.blue()
            )
            processing_msg = await ctx.send(embed=processing_embed)
            
            # Generate transcript
            messages = []
            message_count = 0
            
            async for msg in ctx.channel.history(limit=None, oldest_first=True):
                timestamp = msg.created_at.strftime('%Y-%m-%d %H:%M:%S UTC')
                author = f"{msg.author.display_name} ({msg.author.id})"
                content = msg.content or "[No text content]"
                
                # Handle attachments
                if msg.attachments:
                    attachment_list = []
                    for att in msg.attachments:
                        attachment_list.append(f"{att.filename} ({att.url})")
                    content += f" [Attachments: {', '.join(attachment_list)}]"
                
                # Handle embeds
                if msg.embeds:
                    content += f" [Embeds: {len(msg.embeds)} embed(s)]"
                    
                # Handle reactions
                if msg.reactions:
                    reactions = []
                    for reaction in msg.reactions:
                        reactions.append(f"{reaction.emoji}({reaction.count})")
                    content += f" [Reactions: {', '.join(reactions)}]"
                    
                messages.append(f"[{timestamp}] {author}: {content}")
                message_count += 1

            # Get ticket info from database
            with sqlite3.connect(DB_FILE) as conn:
                cursor = conn.execute("""
                    SELECT creator_id, ticket_type, priority, category, created_at, rating, feedback 
                    FROM tickets WHERE channel_id = ?
                """, (str(ctx.channel.id),))
                ticket_info = cursor.fetchone()

            # Create comprehensive transcript
            transcript_content = f"""
=== TICKET TRANSCRIPT ===
Channel: {ctx.channel.name}
Guild: {ctx.guild.name} (ID: {ctx.guild.id})
Category: {ctx.channel.category.name if ctx.channel.category else 'No Category'}
Generated by: {ctx.author.display_name} ({ctx.author.id})
Generated at: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} UTC

=== TICKET INFORMATION ==="""

            if ticket_info:
                creator = ctx.guild.get_member(int(ticket_info[0]))
                creator_name = creator.display_name if creator else "Unknown User"
                
                transcript_content += f"""
Ticket Creator: {creator_name} (ID: {ticket_info[0]})
Ticket Type: {ticket_info[1] or 'Unknown'}
Priority: {ticket_info[2] or 'Medium'}
Category: {ticket_info[3] or 'General Support'}
Created At: {ticket_info[4] or 'Unknown'}
Rating: {ticket_info[5] or 'Not Rated'}/5
Feedback: {ticket_info[6] or 'No feedback provided'}
"""
            
            transcript_content += f"""
Total Messages: {message_count}
Channel Topic: {ctx.channel.topic or 'No topic set'}

=== CONVERSATION HISTORY ===
""" + "\n".join(messages)

            # Save to database
            with sqlite3.connect(DB_FILE) as conn:
                conn.execute("UPDATE tickets SET transcript = ? WHERE channel_id = ?", 
                           (transcript_content, str(ctx.channel.id)))
                conn.commit()

            # Create transcript file
            transcript_file = discord.File(
                io.BytesIO(transcript_content.encode('utf-8')), 
                filename=f"transcript-{ctx.channel.name}-{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            )
            
            # Update processing message
            success_embed = discord.Embed(
                title="✅ Transcript Generated Successfully",
                description=f"**Messages Collected:** {message_count}\n**File Size:** {len(transcript_content.encode('utf-8'))} bytes",
                color=discord.Color.green(),
                timestamp=datetime.now(timezone.utc)
            )
            success_embed.set_footer(text="Transcript will be sent to your DMs")
            
            await processing_msg.edit(embed=success_embed)
            
            # Try to send to DMs first
            try:
                dm_embed = discord.Embed(
                    title="📄 Ticket Transcript",
                    description=f"Transcript for ticket: **{ctx.channel.name}**\nFrom server: **{ctx.guild.name}**",
                    color=discord.Color.blue()
                )
                await ctx.author.send(embed=dm_embed, file=transcript_file)
                await ctx.send("✅ Transcript sent to your DMs successfully!")
                
            except discord.Forbidden:
                # If DMs fail, send in channel
                await ctx.send("❌ Could not send to DMs. Here's the transcript file:", file=transcript_file)
                
        except Exception as e:
            error_embed = discord.Embed(
                title="❌ Error Generating Transcript",
                description=f"An error occurred: {str(e)}",
                color=discord.Color.red()
            )
            await ctx.send(embed=error_embed)
            print(f"Transcript command error: {e}")

    # Database repair command (owner only)
    @commands.command(name="fixticketdb", aliases=["repairticketdb", "ticketdbfix"])
    @commands.is_owner()
    async def fix_ticket_database(self, ctx):
        """Fix ticket database schema by adding missing columns"""
        try:
            with sqlite3.connect(DB_FILE) as conn:
                # Get current table structure
                cursor = conn.execute("PRAGMA table_info(tickets)")
                columns = [column[1] for column in cursor.fetchall()]
                
                # Define required columns
                required_columns = {
                    'priority': 'TEXT DEFAULT "Medium"',
                    'category': 'TEXT DEFAULT "General Support"',
                    'rating': 'INTEGER',
                    'feedback': 'TEXT',
                    'transcript': 'TEXT',
                    'closed_at': 'TIMESTAMP',
                    'staff_id': 'TEXT',
                    'ticket_type': 'TEXT'
                }
                
                added_columns = []
                for column_name, column_def in required_columns.items():
                    if column_name not in columns:
                        try:
                            conn.execute(f"ALTER TABLE tickets ADD COLUMN {column_name} {column_def}")
                            added_columns.append(column_name)
                        except sqlite3.OperationalError as e:
                            await ctx.send(f"❌ Error adding column {column_name}: {e}")
                            continue
                
                conn.commit()
                
                if added_columns:
                    embed = discord.Embed(
                        title="✅ Database Fixed Successfully",
                        description=f"Added missing columns: {', '.join(added_columns)}",
                        color=discord.Color.green()
                    )
                else:
                    embed = discord.Embed(
                        title="✅ Database Check Complete",
                        description="No missing columns found. Database is already up to date.",
                        color=discord.Color.blue()
                    )
                
                # Show current table structure
                cursor = conn.execute("PRAGMA table_info(tickets)")
                columns = cursor.fetchall()
                column_list = [f"`{col[1]}` ({col[2]})" for col in columns]
                
                embed.add_field(
                    name="Current Table Structure",
                    value="\n".join(column_list[:10]) + ("..." if len(column_list) > 10 else ""),
                    inline=False
                )
                
                await ctx.send(embed=embed)
                
        except Exception as e:
            embed = discord.Embed(
                title="❌ Database Repair Failed",
                description=f"Error: {str(e)}",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)

    # Perfect comprehensive ticket help command with aliases
    @commands.command(name="tickethelp", aliases=["thelp", "ticketcommands", "tcmds", "helpticket"])
    async def ticket_help(self, ctx):
        """🎫 Perfect Ticket System - Complete Command Guide & Help Panel"""
        
        # Create multiple embeds for comprehensive information
        help_embeds = []
        
        # Main Overview Embed
        main_embed = discord.Embed(
            title="🎫 Perfect Ticket System - Command Center",
            description=f"""
**Welcome to the most comprehensive ticket system!**
This system includes advanced features like priorities, categories, analytics, and more.

📋 **Quick Setup Guide:**
1. Use `ticketsetup` to create your ticket panel
2. Configure categories and staff roles
3. Users can create tickets via dropdown menu
4. Staff can manage tickets with powerful commands

🔄 **System Status:** ✅ Online & Ready
📊 **Total Commands:** 11 main commands with 35+ aliases
            """,
            color=0x00ff88,
            timestamp=datetime.now(timezone.utc)
        )
        main_embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/1234567890123456789.png")  # Replace with your server's emoji
        help_embeds.append(main_embed)
        
        # Setup & Configuration Commands
        setup_embed = discord.Embed(
            title="🔧 Setup & Configuration Commands",
            description="Essential commands to get your ticket system running",
            color=0x3498db
        )
        setup_embed.add_field(
            name=f"{EMOJI_DOT} `ticketsetup`",
            value="""
**Aliases:** `tsetup`, `setupticket`, `ticketpanel`
**Permission:** Administrator
**Usage:** `!ticketsetup`
**Description:** Launch the interactive ticket panel setup wizard
**Features:** Custom embed, multiple categories, staff role assignment
            """,
            inline=False
        )
        help_embeds.append(setup_embed)
        
        # Ticket Management Commands
        mgmt_embed = discord.Embed(
            title="⚙️ Advanced Ticket Management",
            description="Powerful tools for staff to manage tickets efficiently",
            color=0xe74c3c
        )
        mgmt_embed.add_field(
            name=f"{EMOJI_DOT} `closeticket`",
            value="""
**Aliases:** `close`, `tclose`, `endticket`
**Permission:** Manage Channels
**Usage:** `!closeticket`
**Features:** Save transcript, send to DMs, auto-delete option
**Location:** Must be used inside ticket channels
            """,
            inline=False
        )
        mgmt_embed.add_field(
            name=f"{EMOJI_DOT} `adduser <@user>`",
            value="""
**Aliases:** `add`, `tadduser`, `ticketadd`
**Permission:** Manage Channels  
**Usage:** `!adduser @username` or `!add 123456789`
**Description:** Add any user to current ticket with full permissions
**Example:** `!adduser @JohnDoe` - Adds JohnDoe to ticket
            """,
            inline=False
        )
        mgmt_embed.add_field(
            name=f"{EMOJI_DOT} `removeuser <@user>`",
            value="""
**Aliases:** `remove`, `tremoveuser`, `ticketremove`
**Permission:** Manage Channels
**Usage:** `!removeuser @username`
**Description:** Remove user access from current ticket
**Safety:** Cannot remove ticket creator or bot
            """,
            inline=False
        )
        mgmt_embed.add_field(
            name=f"{EMOJI_DOT} `claim`",
            value="""
**Aliases:** `tclaim`, `claimticket`
**Permission:** Manage Channels
**Usage:** `!claim`
**Description:** Claim ticket ownership and responsibility
**Effect:** Updates database, notifies users, shows claimer info
            """,
            inline=False
        )
        help_embeds.append(mgmt_embed)
        
        # Analytics & Information Commands
        info_embed = discord.Embed(
            title="📊 Analytics & Information Commands",
            description="Detailed insights and ticket data management",
            color=0x9b59b6
        )
        info_embed.add_field(
            name=f"{EMOJI_DOT} `ticketstats`",
            value="""
**Aliases:** `tstats`, `ticketinfo`, `tinfo`
**Permission:** Manage Channels
**Usage:** `!ticketstats`
**Shows:** Open/closed counts, weekly/monthly stats, total tickets
**Features:** Real-time data, beautiful formatting, timestamp info
            """,
            inline=False
        )
        info_embed.add_field(
            name=f"{EMOJI_DOT} `transcript`",
            value="""
**Aliases:** `ttranscript`, `tickettranscript`, `save`
**Permission:** Manage Channels
**Usage:** `!transcript`
**Features:** Full message history, attachment info, timestamp logs
**Delivery:** Sent to DMs with fallback to channel
            """,
            inline=False
        )
        help_embeds.append(info_embed)
        
        # Interactive Features & Buttons
        interactive_embed = discord.Embed(
            title="🎮 Interactive Features & Button Controls",
            description="Modern UI elements for seamless ticket management",
            color=0xf39c12
        )
        interactive_embed.add_field(
            name="🖱️ Ticket Panel Buttons",
            value="""
**📌 Claim Button:** Instantly claim ticket ownership
**👥 Add User Button:** Modal popup to add users quickly  
**🔒 Lock Button:** Prevent creator from sending messages
**❌ Close Button:** Advanced closing options with transcript
            """,
            inline=False
        )
        interactive_embed.add_field(
            name="🎯 Dropdown Ticket Creation",
            value="""
**Multiple Categories:** Support, Bug Reports, Features, Questions
**Smart Permissions:** Auto-assign staff roles per category
**User Limits:** Configurable max tickets per user
**Priority System:** High, Medium, Low priority options
            """,
            inline=False
        )
        help_embeds.append(interactive_embed)
        
        # Advanced Features & Tips
        advanced_embed = discord.Embed(
            title="⭐ Advanced Features & Pro Tips",
            description="Professional-grade features for enterprise-level support",
            color=0x1abc9c
        )
        advanced_embed.add_field(
            name="🔥 Advanced Features",
            value=f"""
{EMOJI_DOT} **Database Integration:** SQLite with full persistence
{EMOJI_DOT} **Auto-Transcripts:** Conversation logs saved automatically  
{EMOJI_DOT} **Permission Management:** Role-based access control
{EMOJI_DOT} **Category Support:** Organized ticket channels
{EMOJI_DOT} **Rate Limiting:** Prevent ticket spam
{EMOJI_DOT} **Multi-Server:** Works across unlimited Discord servers
            """,
            inline=False
        )
        advanced_embed.add_field(
            name="🔧 Database Maintenance Commands",
            value=f"""
{EMOJI_DOT} `fixticketdb` - **Aliases:** `repairticketdb`, `ticketdbfix`
**Permission:** Bot Owner Only
**Description:** Repairs ticket database by adding missing columns
**Usage:** `!fixticketdb` - Fixes database schema issues
**Note:** Use this if advanced commands aren't working properly
            """,
            inline=False
        )
        advanced_embed.add_field(
            name="💡 Pro Tips for Staff",
            value=f"""
{EMOJI_DOT} Use `!claim` before responding to show ownership
{EMOJI_DOT} Always use `!transcript` before closing important tickets
{EMOJI_DOT} Check `!ticketstats` regularly for workload insights
{EMOJI_DOT} Use `!adduser` to bring in specialists for complex issues
{EMOJI_DOT} Lock tickets when awaiting user response
            """,
            inline=False
        )
        advanced_embed.add_field(
            name="🛡️ Security & Permissions",
            value="""
**Administrator Required:** `ticketsetup`
**Manage Channels Required:** All management commands
**Automatic Permissions:** Ticket creators get full access
**Staff Role Integration:** Configurable per ticket category
**Bot Permissions:** Manage channels, read/send messages
            """,
            inline=False
        )
        help_embeds.append(advanced_embed)
        
        # Final embed with footer information
        footer_embed = discord.Embed(
            title="🎯 Quick Reference & Support",
            description="Everything you need to master the ticket system",
            color=0x2ecc71
        )
        footer_embed.add_field(
            name="📝 All Available Aliases",
            value="""
**Setup:** `ticketsetup`, `tsetup`, `setupticket`, `ticketpanel`
**Close:** `closeticket`, `close`, `tclose`, `endticket`  
**Users:** `adduser/add/tadduser`, `removeuser/remove/tremoveuser`
**Claim:** `claim`, `tclaim`, `claimticket`
**Priority:** `priority`, `tpriority`, `setpriority`, `ticketpriority`
**Rating:** `rate`, `rating`, `rateticket`, `feedback`
**Stats:** `ticketstats`, `tstats`, `ticketinfo`, `tinfo`
**Save:** `transcript`, `ttranscript`, `tickettranscript`, `save`
**Fix DB:** `fixticketdb`, `repairticketdb`, `ticketdbfix`
**Help:** `tickethelp`, `thelp`, `ticketcommands`, `tcmds`
            """,
            inline=False
        )
        footer_embed.add_field(
            name="🆘 Need Additional Help?",
            value="""
• Re-run this command anytime with `!tickethelp`
• All commands have detailed error messages
• Check `!ticketstats` to monitor system health
• Bot automatically handles permissions and setup
            """,
            inline=False
        )
        footer_embed.set_footer(
            text=f"Perfect Ticket System v2.0 | Serving {ctx.guild.name} | Total Commands: 11",
            icon_url=ctx.guild.icon.url if ctx.guild.icon else None
        )
        help_embeds.append(footer_embed)
        
        # Send all embeds
        for embed in help_embeds:
            await ctx.send(embed=embed)

    # Event listener for when a ticket is created via dropdown
    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type != discord.InteractionType.component:
            return
            
        if hasattr(interaction.data, 'custom_id') and interaction.data.get('custom_id') == 'ticket_select':
            selected_option = interaction.data['values'][0]
            guild = interaction.guild
            user = interaction.user
            
            # Check for existing tickets
            with sqlite3.connect(DB_FILE) as conn:
                cursor = conn.execute("""
                    SELECT COUNT(*) FROM tickets 
                    WHERE guild_id = ? AND creator_id = ? AND status = 'open'
                """, (str(guild.id), str(user.id)))
                open_tickets = cursor.fetchone()[0]
                
                cursor = conn.execute("""
                    SELECT max_tickets_per_user FROM ticket_settings 
                    WHERE guild_id = ?
                """, (str(guild.id),))
                result = cursor.fetchone()
                max_tickets = result[0] if result else 3
                
            if open_tickets >= max_tickets:
                await interaction.response.send_message(
                    f"❌ You already have {open_tickets} open tickets! Please close some before creating new ones.",
                    ephemeral=True
                )
                return
                
            # Get ticket category
            with sqlite3.connect(DB_FILE) as conn:
                cursor = conn.execute("""
                    SELECT category_id FROM ticket_settings WHERE guild_id = ?
                """, (str(guild.id),))
                result = cursor.fetchone()
                category_id = int(result[0]) if result and result[0] else None
            
            category = guild.get_channel(category_id) if category_id else None
            
            # Create ticket channel
            global ticket_counter
            ticket_counter += 1
            channel_name = f"ticket-{user.name}-{ticket_counter}"
            
            overwrites = {
                guild.default_role: discord.PermissionOverwrite(view_channel=False),
                user: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
                guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True, manage_channels=True)
            }
            
            # Add staff role permissions if available
            for role in guild.roles:
                if role.permissions.manage_channels:
                    overwrites[role] = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)
            
            ticket_channel = await guild.create_text_channel(
                name=channel_name,
                category=category,
                overwrites=overwrites,
                topic=f"Ticket created by {user} | Type: {selected_option}"
            )
            
            # Save to database
            with sqlite3.connect(DB_FILE) as conn:
                conn.execute("""
                    INSERT INTO tickets (guild_id, channel_id, creator_id, ticket_type, category, status)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (str(guild.id), str(ticket_channel.id), str(user.id), selected_option, 'General Support', 'open'))
                conn.commit()
            
            # Create ticket embed
            ticket_embed = discord.Embed(
                title=f"🎫 Ticket Created",
                description=f"**Creator:** {user.mention}\n**Type:** {selected_option}\n**Status:** Open",
                color=discord.Color.green(),
                timestamp=datetime.now(timezone.utc)
            )
            ticket_embed.add_field(
                name="📋 Information",
                value="• A staff member will be with you shortly\n• Please describe your issue in detail\n• Use the buttons below to manage this ticket",
                inline=False
            )
            ticket_embed.set_footer(text=f"Ticket ID: {ticket_channel.id}")
            
            # Send ticket message with management buttons
            view = TicketView(user, ticket_channel.id)
            await ticket_channel.send(f"{user.mention}", embed=ticket_embed, view=view)
            
            # Respond to interaction
            await interaction.response.send_message(
                f"✅ Ticket created! Please check {ticket_channel.mention}",
                ephemeral=True
            )

async def setup(bot):
    await bot.add_cog(TicketSystem(bot))
