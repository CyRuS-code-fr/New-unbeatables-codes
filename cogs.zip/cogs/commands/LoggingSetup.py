import discord
from discord.ext import commands
import aiosqlite
from datetime import datetime, timezone
from core import Cog, axon, Context
from utils.Tools import *
from typing import Union, Optional

class LoggingSetup(Cog):
    """Setup logging channels for antinuke and moderation"""
    
    def __init__(self, client: axon):
        self.client = client
        self.client.loop.create_task(self.init_db())
    
    def help_custom(self):
        emoji = '📊'
        label = 'Logging Setup'
        description = 'Setup logging channels for antinuke and moderation'
        return emoji, label, description
    
    async def init_db(self):
        await self.client.wait_until_ready()
        # Initialize antinuke db
        async with aiosqlite.connect('db/anti.db') as db:
            await db.execute('''
                CREATE TABLE IF NOT EXISTS antinuke_log_channels (
                    guild_id INTEGER PRIMARY KEY,
                    channel_id INTEGER
                )
            ''')
            await db.commit()
        
        # Initialize automod db
        async with aiosqlite.connect('db/automod.db') as db:
            await db.execute('''
                CREATE TABLE IF NOT EXISTS automod_logging (
                    guild_id INTEGER,
                    log_channel INTEGER,
                    PRIMARY KEY (guild_id)
                )
            ''')
            await db.commit()

    # Antinuke logging setup commands
    @commands.command(name="antinukelogsetup", aliases=["antilogsetup", "antinukelogging", "setupantilog"])
    @commands.has_permissions(administrator=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def antinuke_log_setup(self, ctx: Context, channel: Optional[Union[discord.TextChannel, str]] = None):
        """Setup antinuke logging channel"""
        
        # Check owner/extra owner
        async with aiosqlite.connect('db/anti.db') as db:
            async with db.execute(
                "SELECT owner_id FROM extraowners WHERE guild_id = ? AND owner_id = ?",
                (ctx.guild.id, ctx.author.id)
            ) as cursor:
                check = await cursor.fetchone()
        
        is_owner = ctx.author.id == ctx.guild.owner_id
        if not is_owner and not check:
            embed = discord.Embed(
                title="<:CrossIcon:1327829124894429235> Access Denied",
                color=0x000000,
                description="Only Server Owner or Extra Owner can run this command!"
            )
            return await ctx.send(embed=embed)
        
        if channel is None:
            # Show current setup or help
            async with aiosqlite.connect('db/anti.db') as db:
                async with db.execute('SELECT channel_id FROM antinuke_log_channels WHERE guild_id = ?', (ctx.guild.id,)) as cursor:
                    result = await cursor.fetchone()
            
            if result:
                current_channel = ctx.guild.get_channel(result[0])
                if current_channel:
                    embed = discord.Embed(
                        title="<:tick:1327829594954530896> Antinuke Logging Setup",
                        description=f"**Current Logging Channel:** {current_channel.mention}\n\n**Usage:**\n`{ctx.prefix}antinukelogsetup #channel` - Set logging channel\n`{ctx.prefix}antinukelogsetup disable` - Disable logging",
                        color=0x000000
                    )
                else:
                    embed = discord.Embed(
                        title="<:icons_warning:1327829522573430864> Antinuke Logging Setup",
                        description=f"**Current Logging Channel:** Channel deleted\n\n**Usage:**\n`{ctx.prefix}antinukelogsetup #channel` - Set logging channel\n`{ctx.prefix}antinukelogsetup disable` - Disable logging",
                        color=0x000000
                    )
            else:
                embed = discord.Embed(
                    title="<:CrossIcon:1327829124894429235> Antinuke Logging Setup",
                    description=f"**Current Logging Channel:** Not configured\n\n**Usage:**\n`{ctx.prefix}antinukelogsetup #channel` - Set logging channel",
                    color=0x000000
                )
            
            embed.set_thumbnail(url=self.client.user.display_avatar.url)
            embed.set_footer(
                text=f"Command executed by {ctx.author}",
                icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
            )
            return await ctx.send(embed=embed)
        
        if isinstance(channel, str) and channel.lower() == 'disable':
            # Disable logging
            async with aiosqlite.connect('db/anti.db') as db:
                await db.execute('DELETE FROM antinuke_log_channels WHERE guild_id = ?', (ctx.guild.id,))
                await db.commit()
            
            embed = discord.Embed(
                title="<:tick:1327829594954530896> Antinuke Logging Disabled",
                description="Antinuke logging has been disabled for this server.",
                color=0x000000
            )
            embed.set_thumbnail(url=self.client.user.display_avatar.url)
            embed.set_footer(
                text=f"Command executed by {ctx.author}",
                icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
            )
            return await ctx.send(embed=embed)
        
        # Validate channel parameter
        if isinstance(channel, str):
            embed = discord.Embed(
                title="<:CrossIcon:1327829124894429235> Invalid Channel",
                description=f"Please mention a valid text channel or use `disable` to disable logging.",
                color=0x000000
            )
            return await ctx.send(embed=embed)
        
        # Check bot permissions
        if not channel.permissions_for(ctx.guild.me).send_messages:
            embed = discord.Embed(
                title="<:CrossIcon:1327829124894429235> No Permission",
                description=f"I don't have permission to send messages in {channel.mention}.",
                color=0x000000
            )
            return await ctx.send(embed=embed)
        
        # Set new channel
        async with aiosqlite.connect('db/anti.db') as db:
            await db.execute('INSERT OR REPLACE INTO antinuke_log_channels (guild_id, channel_id) VALUES (?, ?)', 
                           (ctx.guild.id, channel.id))
            await db.commit()
        
        embed = discord.Embed(
            title="<:tick:1327829594954530896> Antinuke Logging Setup Complete",
            description=f"**Logging Channel:** {channel.mention}\n\n**What will be logged:**\n• All antinuke actions (bans, kicks)\n• Channel/Role protection events\n• Bot addition attempts\n• Server modification attempts\n• Mass actions detected",
            color=0x000000
        )
        embed.set_thumbnail(url=self.client.user.avatar.url)
        embed.set_footer(
            text=f"Command executed by {ctx.author}",
            icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
        )
        await ctx.send(embed=embed)

    # Moderation/Automod logging setup commands  
    @commands.command(name="moderationlogsetup", aliases=["modlogsetup", "automodlogsetup", "setupmodlog"])
    @commands.has_permissions(administrator=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def moderation_log_setup(self, ctx: Context, channel: Optional[Union[discord.TextChannel, str]] = None):
        """Setup moderation/automod logging channel"""
        
        # Permission check removed - @commands.has_permissions(administrator=True) is sufficient
        
        if channel is None:
            # Show current setup or help
            async with aiosqlite.connect('db/automod.db') as db:
                async with db.execute("SELECT log_channel FROM automod_logging WHERE guild_id = ?", (ctx.guild.id,)) as cursor:
                    result = await cursor.fetchone()
            
            if result:
                current_channel = ctx.guild.get_channel(result[0])
                if current_channel:
                    embed = discord.Embed(
                        title="<:tick:1327829594954530896> Moderation Logging Setup",
                        description=f"**Current Logging Channel:** {current_channel.mention}\n\n**Usage:**\n`{ctx.prefix}moderationlogsetup #channel` - Set logging channel\n`{ctx.prefix}moderationlogsetup disable` - Disable logging",
                        color=0x000000
                    )
                else:
                    embed = discord.Embed(
                        title="<:icons_warning:1327829522573430864> Moderation Logging Setup",
                        description=f"**Current Logging Channel:** Channel deleted\n\n**Usage:**\n`{ctx.prefix}moderationlogsetup #channel` - Set logging channel\n`{ctx.prefix}moderationlogsetup disable` - Disable logging",
                        color=0x000000
                    )
            else:
                embed = discord.Embed(
                    title="<:CrossIcon:1327829124894429235> Moderation Logging Setup",
                    description=f"**Current Logging Channel:** Not configured\n\n**Usage:**\n`{ctx.prefix}moderationlogsetup #channel` - Set logging channel",
                    color=0x000000
                )
            
            embed.set_thumbnail(url=self.client.user.display_avatar.url)
            embed.set_footer(
                text=f"Command executed by {ctx.author}",
                icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
            )
            return await ctx.send(embed=embed)
        
        if isinstance(channel, str) and channel.lower() == 'disable':
            # Disable logging
            async with aiosqlite.connect('db/automod.db') as db:
                await db.execute('DELETE FROM automod_logging WHERE guild_id = ?', (ctx.guild.id,))
                await db.commit()
            
            embed = discord.Embed(
                title="<:tick:1327829594954530896> Moderation Logging Disabled",
                description="Moderation logging has been disabled for this server.",
                color=0x000000
            )
            embed.set_thumbnail(url=self.client.user.display_avatar.url)
            embed.set_footer(
                text=f"Command executed by {ctx.author}",
                icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
            )
            return await ctx.send(embed=embed)
        
        # Validate channel parameter
        if isinstance(channel, str):
            embed = discord.Embed(
                title="<:CrossIcon:1327829124894429235> Invalid Channel",
                description=f"Please mention a valid text channel or use `disable` to disable logging.",
                color=0x000000
            )
            return await ctx.send(embed=embed)
        
        # Check bot permissions
        if not channel.permissions_for(ctx.guild.me).send_messages:
            embed = discord.Embed(
                title="<:CrossIcon:1327829124894429235> No Permission",
                description=f"I don't have permission to send messages in {channel.mention}.",
                color=0x000000
            )
            return await ctx.send(embed=embed)
        
        # Set new channel
        async with aiosqlite.connect('db/automod.db') as db:
            await db.execute("INSERT OR REPLACE INTO automod_logging (guild_id, log_channel) VALUES (?, ?)", 
                           (ctx.guild.id, channel.id))
            await db.commit()
        
        embed = discord.Embed(
            title="<:tick:1327829594954530896> Moderation Logging Setup Complete",
            description=f"**Logging Channel:** {channel.mention}\n\n**What will be logged:**\n• Anti-spam actions\n• Anti-caps violations\n• Anti-link violations\n• Anti-invite violations\n• Anti-emoji spam actions\n• Anti-mass mention actions\n• All automod punishments",
            color=0x000000
        )
        embed.set_thumbnail(url=self.client.user.avatar.url)
        embed.set_footer(
            text=f"Command executed by {ctx.author}",
            icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
        )
        await ctx.send(embed=embed)

    # Quick setup command for both
    @commands.command(name="setupalllogchannels", aliases=["setupalllogs", "logsetupall", "alllogsetup"])
    @commands.has_permissions(administrator=True)
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    async def setup_all_log_channels(self, ctx: Context):
        """Quick setup for both antinuke and moderation logging channels"""
        
        # Check owner/extra owner for antinuke
        async with aiosqlite.connect('db/anti.db') as db:
            async with db.execute(
                "SELECT owner_id FROM extraowners WHERE guild_id = ? AND owner_id = ?",
                (ctx.guild.id, ctx.author.id)
            ) as cursor:
                check = await cursor.fetchone()
        
        is_owner = ctx.author.id == ctx.guild.owner_id
        if not is_owner and not check:
            embed = discord.Embed(
                title="<:CrossIcon:1327829124894429235> Access Denied",
                color=0x000000,
                description="Only Server Owner or Extra Owner can run this command!"
            )
            return await ctx.send(embed=embed)
        
        # Check bot permissions for channel creation
        if not ctx.guild.me.guild_permissions.manage_channels:
            embed = discord.Embed(
                title="<:CrossIcon:1327829124894429235> Missing Permission",
                description="I need **Manage Channels** permission to create logging channels.",
                color=0x000000
            )
            return await ctx.send(embed=embed)
        
        # Create private logging category
        overwrites = {
            ctx.guild.default_role: discord.PermissionOverwrite(view_channel=False),
            ctx.guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True)
        }
        
        # Check if logging category exists
        category = discord.utils.get(ctx.guild.categories, name="🔒-Log-Channels")
        if not category:
            try:
                category = await ctx.guild.create_category("🔒-Log-Channels", overwrites=overwrites)
            except discord.HTTPException as e:
                return await ctx.send(f"Failed to create category: {e}")
        
        # Create antinuke log channel
        antinuke_channel = discord.utils.get(ctx.guild.text_channels, name="antinuke-logs")
        if not antinuke_channel:
            try:
                antinuke_channel = await ctx.guild.create_text_channel(
                    "antinuke-logs", 
                    category=category, 
                    overwrites=overwrites,
                    topic="🔐 Antinuke protection logs and actions"
                )
            except discord.HTTPException as e:
                return await ctx.send(f"Failed to create antinuke log channel: {e}")
        
        # Create moderation log channel
        moderation_channel = discord.utils.get(ctx.guild.text_channels, name="moderation-logs")
        if not moderation_channel:
            try:
                moderation_channel = await ctx.guild.create_text_channel(
                    "moderation-logs", 
                    category=category, 
                    overwrites=overwrites,
                    topic="⚖️ Moderation and automod action logs"
                )
            except discord.HTTPException as e:
                return await ctx.send(f"Failed to create moderation log channel: {e}")
        
        # Set both channels in database
        async with aiosqlite.connect('db/anti.db') as db:
            await db.execute('INSERT OR REPLACE INTO antinuke_log_channels (guild_id, channel_id) VALUES (?, ?)', 
                           (ctx.guild.id, antinuke_channel.id))
            await db.commit()
        
        async with aiosqlite.connect('db/automod.db') as db:
            await db.execute("INSERT OR REPLACE INTO automod_logging (guild_id, log_channel) VALUES (?, ?)", 
                           (ctx.guild.id, moderation_channel.id))
            await db.commit()
        
        embed = discord.Embed(
            title="<:tick:1327829594954530896> All Logging Channels Setup Complete",
            description=f"**Successfully created and configured:**\n\n🔐 **Antinuke Logs:** {antinuke_channel.mention}\n⚖️ **Moderation Logs:** {moderation_channel.mention}\n\n**Category:** {category.mention}\n\n*All channels are private and only visible to administrators.*",
            color=0x000000
        )
        embed.set_thumbnail(url=self.client.user.avatar.url)
        embed.set_footer(
            text=f"Command executed by {ctx.author}",
            icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
        )
        await ctx.send(embed=embed)

async def setup(bot: axon):
    await bot.add_cog(LoggingSetup(bot))