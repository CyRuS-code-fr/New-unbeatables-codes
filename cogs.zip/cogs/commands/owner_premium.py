import discord
from discord.ext import commands
import aiosqlite
from datetime import datetime, timedelta
from utils.config import OWNER_IDS
from core import Context
from discord.ui import Button, View, Select
from utils import Paginator, DescriptionEmbedPaginator

class TimeSelectView(View):
    def __init__(self, user, db_path, requester):
        super().__init__(timeout=60)
        self.user = user
        self.db_path = db_path
        self.requester = requester

    @discord.ui.select(
        placeholder="Select No Prefix Duration",
        options=[
            discord.SelectOption(label="1 Hour", value="1h", emoji="⏰"),
            discord.SelectOption(label="1 Day", value="1d", emoji="📅"),
            discord.SelectOption(label="1 Week", value="1w", emoji="📆"),
            discord.SelectOption(label="1 Month", value="1m", emoji="🗓️"),
            discord.SelectOption(label="3 Months", value="3m", emoji="📊"),
            discord.SelectOption(label="6 Months", value="6m", emoji="📈"),
            discord.SelectOption(label="1 Year", value="1y", emoji="🎯"),
            discord.SelectOption(label="Lifetime", value="lifetime", emoji="♾️")
        ]
    )
    async def select_time(self, interaction: discord.Interaction, select: Select):
        if interaction.user != self.requester:
            return await interaction.response.send_message("This interaction is not for you.", ephemeral=True)

        duration_map = {
            "1h": timedelta(hours=1),
            "1d": timedelta(days=1),
            "1w": timedelta(weeks=1),
            "1m": timedelta(days=30),
            "3m": timedelta(days=90),
            "6m": timedelta(days=180),
            "1y": timedelta(days=365),
            "lifetime": None
        }

        selected_duration = select.values[0]
        duration = duration_map[selected_duration]

        if duration:
            expiry_time = datetime.utcnow() + duration
            expiry_str = expiry_time.isoformat()
        else:
            expiry_str = None

        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("INSERT INTO np (id, expiry_time) VALUES (?, ?)", (self.user.id, expiry_str))
            await db.commit()

        # Add role in main guild
        guild = interaction.client.get_guild(699587669059174461)
        if guild:
            member = guild.get_member(self.user.id)
            if member:
                role = guild.get_role(1295883122902302771)
                if role:
                    await member.add_roles(role)

        # Send success message
        if duration:
            expire_text = f"<t:{int(expiry_time.timestamp())}:F>"
        else:
            expire_text = "Lifetime"

        embed = discord.Embed(
            title="✅ No Prefix Added Successfully",
            description=(
                f"**User**: [{self.user}](https://discord.com/users/{self.user.id})\n"
                f"**Duration**: {selected_duration.upper()}\n"
                f"**Expires**: {expire_text}\n\n"
                f"**Added By**: [{self.requester}](https://discord.com/users/{self.requester.id})"
            ),
            color=0x00ff00
        )
        await interaction.response.edit_message(embed=embed, view=None)

        # Send DM to user
        try:
            dm_embed = discord.Embed(
                title="🎉 No Prefix Access Granted!",
                description=f"You've been granted No Prefix access for **{selected_duration.upper()}**!\n\nYou can now use bot commands without prefix.",
                color=0x00ff00
            )
            await self.user.send(embed=dm_embed)
        except:
            pass

class OwnerPremium(commands.Cog):
    def __init__(self, client):
        self.client = client
        self.db_path = 'db/np.db'
        self.client.loop.create_task(self.setup_database())

    async def setup_database(self):
        async with aiosqlite.connect(self.db_path) as db:
            # Create np_managers table
            await db.execute('''
                CREATE TABLE IF NOT EXISTS np_managers (
                    id INTEGER PRIMARY KEY
                )
            ''')

            # Create premium_access table
            await db.execute('''
                CREATE TABLE IF NOT EXISTS premium_access (
                    user_id INTEGER PRIMARY KEY,
                    granted_by INTEGER,
                    granted_at TEXT
                )
            ''')
            
            # Create np table
            await db.execute('''
                CREATE TABLE IF NOT EXISTS np (
                    id INTEGER PRIMARY KEY,
                    expiry_time TEXT
                )
            ''')

            await db.commit()

    async def is_np_manager(self, user_id):
        """Check if user is a No Prefix manager"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT 1 FROM np_managers WHERE id = ?", (user_id,)) as cursor:
                return await cursor.fetchone() is not None

    async def has_premium_access(self, user_id):
        """Check if user has premium access"""
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT 1 FROM premium_access WHERE user_id = ?", (user_id,)) as cursor:
                return await cursor.fetchone() is not None

    async def is_authorized(self, user_id):
        """Check if user is owner, np manager, or has premium access"""
        return (user_id in OWNER_IDS or 
                await self.is_np_manager(user_id) or 
                await self.has_premium_access(user_id))

    # ==================== NO PREFIX COMMANDS ====================

    @commands.group(name="noprefixmanager", aliases=["npm", "npmanager"], help="Manage No Prefix managers (Owner only)")
    @commands.is_owner()
    async def np_manager(self, ctx):
        if ctx.invoked_subcommand is None:
            embed = discord.Embed(
                title="No Prefix Manager Commands",
                description=(
                    "**Commands:**\n"
                    f"`{ctx.prefix}npm add <user>` - Add No Prefix manager\n"
                    f"`{ctx.prefix}npm remove <user>` - Remove No Prefix manager\n"
                    f"`{ctx.prefix}npm list` - List all managers\n"
                    f"`{ctx.prefix}npm reset` - Remove all managers"
                ),
                color=0x000000
            )
            await ctx.reply(embed=embed)

    @np_manager.command(name="add", help="Add a No Prefix manager")
    async def add_np_manager(self, ctx, user: discord.User):
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT 1 FROM np_managers WHERE id = ?", (user.id,)) as cursor:
                if await cursor.fetchone():
                    embed = discord.Embed(
                        description=f"**{user}** is already a No Prefix manager",
                        color=0xff0000
                    )
                    return await ctx.reply(embed=embed)

            await db.execute("INSERT INTO np_managers (id) VALUES (?)", (user.id,))
            await db.commit()

        embed = discord.Embed(
            title="✅ No Prefix Manager Added",
            description=f"**{user}** has been added as No Prefix manager",
            color=0x00ff00
        )
        await ctx.reply(embed=embed)

    @np_manager.command(name="remove", help="Remove a No Prefix manager")
    async def remove_np_manager(self, ctx, user: discord.User):
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT 1 FROM np_managers WHERE id = ?", (user.id,)) as cursor:
                if not await cursor.fetchone():
                    embed = discord.Embed(
                        description=f"**{user}** is not a No Prefix manager",
                        color=0xff0000
                    )
                    return await ctx.reply(embed=embed)

            await db.execute("DELETE FROM np_managers WHERE id = ?", (user.id,))
            await db.commit()

        embed = discord.Embed(
            title="✅ No Prefix Manager Removed",
            description=f"**{user}** has been removed from No Prefix managers",
            color=0x00ff00
        )
        await ctx.reply(embed=embed)

    @np_manager.command(name="list", help="List all No Prefix managers")
    async def list_np_managers(self, ctx):
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT id FROM np_managers") as cursor:
                managers = [row[0] for row in await cursor.fetchall()]

        if not managers:
            embed = discord.Embed(
                description="No No Prefix managers found",
                color=0x000000
            )
            return await ctx.reply(embed=embed)

        entries = []
        for i, manager_id in enumerate(managers, 1):
            user = self.client.get_user(manager_id)
            if user:
                entries.append(f"`{i}.` [{user}](https://discord.com/users/{user.id}) (ID: {user.id})")
            else:
                entries.append(f"`{i}.` Unknown User (ID: {manager_id})")

        paginator = Paginator(
            source=DescriptionEmbedPaginator(
                entries=entries,
                title=f"No Prefix Managers [{len(managers)}]",
                description="",
                per_page=10,
                color=0x000000
            ),
            ctx=ctx
        )
        await paginator.paginate()

    @np_manager.command(name="reset", help="Remove all No Prefix managers")
    async def reset_np_managers(self, ctx):
        # Confirmation
        embed = discord.Embed(
            title="Confirm Reset",
            description="Are you sure you want to remove **ALL** No Prefix managers?",
            color=0xff0000
        )

        yes_button = Button(label="Yes", style=discord.ButtonStyle.danger)
        no_button = Button(label="No", style=discord.ButtonStyle.secondary)
        view = View()
        view.add_item(yes_button)
        view.add_item(no_button)

        async def yes_callback(interaction):
            if interaction.user != ctx.author:
                return await interaction.response.send_message("This interaction is not for you.", ephemeral=True)

            async with aiosqlite.connect(self.db_path) as db:
                async with db.execute("SELECT COUNT(*) FROM np_managers") as cursor:
                    count = (await cursor.fetchone())[0]
                await db.execute("DELETE FROM np_managers")
                await db.commit()

            success_embed = discord.Embed(
                title="✅ No Prefix Managers Reset",
                description=f"Removed {count} No Prefix managers",
                color=0x00ff00
            )
            await interaction.response.edit_message(embed=success_embed, view=None)

        async def no_callback(interaction):
            if interaction.user != ctx.author:
                return await interaction.response.send_message("This interaction is not for you.", ephemeral=True)

            cancel_embed = discord.Embed(
                title="Reset Cancelled",
                description="No changes were made",
                color=0x000000
            )
            await interaction.response.edit_message(embed=cancel_embed, view=None)

        yes_button.callback = yes_callback
        no_button.callback = no_callback

        await ctx.reply(embed=embed, view=view)

    # ==================== PREMIUM ACCESS COMMANDS ====================

    @commands.group(name="premium", aliases=["prem"], help="Manage premium access (Owner only)")
    @commands.is_owner()
    async def premium(self, ctx):
        if ctx.invoked_subcommand is None:
            embed = discord.Embed(
                title="Premium Access Commands",
                description=(
                    "**Commands:**\n"
                    f"`{ctx.prefix}premium add <user>` - Grant premium access\n"
                    f"`{ctx.prefix}premium remove <user>` - Remove premium access\n"
                    f"`{ctx.prefix}premium list` - List premium users\n"
                    f"`{ctx.prefix}premium reset` - Remove all premium access"
                ),
                color=0x000000
            )
            await ctx.reply(embed=embed)

    @premium.command(name="add", help="Grant premium access to user")
    async def add_premium(self, ctx, user: discord.User):
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT 1 FROM premium_access WHERE user_id = ?", (user.id,)) as cursor:
                if await cursor.fetchone():
                    embed = discord.Embed(
                        description=f"**{user}** already has premium access",
                        color=0xff0000
                    )
                    return await ctx.reply(embed=embed)

            await db.execute(
                "INSERT INTO premium_access (user_id, granted_by, granted_at) VALUES (?, ?, ?)",
                (user.id, ctx.author.id, datetime.utcnow().isoformat())
            )
            await db.commit()

        embed = discord.Embed(
            title="✅ Premium Access Granted",
            description=f"**{user}** has been granted premium access",
            color=0x00ff00
        )
        await ctx.reply(embed=embed)

        # Send DM
        try:
            dm_embed = discord.Embed(
                title="🎉 Premium Access Granted!",
                description="You've been granted premium access to bot commands!",
                color=0x00ff00
            )
            await user.send(embed=dm_embed)
        except:
            pass

    @premium.command(name="remove", help="Remove premium access from user")
    async def remove_premium(self, ctx, user: discord.User):
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT 1 FROM premium_access WHERE user_id = ?", (user.id,)) as cursor:
                if not await cursor.fetchone():
                    embed = discord.Embed(
                        description=f"**{user}** doesn't have premium access",
                        color=0xff0000
                    )
                    return await ctx.reply(embed=embed)

            await db.execute("DELETE FROM premium_access WHERE user_id = ?", (user.id,))
            await db.commit()

        embed = discord.Embed(
            title="✅ Premium Access Removed",
            description=f"Premium access removed from **{user}**",
            color=0x00ff00
        )
        await ctx.reply(embed=embed)

    @premium.command(name="list", help="List all premium users")
    async def list_premium(self, ctx):
        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT user_id, granted_by, granted_at FROM premium_access") as cursor:
                premium_users = await cursor.fetchall()

        if not premium_users:
            embed = discord.Embed(
                description="No premium users found",
                color=0x000000
            )
            return await ctx.reply(embed=embed)

        entries = []
        for i, (user_id, granted_by, granted_at) in enumerate(premium_users, 1):
            user = self.client.get_user(user_id)
            granter = self.client.get_user(granted_by)

            granted_time = datetime.fromisoformat(granted_at)
            timestamp = f"<t:{int(granted_time.timestamp())}:F>"

            user_name = user.name if user else f"Unknown User (ID: {user_id})"
            granter_name = granter.name if granter else f"Unknown User (ID: {granted_by})"

            entries.append(f"`{i}.` **{user_name}**\nGranted by: {granter_name}\nAt: {timestamp}")

        paginator = Paginator(
            source=DescriptionEmbedPaginator(
                entries=entries,
                title=f"Premium Users [{len(premium_users)}]",
                description="",
                per_page=5,
                color=0x000000
            ),
            ctx=ctx
        )
        await paginator.paginate()

    @premium.command(name="reset", help="Remove all premium access")
    async def reset_premium(self, ctx):
        # Confirmation
        embed = discord.Embed(
            title="Confirm Reset",
            description="Are you sure you want to remove **ALL** premium access?",
            color=0xff0000
        )

        yes_button = Button(label="Yes", style=discord.ButtonStyle.danger)
        no_button = Button(label="No", style=discord.ButtonStyle.secondary)
        view = View()
        view.add_item(yes_button)
        view.add_item(no_button)

        async def yes_callback(interaction):
            if interaction.user != ctx.author:
                return await interaction.response.send_message("This interaction is not for you.", ephemeral=True)

            async with aiosqlite.connect(self.db_path) as db:
                async with db.execute("SELECT COUNT(*) FROM premium_access") as cursor:
                    count = (await cursor.fetchone())[0]
                await db.execute("DELETE FROM premium_access")
                await db.commit()

            success_embed = discord.Embed(
                title="✅ Premium Access Reset",
                description=f"Removed premium access from {count} users",
                color=0x00ff00
            )
            await interaction.response.edit_message(embed=success_embed, view=None)

        async def no_callback(interaction):
            if interaction.user != ctx.author:
                return await interaction.response.send_message("This interaction is not for you.", ephemeral=True)

            cancel_embed = discord.Embed(
                title="Reset Cancelled",
                description="No changes were made",
                color=0x000000
            )
            await interaction.response.edit_message(embed=cancel_embed, view=None)

        yes_button.callback = yes_callback
        no_button.callback = no_callback

        await ctx.reply(embed=embed, view=view)

    # ==================== NO PREFIX SYSTEM FOR MANAGERS ====================

    @commands.group(name="nprefix", aliases=["nopre", "npx"], help="No Prefix system (For authorized users)")
    async def nprefix(self, ctx):
        if not await self.is_authorized(ctx.author.id):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You need to be a bot owner, No Prefix manager, or have premium access to use this command.",
                color=0xff0000
            )
            return await ctx.reply(embed=embed)

        if ctx.invoked_subcommand is None:
            embed = discord.Embed(
                title="No Prefix Commands",
                description=(
                    "**Available Commands:**\n"
                    f"`{ctx.prefix}nprefix add <user>` - Add No Prefix access\n"
                    f"`{ctx.prefix}nprefix remove <user>` - Remove No Prefix access\n"
                    f"`{ctx.prefix}nprefix list` - List No Prefix users\n"
                    f"`{ctx.prefix}nprefix status <user>` - Check user status\n"
                    f"`{ctx.prefix}nprefix search <user>` - Search user in list"
                ),
                color=0x000000
            )
            await ctx.reply(embed=embed)

    @nprefix.command(name="add", help="Add No Prefix access to user")
    async def nprefix_add(self, ctx, user: discord.User):
        if not await self.is_authorized(ctx.author.id):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You don't have permission to use this command.",
                color=0xff0000
            )
            return await ctx.reply(embed=embed)

        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT id FROM np WHERE id = ?", (user.id,)) as cursor:
                if await cursor.fetchone():
                    embed = discord.Embed(
                        description=f"**{user}** already has No Prefix access",
                        color=0xff0000
                    )
                    return await ctx.reply(embed=embed)

        view = TimeSelectView(user, self.db_path, ctx.author)
        embed = discord.Embed(
            title="Select No Prefix Duration",
            description="Choose how long No Prefix access should be granted:",
            color=0x000000
        )
        await ctx.reply(embed=embed, view=view)

    @nprefix.command(name="remove", help="Remove No Prefix access from user")
    async def nprefix_remove(self, ctx, user: discord.User):
        if not await self.is_authorized(ctx.author.id):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You don't have permission to use this command.",
                color=0xff0000
            )
            return await ctx.reply(embed=embed)

        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT id FROM np WHERE id = ?", (user.id,)) as cursor:
                if not await cursor.fetchone():
                    embed = discord.Embed(
                        description=f"**{user}** doesn't have No Prefix access",
                        color=0xff0000
                    )
                    return await ctx.reply(embed=embed)

            await db.execute("DELETE FROM np WHERE id = ?", (user.id,))
            await db.commit()

        # Remove role from main guild
        guild = self.client.get_guild(699587669059174461)
        if guild:
            member = guild.get_member(user.id)
            if member:
                role = guild.get_role(1295883122902302771)
                if role and role in member.roles:
                    await member.remove_roles(role)

        embed = discord.Embed(
            title="✅ No Prefix Access Removed",
            description=f"No Prefix access removed from **{user}**",
            color=0x00ff00
        )
        await ctx.reply(embed=embed)

    @nprefix.command(name="list", help="List all No Prefix users")
    async def nprefix_list(self, ctx):
        if not await self.is_authorized(ctx.author.id):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You don't have permission to use this command.",
                color=0xff0000
            )
            return await ctx.reply(embed=embed)

        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT id, expiry_time FROM np") as cursor:
                np_users = await cursor.fetchall()

        if not np_users:
            embed = discord.Embed(
                description="No users with No Prefix access found",
                color=0x000000
            )
            return await ctx.reply(embed=embed)

        entries = []
        for i, (user_id, expiry_time) in enumerate(np_users, 1):
            user = self.client.get_user(user_id)
            user_name = user.name if user else f"Unknown User (ID: {user_id})"

            if expiry_time:
                expire_dt = datetime.fromisoformat(expiry_time)
                expire_text = f"<t:{int(expire_dt.timestamp())}:R>"
            else:
                expire_text = "Lifetime"

            entries.append(f"`{i}.` **{user_name}**\nExpires: {expire_text}")

        paginator = Paginator(
            source=DescriptionEmbedPaginator(
                entries=entries,
                title=f"No Prefix Users [{len(np_users)}]",
                description="",
                per_page=10,
                color=0x000000
            ),
            ctx=ctx
        )
        await paginator.paginate()

    @nprefix.command(name="status", help="Check No Prefix status of user")
    async def nprefix_status(self, ctx, user: discord.User):
        if not await self.is_authorized(ctx.author.id):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You don't have permission to use this command.",
                color=0xff0000
            )
            return await ctx.reply(embed=embed)

        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT id, expiry_time FROM np WHERE id = ?", (user.id,)) as cursor:
                result = await cursor.fetchone()

        if not result:
            embed = discord.Embed(
                title="No Prefix Status",
                description=f"**{user}** doesn't have No Prefix access",
                color=0xff0000
            )
            return await ctx.reply(embed=embed)

        user_id, expiry_time = result

        if expiry_time:
            expire_dt = datetime.fromisoformat(expiry_time)
            expire_timestamp = f"<t:{int(expire_dt.timestamp())}:F>"
            expire_relative = f"<t:{int(expire_dt.timestamp())}:R>"
        else:
            expire_timestamp = "Lifetime"
            expire_relative = "Never"

        embed = discord.Embed(
            title="No Prefix Status",
            description=(
                f"**User**: [{user}](https://discord.com/users/{user.id})\n"
                f"**Status**: ✅ Active\n"
                f"**Expires**: {expire_timestamp}\n"
                f"**Time Left**: {expire_relative}"
            ),
            color=0x00ff00
        )
        embed.set_thumbnail(url=user.display_avatar.url)
        await ctx.reply(embed=embed)

    @nprefix.command(name="search", help="Search for user in No Prefix list")
    async def nprefix_search(self, ctx, *, query):
        if not await self.is_authorized(ctx.author.id):
            embed = discord.Embed(
                title="❌ Access Denied",
                description="You don't have permission to use this command.",
                color=0xff0000
            )
            return await ctx.reply(embed=embed)

        async with aiosqlite.connect(self.db_path) as db:
            async with db.execute("SELECT id, expiry_time FROM np") as cursor:
                np_users = await cursor.fetchall()

        if not np_users:
            embed = discord.Embed(
                description="No users with No Prefix access found",
                color=0x000000
            )
            return await ctx.reply(embed=embed)

        # Search logic
        found_users = []
        query_lower = query.lower()

        for user_id, expiry_time in np_users:
            user = self.client.get_user(user_id)
            if user:
                if (query_lower in user.name.lower() or 
                    query_lower in str(user.id) or 
                    (user.display_name and query_lower in user.display_name.lower())):
                    found_users.append((user, expiry_time))

        if not found_users:
            embed = discord.Embed(
                title="Search Results",
                description=f"No users found matching: `{query}`",
                color=0xff0000
            )
            return await ctx.reply(embed=embed)

        entries = []
        for i, (user, expiry_time) in enumerate(found_users, 1):
            if expiry_time:
                expire_dt = datetime.fromisoformat(expiry_time)
                expire_text = f"<t:{int(expire_dt.timestamp())}:R>"
            else:
                expire_text = "Lifetime"

            entries.append(f"`{i}.` **{user.name}**\nID: {user.id}\nExpires: {expire_text}")

        paginator = Paginator(
            source=DescriptionEmbedPaginator(
                entries=entries,
                title=f"Search Results [{len(found_users)}]",
                description=f"Query: `{query}`",
                per_page=5,
                color=0x000000
            ),
            ctx=ctx
        )
        await paginator.paginate()

async def setup(client):
    await client.add_cog(OwnerPremium(client))