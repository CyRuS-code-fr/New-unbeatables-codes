import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timezone

EMOJI_DOT = "<a:BlueDot:1364125472539021352>"

class GlobalHelp(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="help", aliases=["h", "commands", "cmds"])
    async def help_command(self, ctx):
        """Show all available bot commands and systems"""
        embed = discord.Embed(
            title="🤖 CodeX Bot Help Center",
            description="Complete guide to all bot features and commands",
            color=discord.Color.blue(),
            timestamp=datetime.now(timezone.utc)
        )
        
        # Activity Tracker System
        embed.add_field(
            name="📊 Activity Tracker",
            value=f"""
{EMOJI_DOT} `activityhelp` **(ahelp, acthelp, ah)**
└ Complete activity tracking commands guide

{EMOJI_DOT} `vchours [@user]` **(vch, voicehours, vh)**
└ View voice channel hours

{EMOJI_DOT} `msgstats [@user]` **(ms, messagestats, messages)**
└ View message statistics

{EMOJI_DOT} `clearuserstats <@user>` **(cus, clearuser)**
└ Clear user's activity stats

{EMOJI_DOT} `clearmessagestats <@user>` **(cms, clearmsg)**
└ Clear user's message stats only

{EMOJI_DOT} `clearvoicestats <@user>` **(cvs, clearvoice)**
└ Clear user's voice stats only
            """,
            inline=False
        )
        
        # Ticket System
        embed.add_field(
            name="🎫 Ticket System",
            value=f"""
{EMOJI_DOT} `tickethelp` **(thelp, ticketcommands, tcmds)**
└ Complete ticket system commands guide

{EMOJI_DOT} `ticketsetup` **(tsetup, setupticket, ticketpanel)**
└ Set up the ticket panel

{EMOJI_DOT} `closeticket` **(close, tclose, endticket)**
└ Close current ticket

{EMOJI_DOT} `adduser <@user>` **(add, tadduser, ticketadd)**
└ Add user to ticket

{EMOJI_DOT} `claim` **(tclaim, claimticket)**
└ Claim current ticket

{EMOJI_DOT} `ticketstats` **(tstats, ticketinfo, tinfo)**
└ View ticket statistics
            """,
            inline=False
        )
        
        # Quick Access
        embed.add_field(
            name="⚡ Quick Access",
            value=f"""
{EMOJI_DOT} `help` **(h, commands, cmds)**
└ Show this help message

{EMOJI_DOT} `activityhelp` - Activity tracker detailed help
{EMOJI_DOT} `tickethelp` - Ticket system detailed help
            """,
            inline=False
        )
        
        # Bot Information
        embed.add_field(
            name="ℹ️ Bot Information",
            value=f"""
{EMOJI_DOT} **Guilds**: {len(self.bot.guilds)}
{EMOJI_DOT} **Users**: {len(self.bot.users)}
{EMOJI_DOT} **Commands**: {len([cmd for cmd in self.bot.commands])}
{EMOJI_DOT} **Ping**: {round(self.bot.latency * 1000)}ms
            """,
            inline=False
        )
        
        embed.set_footer(text="All command aliases are shown in parentheses • Use specific help commands for detailed guides")
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        await ctx.send(embed=embed)

    @app_commands.command(name="help", description="Show all available bot commands and systems")
    async def slash_help(self, interaction: discord.Interaction):
        """Slash command version of help"""
        embed = discord.Embed(
            title="🤖 CodeX Bot Help Center",
            description="Complete guide to all bot features and commands",
            color=discord.Color.blue(),
            timestamp=datetime.now(timezone.utc)
        )
        
        # Activity Tracker System
        embed.add_field(
            name="📊 Activity Tracker",
            value=f"""
{EMOJI_DOT} `activityhelp` **(ahelp, acthelp, ah)**
└ Complete activity tracking commands guide

{EMOJI_DOT} `vchours [@user]` **(vch, voicehours, vh)**
└ View voice channel hours

{EMOJI_DOT} `msgstats [@user]` **(ms, messagestats, messages)**
└ View message statistics

{EMOJI_DOT} `clearuserstats <@user>` **(cus, clearuser)**
└ Clear user's activity stats

{EMOJI_DOT} `clearmessagestats <@user>` **(cms, clearmsg)**
└ Clear user's message stats only

{EMOJI_DOT} `clearvoicestats <@user>` **(cvs, clearvoice)**
└ Clear user's voice stats only
            """,
            inline=False
        )
        
        # Ticket System
        embed.add_field(
            name="🎫 Ticket System",
            value=f"""
{EMOJI_DOT} `tickethelp` **(thelp, ticketcommands, tcmds)**
└ Complete ticket system commands guide

{EMOJI_DOT} `ticketsetup` **(tsetup, setupticket, ticketpanel)**
└ Set up the ticket panel

{EMOJI_DOT} `closeticket` **(close, tclose, endticket)**
└ Close current ticket

{EMOJI_DOT} `adduser <@user>` **(add, tadduser, ticketadd)**
└ Add user to ticket

{EMOJI_DOT} `claim` **(tclaim, claimticket)**
└ Claim current ticket

{EMOJI_DOT} `ticketstats` **(tstats, ticketinfo, tinfo)**
└ View ticket statistics
            """,
            inline=False
        )
        
        # Quick Access
        embed.add_field(
            name="⚡ Quick Access",
            value=f"""
{EMOJI_DOT} `/help` - Show this help message (slash command)
{EMOJI_DOT} `help` **(h, commands, cmds)** - Regular help command

{EMOJI_DOT} `activityhelp` - Activity tracker detailed help
{EMOJI_DOT} `tickethelp` - Ticket system detailed help
            """,
            inline=False
        )
        
        # Bot Information
        embed.add_field(
            name="ℹ️ Bot Information",
            value=f"""
{EMOJI_DOT} **Guilds**: {len(self.bot.guilds)}
{EMOJI_DOT} **Users**: {len(self.bot.users)}
{EMOJI_DOT} **Commands**: {len([cmd for cmd in self.bot.commands])}
{EMOJI_DOT} **Ping**: {round(self.bot.latency * 1000)}ms
            """,
            inline=False
        )
        
        embed.set_footer(text="All command aliases are shown in parentheses • Use specific help commands for detailed guides")
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        await interaction.response.send_message(embed=embed)

    @commands.command(name="botinfo", aliases=["info", "about", "stats"])
    async def bot_info(self, ctx):
        """Show detailed bot information and statistics"""
        embed = discord.Embed(
            title="🤖 CodeX Bot Information",
            description="Detailed bot statistics and information",
            color=discord.Color.green(),
            timestamp=datetime.now(timezone.utc)
        )
        
        # Bot Stats
        embed.add_field(
            name="📊 Statistics",
            value=f"""
{EMOJI_DOT} **Guilds**: {len(self.bot.guilds)}
{EMOJI_DOT} **Users**: {len(self.bot.users)}
{EMOJI_DOT} **Text Channels**: {len([c for c in self.bot.get_all_channels() if isinstance(c, discord.TextChannel)])}
{EMOJI_DOT} **Voice Channels**: {len([c for c in self.bot.get_all_channels() if isinstance(c, discord.VoiceChannel)])}
{EMOJI_DOT} **Commands**: {len([cmd for cmd in self.bot.commands])}
            """,
            inline=True
        )
        
        # Performance
        embed.add_field(
            name="⚡ Performance",
            value=f"""
{EMOJI_DOT} **Latency**: {round(self.bot.latency * 1000)}ms
{EMOJI_DOT} **Python**: 3.x
{EMOJI_DOT} **Discord.py**: {discord.__version__}
{EMOJI_DOT} **Status**: Online ✅
{EMOJI_DOT} **Uptime**: Active
            """,
            inline=True
        )
        
        # Features
        embed.add_field(
            name="🎯 Core Features",
            value=f"""
{EMOJI_DOT} Activity Tracking System
{EMOJI_DOT} Advanced Ticket Management
{EMOJI_DOT} Voice Hours Tracking
{EMOJI_DOT} Message Statistics
{EMOJI_DOT} Database Persistence
{EMOJI_DOT} Comprehensive Help System
            """,
            inline=False
        )
        
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        embed.set_footer(text="CodeX Bot - Advanced Discord Management System")
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(GlobalHelp(bot))