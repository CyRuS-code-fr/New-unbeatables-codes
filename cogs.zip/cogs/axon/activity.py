import discord
from discord.ext import commands
from core.Cog import Cog

class _activity(Cog):
    def __init__(self, bot):
        self.bot = bot
        self.color = 0x2f3136

    def help_custom(self):
        emoji = '📊'
        label = "Activity Tracker"
        description = "Message and Voice Channel Tracking Commands"
        return emoji, label, description

    @commands.group(name="activity", description="Activity tracking and statistics commands", aliases=["act", "acttracker"])
    async def _activity(self, ctx):
        if ctx.invoked_subcommand is None:
            embed = discord.Embed(
                title="📊 Activity Tracker Help",
                description="Track messages and voice channel usage with comprehensive statistics",
                color=self.color
            )
            
            embed.add_field(
                name="**📈 Statistics Commands**",
                value="`messagestats` `voicestats` `userstats`\n"
                      "`messageleaderboard` `voiceleaderboard` `activityleaderboard`",
                inline=False
            )
            
            embed.add_field(
                name="**⚙️ Configuration Commands**",
                value="`messagetracking` `voicetracking` `setupupdates`",
                inline=False
            )
            
            embed.add_field(
                name="**🔧 Management Commands**",
                value="`resetstats` `clearuserstats` `clearmessagestats` `clearvoicestats`\n"
                      "`verifyclear` - Verify if stats are cleared\n"
                      "Admin permissions required for clearing commands",
                inline=False
            )
            
            embed.add_field(
                name="**📝 Available Aliases**",
                value="**Stats:** `msgstats` `vcstats` `userstat` `useract`\n"
                      "**Leaderboards:** `msglb` `vclb` `actlb` `msgboard` `vcboard`\n"
                      "**Config:** `msgtrack` `vctrack` `setupchannel` `updatechannel`\n"
                      "**Management:** `clearstats` `resetuser` `clearmsg` `clearvc` `checkstats`",
                inline=False
            )
            
            embed.set_footer(text="Use >help activity <command> for detailed command info")
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            
            await ctx.reply(embed=embed)

    @_activity.command(name="messagestats", description="View message statistics for a user", aliases=["msgstats", "msgstat"])
    async def messagestats_help(self, ctx):
        embed = discord.Embed(
            title="📊 Message Stats Command",
            description="View detailed message statistics for any user",
            color=self.color
        )
        
        embed.add_field(
            name="**Usage**",
            value="`>messagestats [user]`",
            inline=False
        )
        
        embed.add_field(
            name="**Aliases**",
            value="`msgstats`, `msgstat`",
            inline=False
        )
        
        embed.add_field(
            name="**Examples**",
            value="`>messagestats` - Your message stats\n"
                  "`>msgstats @user` - Another user's stats",
            inline=False
        )
        
        embed.add_field(
            name="**Information Shown**",
            value="• Total messages sent\n• Channels used\n• Top 3 most active channels",
            inline=False
        )
        
        await ctx.reply(embed=embed)

    @_activity.command(name="voicestats", description="View voice channel statistics for a user", aliases=["vcstats", "voicetime"])
    async def voicestats_help(self, ctx):
        embed = discord.Embed(
            title="🎤 Voice Stats Command",
            description="View detailed voice channel statistics for any user",
            color=self.color
        )
        
        embed.add_field(
            name="**Usage**",
            value="`>voicestats [user]`",
            inline=False
        )
        
        embed.add_field(
            name="**Aliases**",
            value="`vcstats`, `voicetime`",
            inline=False
        )
        
        embed.add_field(
            name="**Examples**",
            value="`>voicestats` - Your voice stats\n"
                  "`>vcstats @user` - Another user's stats",
            inline=False
        )
        
        embed.add_field(
            name="**Information Shown**",
            value="• Total time in voice channels\n• Voice channels used\n• Top 3 most used channels",
            inline=False
        )
        
        await ctx.reply(embed=embed)

    @_activity.command(name="userstats", description="View combined activity statistics for a user", aliases=["userstat", "useract"])
    async def userstats_help(self, ctx):
        embed = discord.Embed(
            title="📈 User Stats Command",
            description="View combined message and voice statistics",
            color=self.color
        )
        
        embed.add_field(
            name="**Usage**",
            value="`>userstats [user]`",
            inline=False
        )
        
        embed.add_field(
            name="**Aliases**",
            value="`userstat`, `useract`",
            inline=False
        )
        
        embed.add_field(
            name="**Examples**",
            value="`>userstats` - Your activity stats\n"
            "`>userstat @user` - Another user's stats",
            inline=False
        )
        
        embed.add_field(
            name="**Information Shown**",
            value="• All-time message and voice stats\n• Today's activity summary\n• Combined activity overview",
            inline=False
        )
        
        await ctx.reply(embed=embed)

    @_activity.command(name="messageleaderboard", description="View message leaderboard", aliases=["msglb", "topmessages", "msgboard"])
    async def messageleaderboard_help(self, ctx):
        embed = discord.Embed(
            title="🏆 Message Leaderboard Command",
            description="View the most active message senders",
            color=self.color
        )
        
        embed.add_field(
            name="**Usage**",
            value="`>messageleaderboard [limit]`",
            inline=False
        )
        
        embed.add_field(
            name="**Aliases**",
            value="`msglb`, `topmessages`, `msgboard`",
            inline=False
        )
        
        embed.add_field(
            name="**Examples**",
            value="`>messageleaderboard` - Top 10 users\n"
                  "`>msglb 20` - Top 20 users",
            inline=False
        )
        
        embed.add_field(
            name="**Notes**",
            value="• Default limit: 10 users\n• Maximum limit: 25 users\n• Shows total messages sent",
            inline=False
        )
        
        await ctx.reply(embed=embed)

    @_activity.command(name="voiceleaderboard", description="View voice channel leaderboard", aliases=["vclb", "topvoice", "vcboard"])
    async def voiceleaderboard_help(self, ctx):
        embed = discord.Embed(
            title="🏆 Voice Leaderboard Command",
            description="View the most active voice channel users",
            color=self.color
        )
        
        embed.add_field(
            name="**Usage**",
            value="`>voiceleaderboard [limit]`",
            inline=False
        )
        
        embed.add_field(
            name="**Aliases**",
            value="`vclb`, `topvoice`, `vcboard`",
            inline=False
        )
        
        embed.add_field(
            name="**Examples**",
            value="`>voiceleaderboard` - Top 10 users\n"
                  "`>vclb 15` - Top 15 users",
            inline=False
        )
        
        embed.add_field(
            name="**Notes**",
            value="• Default limit: 10 users\n• Maximum limit: 25 users\n• Shows total time in voice channels",
            inline=False
        )
        
        await ctx.reply(embed=embed)

    @_activity.command(name="activityleaderboard", description="View daily activity leaderboard", aliases=["actlb", "topactivity", "actboard"])
    async def activityleaderboard_help(self, ctx):
        embed = discord.Embed(
            title="🏆 Activity Leaderboard Command",
            description="View today's most active users (messages + voice)",
            color=self.color
        )
        
        embed.add_field(
            name="**Usage**",
            value="`>activityleaderboard [limit]`",
            inline=False
        )
        
        embed.add_field(
            name="**Aliases**",
            value="`actlb`, `topactivity`, `actboard`",
            inline=False
        )
        
        embed.add_field(
            name="**Examples**",
            value="`>activityleaderboard` - Top 10 users today\n"
                  "`>actlb 20` - Top 20 users today",
            inline=False
        )
        
        embed.add_field(
            name="**Notes**",
            value="• Shows today's activity only\n• Combines messages and voice time\n• Resets daily",
            inline=False
        )
        
        await ctx.reply(embed=embed)

    @_activity.command(name="messagetracking", description="Enable/disable message tracking", aliases=["msgtrack", "msgenable"])
    async def messagetracking_help(self, ctx):
        embed = discord.Embed(
            title="⚙️ Message Tracking Command",
            description="Control message tracking for the server",
            color=self.color
        )
        
        embed.add_field(
            name="**Usage**",
            value="`>messagetracking [on/off]`",
            inline=False
        )
        
        embed.add_field(
            name="**Aliases**",
            value="`msgtrack`, `msgenable`",
            inline=False
        )
        
        embed.add_field(
            name="**Examples**",
            value="`>messagetracking` - Check current status\n"
                  "`>msgtrack on` - Enable tracking\n"
                  "`>msgtrack off` - Disable tracking",
            inline=False
        )
        
        embed.add_field(
            name="**Permission Required**",
            value="Administrator",
            inline=False
        )
        
        await ctx.reply(embed=embed)

    @_activity.command(name="voicetracking", description="Enable/disable voice tracking", aliases=["vctrack", "vcenable"])
    async def voicetracking_help(self, ctx):
        embed = discord.Embed(
            title="⚙️ Voice Tracking Command",
            description="Control voice channel tracking for the server",
            color=self.color
        )
        
        embed.add_field(
            name="**Usage**",
            value="`>voicetracking [on/off]`",
            inline=False
        )
        
        embed.add_field(
            name="**Aliases**",
            value="`vctrack`, `vcenable`",
            inline=False
        )
        
        embed.add_field(
            name="**Examples**",
            value="`>voicetracking` - Check current status\n"
                  "`>vctrack on` - Enable tracking\n"
                  "`>vctrack off` - Disable tracking",
            inline=False
        )
        
        embed.add_field(
            name="**Permission Required**",
            value="Administrator",
            inline=False
        )
        
        await ctx.reply(embed=embed)

    @_activity.command(name="setupupdates", description="Configure automatic activity updates", aliases=["setupchannel", "updatechannel"])
    async def setupupdates_help(self, ctx):
        embed = discord.Embed(
            title="⚙️ Setup Updates Command",
            description="Configure automatic periodic activity updates",
            color=self.color
        )
        
        embed.add_field(
            name="**Usage**",
            value="`>setupupdates [#channel] [interval_in_seconds]`",
            inline=False
        )
        
        embed.add_field(
            name="**Aliases**",
            value="`setupchannel`, `updatechannel`",
            inline=False
        )
        
        embed.add_field(
            name="**Examples**",
            value="`>setupupdates` - Use current channel, 1 hour interval\n"
                  "`>setupupdates #general 7200` - 2 hour updates\n"
                  "`>setupchannel #activity 1800` - 30 minute updates",
            inline=False
        )
        
        embed.add_field(
            name="**Notes**",
            value="• Default interval: 1 hour (3600 seconds)\n• Minimum: 5 minutes (300 seconds)\n• Maximum: 24 hours (86400 seconds)",
            inline=False
        )
        
        embed.add_field(
            name="**Permission Required**",
            value="Administrator",
            inline=False
        )
        
        await ctx.reply(embed=embed)

    @_activity.command(name="resetstats", description="Reset activity statistics", aliases=["clearstats", "resetactivity"])
    async def resetstats_help(self, ctx):
        embed = discord.Embed(
            title="🗑️ Reset Stats Command",
            description="Reset activity statistics for a user or entire server",
            color=self.color
        )
        
        embed.add_field(
            name="**Usage**",
            value="`>resetstats [user]`",
            inline=False
        )
        
        embed.add_field(
            name="**Aliases**",
            value="`clearstats`, `resetactivity`",
            inline=False
        )
        
        embed.add_field(
            name="**Examples**",
            value="`>resetstats` - Reset all server stats\n"
                  "`>resetstats @user` - Reset specific user stats",
            inline=False
        )
        
        embed.add_field(
            name="**Warning**",
            value="⚠️ This action cannot be undone!",
            inline=False
        )
        
        embed.add_field(
            name="**Permission Required**",
            value="Administrator",
            inline=False
        )
        
        await ctx.reply(embed=embed)

    @_activity.command(name="clearuserstats", description="Clear stats for a specific user", aliases=["resetuser", "removeuserstats", "clearuseract"])
    async def clearuserstats_help(self, ctx):
        embed = discord.Embed(
            title="🗑️ Clear User Stats Command",
            description="Clear all activity statistics for a specific user",
            color=self.color
        )
        
        embed.add_field(
            name="**Usage**",
            value="`>clearuserstats <user>`",
            inline=False
        )
        
        embed.add_field(
            name="**Aliases**",
            value="`resetuser`, `removeuserstats`, `clearuseract`",
            inline=False
        )
        
        embed.add_field(
            name="**Examples**",
            value="`>clearuserstats @user` - Clear all stats for the user\n"
                  "`>resetuser @member` - Same but with alias",
            inline=False
        )
        
        embed.add_field(
            name="**What Gets Cleared**",
            value="• All message statistics\n• All voice channel statistics\n• All daily activity data",
            inline=False
        )
        
        embed.add_field(
            name="**Warning**",
            value="⚠️ This action cannot be undone!",
            inline=False
        )
        
        embed.add_field(
            name="**Permission Required**",
            value="Administrator",
            inline=False
        )
        
        await ctx.reply(embed=embed)

    @_activity.command(name="clearmessagestats", description="Clear only message stats for a user", aliases=["clearmsg", "resetmsg", "removemsgstats"])
    async def clearmessagestats_help(self, ctx):
        embed = discord.Embed(
            title="🗑️ Clear Message Stats Command",
            description="Clear only message statistics for a specific user",
            color=self.color
        )
        
        embed.add_field(
            name="**Usage**",
            value="`>clearmessagestats <user>`",
            inline=False
        )
        
        embed.add_field(
            name="**Aliases**",
            value="`clearmsg`, `resetmsg`, `removemsgstats`",
            inline=False
        )
        
        embed.add_field(
            name="**Examples**",
            value="`>clearmessagestats @user` - Clear message stats only\n"
                  "`>clearmsg @member` - Same using alias",
            inline=False
        )
        
        embed.add_field(
            name="**What Gets Cleared**",
            value="• All message statistics\n• Channel-specific message data\n• Daily message counts",
            inline=False
        )
        
        embed.add_field(
            name="**Note**",
            value="Voice channel statistics remain unchanged",
            inline=False
        )
        
        embed.add_field(
            name="**Permission Required**",
            value="Administrator",
            inline=False
        )
        
        await ctx.reply(embed=embed)

    @_activity.command(name="clearvoicestats", description="Clear only voice stats for a user", aliases=["clearvc", "resetvc", "removevcstats"])
    async def clearvoicestats_help(self, ctx):
        embed = discord.Embed(
            title="🗑️ Clear Voice Stats Command",
            description="Clear only voice channel statistics for a specific user",
            color=self.color
        )
        
        embed.add_field(
            name="**Usage**",
            value="`>clearvoicestats <user>`",
            inline=False
        )
        
        embed.add_field(
            name="**Aliases**",
            value="`clearvc`, `resetvc`, `removevcstats`",
            inline=False
        )
        
        embed.add_field(
            name="**Examples**",
            value="`>clearvoicestats @user` - Clear voice stats only\n"
                  "`>clearvc @member` - Same using alias",
            inline=False
        )
        
        embed.add_field(
            name="**What Gets Cleared**",
            value="• All voice channel statistics\n• Channel-specific voice time\n• Daily voice time data",
            inline=False
        )
        
        embed.add_field(
            name="**Note**",
            value="Message statistics remain unchanged",
            inline=False
        )
        
        embed.add_field(
            name="**Permission Required**",
            value="Administrator",
            inline=False
        )
        
        await ctx.reply(embed=embed)

async def setup(bot):
    await bot.add_cog(_activity(bot))