import discord

from discord.ext import commands

class _ticket(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    """Ticket"""

    def help_custom(self):

              emoji = '<:ticket:1355527347335467191>'

              label = "Ticket"

              description = "Show you Commands of Ticket"

              return emoji, label, description

    @commands.group()

    async def __Ticket__(self, ctx: commands.Context):

        """`Setup Commands:

ticketsetup - Create ticket panel

Management Commands:

closeticket - Close with transcript options

adduser <@user> - Add user to ticket

removeuser <@user> - Remove user from ticket

claim - Claim ticket ownership

lockticket - Lock ticket (prevent user messages)

unlockticket - Unlock ticket

renameticket <name> - Rename ticket channel

Advanced Commands:

priority <high/medium/low> - Set ticket priority

rate <1-5> [feedback] - Rate ticket experience

`transcript` - Generate ticket transcript

`ticketstats` - View server ticket statistics

Help:`tickethelp` - Complete command guide`"""